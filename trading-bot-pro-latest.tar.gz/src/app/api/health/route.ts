import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

/**
 * Health Monitoring API
 * لوحة مراقبة الصحة
 */

interface HealthStatus {
  status: 'HEALTHY' | 'WARNING' | 'CRITICAL';
  timestamp: Date;
  uptime: number;
  services: {
    database: { status: boolean; latency?: number; error?: string };
    ib: { status: boolean; latency?: number; error?: string };
    telegram: { status: boolean; error?: string };
    websocket: { status: boolean; error?: string };
  };
  system: {
    memory: { used: number; total: number; percentage: number };
    cpu: number;
    disk?: { used: number; total: number; percentage: number };
  };
  trading: {
    openTrades: number;
    pendingTrades: number;
    todayTrades: number;
    todayPnL: number;
    dailyLossLimitReached: boolean;
  };
  lastErrors: Array<{ time: Date; message: string; source: string }>;
}

// GET - Get full health status
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    const startTime = Date.now();

    // Check database
    let dbStatus = { status: true, latency: 0 };
    try {
      const dbStart = Date.now();
      await db.$queryRaw`SELECT 1`;
      dbStatus.latency = Date.now() - dbStart;
    } catch (e) {
      dbStatus.status = false;
    }

    // Check IB connection
    let ibStatus = { status: false, latency: 0, error: 'Not connected' };
    try {
      const settings = await db.botSettings.findFirst();
      if (settings?.ibConnected) {
        ibStatus.status = true;
        ibStatus.error = '';
        
        // Try to ping IB service
        const ibStart = Date.now();
        const res = await fetch('http://localhost:3003/health', { 
          method: 'GET',
          signal: AbortSignal.timeout(5000),
        }).catch(() => null);
        ibStatus.latency = Date.now() - ibStart;
        
        if (!res?.ok) {
          ibStatus.status = false;
          ibStatus.error = 'IB service not responding';
        }
      }
    } catch (e) {
      ibStatus.error = 'Connection error';
    }

    // Check Telegram
    let telegramStatus = { status: false, error: 'Not configured' };
    try {
      const notifSettings = await db.notificationSettings.findFirst();
      if (notifSettings?.telegramEnabled && notifSettings.telegramBotToken) {
        const res = await fetch(`https://api.telegram.org/bot${notifSettings.telegramBotToken}/getMe`);
        if (res.ok) {
          telegramStatus.status = true;
          telegramStatus.error = '';
        } else {
          telegramStatus.error = 'Invalid bot token';
        }
      }
    } catch (e) {
      telegramStatus.error = 'Check failed';
    }

    // Check WebSocket
    let wsStatus = { status: false, error: 'Not running' };
    try {
      const res = await fetch('http://localhost:3004', { 
        method: 'GET',
        signal: AbortSignal.timeout(3000),
      }).catch(() => null);
      if (res?.ok) {
        wsStatus.status = true;
        wsStatus.error = '';
      }
    } catch {
      wsStatus.error = 'Service not available';
    }

    // Get trading stats
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const [openTrades, pendingTrades, todayTrades] = await Promise.all([
      db.trade.count({ where: { status: 'OPEN' } }),
      db.trade.count({ where: { status: 'PENDING' } }),
      db.trade.count({ where: { createdAt: { gte: today } } }),
    ]);

    const todayClosed = await db.trade.findMany({
      where: { 
        status: 'CLOSED',
        closedAt: { gte: today },
      },
      select: { pnl: true },
    });
    const todayPnL = todayClosed.reduce((s, t) => s + (t.pnl || 0), 0);

    // Check daily loss limit
    const settings = await db.botSettings.findFirst();
    const dailyLossLimitReached = settings?.smartModeEnabled 
      && settings.maxDailyLoss 
      && todayPnL < -settings.maxDailyLoss;

    // Get memory usage
    const memUsage = process.memoryUsage();
    const memory = {
      used: memUsage.heapUsed,
      total: memUsage.heapTotal,
      percentage: (memUsage.heapUsed / memUsage.heapTotal) * 100,
    };

    // Get recent errors from audit log
    const recentErrors = await db.auditLog.findMany({
      where: { status: 'FAILED' },
      take: 10,
      orderBy: { createdAt: 'desc' },
      select: {
        createdAt: true,
        errorMessage: true,
        action: true,
      },
    });

    // Determine overall status
    let overallStatus: 'HEALTHY' | 'WARNING' | 'CRITICAL' = 'HEALTHY';
    if (!dbStatus.status) {
      overallStatus = 'CRITICAL';
    } else if (!ibStatus.status || memory.percentage > 80) {
      overallStatus = 'WARNING';
    }

    const health: HealthStatus = {
      status: overallStatus,
      timestamp: new Date(),
      uptime: process.uptime(),
      services: {
        database: dbStatus,
        ib: ibStatus,
        telegram: telegramStatus,
        websocket: wsStatus,
      },
      system: {
        memory,
        cpu: 0, // Would need a proper CPU monitor
      },
      trading: {
        openTrades,
        pendingTrades,
        todayTrades,
        todayPnL,
        dailyLossLimitReached: dailyLossLimitReached || false,
      },
      lastErrors: recentErrors.map(e => ({
        time: e.createdAt,
        message: e.errorMessage || 'Unknown error',
        source: e.action,
      })),
    };

    return NextResponse.json(health);

  } catch (error) {
    console.error('Health check error:', error);
    return NextResponse.json({ 
      status: 'CRITICAL',
      error: 'Health check failed',
      timestamp: new Date(),
    }, { status: 500 });
  }
}

// POST - Trigger specific health check
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action } = body;

    switch (action) {
      case 'PING_IB':
        try {
          const res = await fetch('http://localhost:3003/ping', { method: 'POST' });
          return NextResponse.json({ success: res.ok, latency: Date.now() });
        } catch {
          return NextResponse.json({ success: false, error: 'IB not responding' });
        }

      case 'TEST_TELEGRAM':
        try {
          const settings = await db.notificationSettings.findFirst();
          if (!settings?.telegramBotToken || !settings?.telegramChatId) {
            return NextResponse.json({ success: false, error: 'Telegram not configured' });
          }
          
          await fetch(`https://api.telegram.org/bot${settings.telegramBotToken}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: settings.telegramChatId,
              text: '✅ Health check: Telegram is working!',
            }),
          });
          
          return NextResponse.json({ success: true, message: 'Test message sent' });
        } catch (e) {
          return NextResponse.json({ success: false, error: 'Telegram test failed' });
        }

      case 'RECONNECT_IB':
        try {
          const res = await fetch('http://localhost:3003/reconnect', { method: 'POST' });
          return NextResponse.json({ success: res.ok });
        } catch {
          return NextResponse.json({ success: false, error: 'Reconnect failed' });
        }

      default:
        return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
    }

  } catch (error) {
    return NextResponse.json({ error: 'Action failed' }, { status: 500 });
  }
}
