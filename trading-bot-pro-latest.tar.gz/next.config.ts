import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  /* config options here */
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  allowedDevOrigins: [
    "preview-chat-fef0d1e3-5976-4b9a-8087-7e07180c028a.space.z.ai",
    ".space.z.ai",
  ],
};

export default nextConfig;
