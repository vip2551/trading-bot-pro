import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Get subscription details
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (!userId) {
      return NextResponse.json({ error: 'User ID required' }, { status: 400 });
    }

    const subscription = await db.subscription.findUnique({
      where: { userId },
      include: {
        plan: true,
        user: { select: { email: true, name: true } },
      },
    });

    if (!subscription) {
      return NextResponse.json({ error: 'Subscription not found' }, { status: 404 });
    }

    // Check if trial expired
    if (subscription.isTrial && subscription.trialEndsAt) {
      if (new Date() > subscription.trialEndsAt && subscription.status === 'ACTIVE') {
        await db.subscription.update({
          where: { id: subscription.id },
          data: { status: 'EXPIRED' },
        });
        subscription.status = 'EXPIRED';
      }
    }

    // Format response for frontend compatibility
    const response = {
      id: subscription.id,
      plan: subscription.planName || subscription.plan?.name || 'TRIAL',
      planDetails: subscription.plan,
      status: subscription.status,
      isTrial: subscription.isTrial,
      trialEndsAt: subscription.trialEndsAt,
      maxTradesPerDay: subscription.maxTradesPerDay,
      maxActiveTrades: subscription.maxActiveTrades,
      currentPeriodEnd: subscription.currentPeriodEnd,
    };

    return NextResponse.json({ subscription: response });
  } catch (error) {
    console.error('Get subscription error:', error);
    return NextResponse.json({ error: 'Failed to get subscription' }, { status: 500 });
  }
}

// Update subscription (cancel, etc.)
export async function PATCH(request: NextRequest) {
  try {
    const { userId, action } = await request.json();

    if (!userId || !action) {
      return NextResponse.json({ error: 'Missing parameters' }, { status: 400 });
    }

    const subscription = await db.subscription.findUnique({
      where: { userId },
    });

    if (!subscription) {
      return NextResponse.json({ error: 'Subscription not found' }, { status: 404 });
    }

    if (action === 'cancel') {
      await db.subscription.update({
        where: { id: subscription.id },
        data: {
          cancelAtPeriodEnd: true,
          status: 'CANCELLED',
        },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Update subscription error:', error);
    return NextResponse.json({ error: 'Failed to update subscription' }, { status: 500 });
  }
}
