import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const { email, password, name } = await request.json();

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Password must be at least 6 characters' },
        { status: 400 }
      );
    }

    // Check if user exists
    const existingUser = await db.user.findUnique({
      where: { email },
    });

    if (existingUser) {
      return NextResponse.json(
        { error: 'User already exists' },
        { status: 400 }
      );
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Find TRIAL plan or use defaults
    const trialPlan = await db.plan.findFirst({
      where: { name: 'TRIAL', isActive: true },
    });

    // Calculate trial end date
    const trialDays = trialPlan?.trialDays || 7;
    const trialEndsAt = new Date();
    trialEndsAt.setDate(trialEndsAt.getDate() + trialDays);

    // Create user with trial subscription
    const user = await db.user.create({
      data: {
        email,
        name: name || email.split('@')[0],
        password: hashedPassword,
        subscription: {
          create: {
            planId: trialPlan?.id || null,
            planName: 'TRIAL',
            status: 'ACTIVE',
            isTrial: true,
            trialEndsAt,
            maxTradesPerDay: trialPlan?.maxTradesPerDay || 5,
            maxActiveTrades: trialPlan?.maxActiveTrades || 2,
          },
        },
        botSettings: {
          create: {
            accountType: 'SIMULATION',
          },
        },
      },
      include: {
        subscription: true,
      },
    });

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        subscription: user.subscription,
      },
    });
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'Failed to create account' },
      { status: 500 }
    );
  }
}
