import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Start the bot with recovery
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));
    const userId = body.userId;

    let settings;

    if (userId) {
      settings = await db.botSettings.findUnique({
        where: { userId },
      });

      if (!settings) {
        settings = await db.botSettings.create({
          data: { userId, isRunning: true },
        });
      } else {
        settings = await db.botSettings.update({
          where: { id: settings.id },
          data: { isRunning: true },
        });
      }
    } else {
      // Fallback for backward compatibility - find any settings
      settings = await db.botSettings.findFirst();

      if (!settings) {
        // Cannot create without userId, return success anyway
        return NextResponse.json({ success: true, settings: null });
      }

      settings = await db.botSettings.update({
        where: { id: settings.id },
        data: { isRunning: true },
      });
    }

    // Recovery: Check for open trades that need to be resumed
    const openTrades = await db.trade.findMany({
      where: {
        userId: userId || undefined,
        status: 'OPEN',
      },
    });

    const pendingTrades = await db.trade.findMany({
      where: {
        userId: userId || undefined,
        status: 'PENDING',
        createdAt: {
          gte: new Date(Date.now() - 30 * 60 * 1000), // Last 30 minutes
        },
      },
    });

    // Trades that need trailing stop monitoring
    const trailingStopTrades = openTrades.filter(t => t.trailingStopEnabled);
    
    // Trades with bracket orders
    const bracketOrders = openTrades.filter(t => t.isBracketOrder);

    // Auto-close trades
    const autoCloseTrades = openTrades.filter(t => 
      t.autoCloseAt && new Date(t.autoCloseAt) > new Date()
    );

    // Recovery summary
    const recoveryInfo = {
      openTrades: openTrades.length,
      pendingTrades: pendingTrades.length,
      trailingStopTrades: trailingStopTrades.length,
      bracketOrders: bracketOrders.length,
      autoCloseTrades: autoCloseTrades.length,
    };

    // Start IB service connection with recovery
    let ibStatus = { connected: false, message: 'IB service not available' };
    try {
      const ibRes = await fetch('http://localhost:3003/bot/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recovery: true,
          openTrades: openTrades.map(t => ({
            id: t.id,
            symbol: t.symbol,
            ibOrderId: t.ibOrderId,
            bracketStopOrderId: t.bracketStopOrderId,
            bracketProfitOrderId: t.bracketProfitOrderId,
            trailingStopEnabled: t.trailingStopEnabled,
            trailingStopPrice: t.trailingStopPrice,
          })),
        }),
      });
      
      if (ibRes.ok) {
        ibStatus = await ibRes.json();
        
        // Update IB connection status
        await db.botSettings.update({
          where: { id: settings.id },
          data: { ibConnected: ibStatus.connected },
        });
      }
    } catch (err) {
      console.error('Failed to start IB service:', err);
    }

    // Create recovery log
    if (userId && (openTrades.length > 0 || pendingTrades.length > 0)) {
      await db.auditLog.create({
        data: {
          userId,
          action: 'BOT_START_WITH_RECOVERY',
          entity: 'BOT',
          details: JSON.stringify(recoveryInfo),
          status: 'SUCCESS',
        },
      });
    }

    return NextResponse.json({ 
      success: true, 
      settings,
      recovery: recoveryInfo,
      ibStatus,
      message: openTrades.length > 0 
        ? `Bot started. Recovered ${openTrades.length} open trades.` 
        : 'Bot started successfully',
    });
  } catch (error) {
    console.error('Error starting bot:', error);
    return NextResponse.json({ error: 'Failed to start bot' }, { status: 500 });
  }
}
