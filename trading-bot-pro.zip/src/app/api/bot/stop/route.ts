import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Stop the bot
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));
    const userId = body.userId;

    let settings;

    if (userId) {
      settings = await db.botSettings.findUnique({
        where: { userId },
      });

      if (!settings) {
        settings = await db.botSettings.create({
          data: { userId, isRunning: false },
        });
      } else {
        settings = await db.botSettings.update({
          where: { id: settings.id },
          data: { isRunning: false },
        });
      }
    } else {
      // Fallback for backward compatibility - find any settings
      settings = await db.botSettings.findFirst();

      if (!settings) {
        // Cannot create without userId, return success anyway
        return NextResponse.json({ success: true, settings: null });
      }

      settings = await db.botSettings.update({
        where: { id: settings.id },
        data: { isRunning: false },
      });
    }

    // Stop IB service
    try {
      await fetch('http://localhost:3003/bot/stop', {
        method: 'POST',
      });
    } catch (err) {
      console.error('Failed to stop IB service:', err);
    }

    return NextResponse.json({ success: true, settings });
  } catch (error) {
    console.error('Error stopping bot:', error);
    return NextResponse.json({ error: 'Failed to stop bot' }, { status: 500 });
  }
}
