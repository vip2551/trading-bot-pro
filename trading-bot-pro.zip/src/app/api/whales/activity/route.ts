import { NextRequest, NextResponse } from "next/server";

// Simulated whale activity data
// In production, this would connect to real data providers like:
// - Unusual Whales API
// - FlowAlgo
// - Dark pool data providers
// - Options flow services

const WHALE_TYPES = ["WHALE", "HEDGE_FUND", "MARKET_MAKER", "DARK_POOL", "UNUSUAL_OPTIONS"] as const;
const SYMBOLS = ["SPX", "SPY", "QQQ", "TSLA", "NVDA", "AAPL", "AMD", "AMZN", "META", "GOOGL"];
const DIRECTIONS = ["BUY", "SELL"] as const;

function generateWhaleActivity() {
  const activities = [];
  const count = Math.floor(Math.random() * 8) + 5; // 5-12 activities

  for (let i = 0; i < count; i++) {
    const symbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
    const direction = DIRECTIONS[Math.floor(Math.random() * DIRECTIONS.length)];
    const type = WHALE_TYPES[Math.floor(Math.random() * WHALE_TYPES.length)];
    const size = Math.floor(Math.random() * 50000) + 10000;
    const price = Math.random() * 500 + 100;
    const confidence = Math.floor(Math.random() * 30) + 70;

    activities.push({
      id: `whale-${Date.now()}-${i}`,
      type,
      symbol,
      direction,
      size,
      price: parseFloat(price.toFixed(2)),
      timestamp: new Date(Date.now() - Math.random() * 3600000),
      confidence,
      estimatedValue: size * price,
      source: type === "DARK_POOL" ? "Dark Pool Data" : type === "HEDGE_FUND" ? "13F Filing" : "Real-time Flow",
      isFollowed: Math.random() > 0.7,
    });
  }

  return activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
}

function generateSmartMoneySignals() {
  const signals = [];
  const count = Math.floor(Math.random() * 4) + 1; // 1-4 signals

  const signalTypes = ["ENTRY", "EXIT", "ACCUMULATION", "DISTRIBUTION"] as const;
  const urgencyLevels = ["LOW", "MEDIUM", "HIGH", "CRITICAL"] as const;
  const actions = ["BUY", "SELL", "WAIT"] as const;

  const reasons = [
    "Multiple whales detected accumulating positions",
    "Unusual options activity suggests institutional buying",
    "Dark pool data shows large block trades",
    "Hedge fund 13F filings indicate new positions",
    "Market maker positioning suggests directional bias",
    "Order flow imbalance detected by AI",
  ];

  for (let i = 0; i < count; i++) {
    const symbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
    const confidence = Math.floor(Math.random() * 25) + 75;
    const aiScore = Math.floor(Math.random() * 20) + 80;
    const whaleCount = Math.floor(Math.random() * 5) + 1;
    const totalVolume = Math.floor(Math.random() * 50000000) + 10000000;

    signals.push({
      id: `signal-${Date.now()}-${i}`,
      symbol,
      signalType: signalTypes[Math.floor(Math.random() * signalTypes.length)],
      confidence,
      aiScore,
      whaleCount,
      totalVolume,
      timestamp: new Date(Date.now() - Math.random() * 1800000),
      reason: reasons[Math.floor(Math.random() * reasons.length)],
      recommendedAction: actions[Math.floor(Math.random() * actions.length)],
      urgency: urgencyLevels[Math.floor(Math.random() * urgencyLevels.length)],
    });
  }

  return signals.sort((a, b) => {
    const urgencyOrder = { CRITICAL: 0, HIGH: 1, MEDIUM: 2, LOW: 3 };
    return urgencyOrder[a.urgency] - urgencyOrder[b.urgency];
  });
}

function calculateStats() {
  return {
    totalWhales: Math.floor(Math.random() * 20) + 15,
    todayVolume: Math.floor(Math.random() * 500000000) + 100000000,
    buyPressure: Math.floor(Math.random() * 30) + 35,
    aiAccuracy: 85 + Math.random() * 10,
    signalsGenerated: Math.floor(Math.random() * 15) + 5,
    profitableSignals: Math.floor(Math.random() * 10) + 3,
  };
}

export async function GET(request: NextRequest) {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500));

  const activities = generateWhaleActivity();
  const signals = generateSmartMoneySignals();
  const stats = calculateStats();

  return NextResponse.json({
    success: true,
    activities,
    signals,
    stats,
    timestamp: new Date().toISOString(),
  });
}
