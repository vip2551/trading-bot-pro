import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch all plans
export async function GET() {
  try {
    const plans = await db.plan.findMany({
      where: { isActive: true },
      orderBy: { sortOrder: 'asc' },
    });

    return NextResponse.json({ plans });
  } catch (error) {
    console.error('Error fetching plans:', error);
    return NextResponse.json({ error: 'Failed to fetch plans' }, { status: 500 });
  }
}

// POST - Create new plan (Admin only)
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();

    const plan = await db.plan.create({
      data: {
        name: data.name,
        displayName: data.displayName,
        description: data.description,
        priceMonthly: parseFloat(data.priceMonthly) || 0,
        priceYearly: parseFloat(data.priceYearly) || 0,
        currency: data.currency || 'USD',
        maxTradesPerDay: parseInt(data.maxTradesPerDay) || 5,
        maxActiveTrades: parseInt(data.maxActiveTrades) || 2,
        trialDays: parseInt(data.trialDays) || 0,
        features: data.features ? JSON.stringify(data.features) : null,
        isPopular: data.isPopular || false,
        sortOrder: data.sortOrder || 0,
      },
    });

    return NextResponse.json({ success: true, plan });
  } catch (error) {
    console.error('Error creating plan:', error);
    return NextResponse.json({ error: 'Failed to create plan' }, { status: 500 });
  }
}
