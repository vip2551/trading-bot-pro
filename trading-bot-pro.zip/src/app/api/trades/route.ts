import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');
    const userId = searchParams.get('userId');
    const limit = parseInt(searchParams.get('limit') || '50');

    const where: { status?: string; userId?: string } = {};
    if (status) where.status = status;
    if (userId) where.userId = userId;

    const trades = await db.trade.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      include: {
        notifications: true,
        logs: true,
      },
    });

    return NextResponse.json({ trades });
  } catch (error) {
    console.error('Error fetching trades:', error);
    return NextResponse.json({ error: 'Failed to fetch trades' }, { status: 500 });
  }
}
