import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Close a trade
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ tradeId: string }> }
) {
  try {
    const { tradeId } = await params;
    
    // Get the trade
    const trade = await db.trade.findUnique({
      where: { id: tradeId },
    });
    
    if (!trade) {
      return NextResponse.json({ error: 'Trade not found' }, { status: 404 });
    }
    
    if (trade.status !== 'OPEN' && trade.status !== 'PENDING') {
      return NextResponse.json({ error: 'Trade is not open' }, { status: 400 });
    }
    
    // Update trade status
    const updatedTrade = await db.trade.update({
      where: { id: tradeId },
      data: {
        status: 'CLOSED',
        closedAt: new Date(),
      },
    });
    
    // Log the action
    await db.tradeLog.create({
      data: {
        tradeId,
        action: 'CLOSED',
        details: 'Trade closed manually via dashboard',
      },
    });
    
    // Send to IB service to close
    const settings = await db.botSettings.findFirst();
    if (settings?.isRunning) {
      try {
        await fetch(`http://localhost:3003/trade/close`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tradeId }),
        });
      } catch (err) {
        console.error('Failed to send close request to IB service:', err);
      }
    }
    
    return NextResponse.json({ success: true, trade: updatedTrade });
  } catch (error) {
    console.error('Error closing trade:', error);
    return NextResponse.json({ error: 'Failed to close trade' }, { status: 500 });
  }
}
