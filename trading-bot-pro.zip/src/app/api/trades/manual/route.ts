import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      userId,
      symbol,
      direction,
      quantity,
      strike,
      instrumentType,
      optionType,
      expiry,
      stopLoss,
      takeProfit,
      trailingStopEnabled,
      trailingStopAmount,
      trailingStopPercent,
      isBracketOrder,
      maxHoldingMinutes,
    } = body;

    // Check subscription if userId provided
    if (userId) {
      const subscription = await db.subscription.findUnique({
        where: { userId },
      });

      if (!subscription || subscription.status !== 'ACTIVE') {
        return NextResponse.json({ error: 'Subscription inactive' }, { status: 403 });
      }

      // Check trial expiration
      if (subscription.isTrial && subscription.trialEndsAt) {
        if (new Date() > subscription.trialEndsAt) {
          return NextResponse.json({ error: 'Trial expired' }, { status: 403 });
        }
      }

      // Check trade limits
      const todayTrades = await db.trade.count({
        where: {
          userId,
          createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) },
        },
      });

      if (subscription.maxTradesPerDay > 0 && todayTrades >= subscription.maxTradesPerDay) {
        return NextResponse.json({ error: 'Daily trade limit reached' }, { status: 403 });
      }

      const activeTrades = await db.trade.count({
        where: { userId, status: 'OPEN' },
      });

      if (subscription.maxActiveTrades > 0 && activeTrades >= subscription.maxActiveTrades) {
        return NextResponse.json({ error: 'Maximum active trades reached' }, { status: 403 });
      }

      // Check multiple trades setting from bot settings
      const botSettings = await db.botSettings.findUnique({ where: { userId } });
      if (botSettings) {
        // If multiple trades not allowed and there's an open trade
        if (!botSettings.allowMultipleTrades && activeTrades > 0) {
          return NextResponse.json({ 
            error: 'A trade is already open. Wait for it to close before opening a new one.',
            code: 'EXISTING_TRADE'
          }, { status: 403 });
        }

        // If multiple trades allowed but max positions reached
        if (botSettings.allowMultipleTrades && botSettings.maxOpenPositions > 0 && activeTrades >= botSettings.maxOpenPositions) {
          return NextResponse.json({ 
            error: `Maximum open positions (${botSettings.maxOpenPositions}) reached. Close existing trades first.`,
            code: 'MAX_POSITIONS'
          }, { status: 403 });
        }

        // Smart Trading Mode checks
        if (botSettings.smartModeEnabled) {
          // Check daily loss limit
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          const todayClosedTrades = await db.trade.findMany({
            where: {
              userId,
              status: 'CLOSED',
              closedAt: { gte: today },
            },
            select: { pnl: true },
          });
          const todayPnL = todayClosedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
          
          if (todayPnL < -botSettings.maxDailyLoss) {
            return NextResponse.json({ 
              error: `Daily loss limit ($${botSettings.maxDailyLoss}) reached. Trading paused until tomorrow.`,
              code: 'DAILY_LOSS_LIMIT'
            }, { status: 403 });
          }

          // Check low liquidity hours (pre-market: before 9:30 ET, after-hours: after 16:00 ET)
          if (botSettings.avoidLowLiquidityHours) {
            const now = new Date();
            const etHour = (now.getUTCHours() - 5 + 24) % 24; // Rough ET conversion
            if (etHour < 9.5 || etHour >= 16) {
              return NextResponse.json({ 
                error: 'Low liquidity period detected. Trading paused (pre-market/after-hours).',
                code: 'LOW_LIQUIDITY_HOURS'
              }, { status: 403 });
            }
          }
        }
      }
    }

    const settings = userId
      ? await db.botSettings.findUnique({ where: { userId } })
      : await db.botSettings.findFirst();

    // Determine instrument type
    let determinedInstrumentType = instrumentType || 'OPTION';
    if (!instrumentType) {
      if (['AAPL', 'TSLA', 'MSFT', 'GOOGL', 'AMZN'].includes(symbol)) {
        determinedInstrumentType = 'STOCK';
      } else if (['ES', 'NQ', 'YM', 'RTY', 'GC', 'SI', 'CL'].includes(symbol)) {
        determinedInstrumentType = 'FUTURE';
      } else if (symbol.includes('USD')) {
        determinedInstrumentType = 'FOREX';
      }
    }

    // Calculate auto close time
    const autoCloseAt = maxHoldingMinutes ? new Date(Date.now() + maxHoldingMinutes * 60000) : null;

    // Create trade
    const trade = await db.trade.create({
      data: {
        userId: userId || null,
        symbol,
        instrumentType: determinedInstrumentType,
        direction,
        quantity: quantity || settings?.defaultQuantity || 1,
        entryPrice: 0,
        strike: strike || null,
        optionType: optionType || (['CALL', 'PUT'].includes(direction) ? direction : null),
        expiry: expiry || '0DTE',
        status: 'PENDING',
        signalSource: 'MANUAL',
        signalTime: new Date(),
        stopLoss,
        takeProfit,
        trailingStopEnabled: trailingStopEnabled || false,
        trailingStopAmount,
        trailingStopPercent,
        isBracketOrder: isBracketOrder || false,
        maxHoldingMinutes,
        autoCloseAt,
      },
    });

    // Log
    await db.tradeLog.create({
      data: {
        tradeId: trade.id,
        action: 'CREATED',
        details: 'Manual trade created',
      },
    });

    // Send to IB if running
    if (settings?.isRunning) {
      try {
        await fetch('http://localhost:3003/trade/open', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            tradeId: trade.id,
            symbol,
            direction,
            quantity: trade.quantity,
            strike: trade.strike,
            stopLoss,
            takeProfit,
          }),
        });
      } catch {
        console.log('IB service not available');
      }
    }

    return NextResponse.json({ success: true, trade });
  } catch (error) {
    console.error('Error opening manual trade:', error);
    return NextResponse.json({ error: 'Failed to open trade' }, { status: 500 });
  }
}
