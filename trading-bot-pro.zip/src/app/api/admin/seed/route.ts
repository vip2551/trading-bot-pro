import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// POST - Seed default plans
export async function POST() {
  try {
    // Check if plans already exist
    const existingPlans = await db.plan.count();

    if (existingPlans > 0) {
      return NextResponse.json({ message: 'Plans already seeded', count: existingPlans });
    }

    // Create default plans
    const plans = await db.plan.createMany({
      data: [
        {
          name: 'TRIAL',
          displayName: 'Free Trial',
          description: 'Try all features free for 7 days',
          priceMonthly: 0,
          priceYearly: 0,
          maxTradesPerDay: 5,
          maxActiveTrades: 2,
          trialDays: 7,
          features: JSON.stringify(['basic_signals', 'telegram_notifications', 'simulation_mode']),
          isPopular: false,
          sortOrder: 0,
        },
        {
          name: 'BASIC',
          displayName: 'Basic',
          description: 'Perfect for getting started',
          priceMonthly: 29,
          priceYearly: 278, // ~20% discount
          maxTradesPerDay: 20,
          maxActiveTrades: 5,
          trialDays: 0,
          features: JSON.stringify(['trailing_stop', 'bracket_orders', 'telegram_notifications', 'paper_trading']),
          isPopular: false,
          sortOrder: 1,
        },
        {
          name: 'PRO',
          displayName: 'Pro',
          description: 'For serious traders',
          priceMonthly: 79,
          priceYearly: 758, // ~20% discount
          maxTradesPerDay: -1, // Unlimited
          maxActiveTrades: 10,
          trialDays: 0,
          features: JSON.stringify(['unlimited_trades', 'advanced_analytics', 'priority_support', 'live_trading', 'all_basic_features']),
          isPopular: true,
          sortOrder: 2,
        },
        {
          name: 'ENTERPRISE',
          displayName: 'Enterprise',
          description: 'For professional teams',
          priceMonthly: 199,
          priceYearly: 1910, // ~20% discount
          maxTradesPerDay: -1,
          maxActiveTrades: -1,
          trialDays: 0,
          features: JSON.stringify(['unlimited_everything', 'dedicated_support', 'custom_integrations', 'api_access', 'white_label']),
          isPopular: false,
          sortOrder: 3,
        },
      ],
    });

    return NextResponse.json({
      success: true,
      message: 'Default plans created',
      count: plans.count,
    });
  } catch (error) {
    console.error('Error seeding plans:', error);
    return NextResponse.json({ error: 'Failed to seed plans' }, { status: 500 });
  }
}
