import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch bot settings
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');

    if (userId) {
      // Get user-specific settings
      let settings = await db.botSettings.findUnique({
        where: { userId },
      });

      if (!settings) {
        settings = await db.botSettings.create({
          data: { userId, accountType: 'SIMULATION' },
        });
      }

      return NextResponse.json({ settings });
    } else {
      // Fallback: get first settings (for backward compatibility)
      const settings = await db.botSettings.findFirst();
      return NextResponse.json({ settings });
    }
  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

// POST - Update bot settings
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, ...settingsData } = body;

    if (userId) {
      // Update user-specific settings
      let settings = await db.botSettings.findUnique({
        where: { userId },
      });

      if (!settings) {
        settings = await db.botSettings.create({
          data: { userId, ...settingsData },
        });
      } else {
        settings = await db.botSettings.update({
          where: { userId },
          data: settingsData,
        });
      }

      return NextResponse.json({ success: true, settings });
    } else {
      // Fallback: update first settings (for backward compatibility)
      const existingSettings = await db.botSettings.findFirst();

      if (existingSettings) {
        const settings = await db.botSettings.update({
          where: { id: existingSettings.id },
          data: settingsData,
        });
        return NextResponse.json({ success: true, settings });
      }

      return NextResponse.json({ success: false, error: 'No settings found' }, { status: 404 });
    }
  } catch (error) {
    console.error('Error updating settings:', error);
    return NextResponse.json({ error: 'Failed to update settings' }, { status: 500 });
  }
}
