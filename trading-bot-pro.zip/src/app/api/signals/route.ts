import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch all TradingView signals
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const limit = parseInt(searchParams.get('limit') || '50');
    const processed = searchParams.get('processed');
    const userId = searchParams.get('userId');

    const where: { processed?: boolean; userId?: string | null } = {};
    if (processed !== null) {
      where.processed = processed === 'true';
    }
    if (userId) {
      where.userId = userId;
    }

    const signals = await db.tradingViewSignal.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
    });

    return NextResponse.json({ signals });
  } catch (error) {
    console.error('Error fetching signals:', error);
    return NextResponse.json({ error: 'Failed to fetch signals' }, { status: 500 });
  }
}
