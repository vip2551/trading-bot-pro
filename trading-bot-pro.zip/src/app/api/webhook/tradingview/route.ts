import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    console.log('Received TradingView signal:', body);

    const {
      symbol,
      action,
      strategy,
      price,
      strike,
      expiry,
      quantity,
      stop_loss,
      take_profit,
      trailing_stop_percent,
      trailing_stop_amount,
      max_holding_minutes,
    } = body;

    if (!symbol || !action) {
      return NextResponse.json(
        { error: 'Missing required fields: symbol and action' },
        { status: 400 }
      );
    }

    // Save signal
    const signal = await db.tradingViewSignal.create({
      data: {
        symbol,
        action: action.toUpperCase(),
        strategy: strategy || null,
        price: price ? parseFloat(price) : null,
        strike: strike ? parseFloat(strike) : null,
        expiry: expiry || null,
        quantity: quantity ? parseInt(quantity) : null,
        stopLoss: stop_loss ? parseFloat(stop_loss) : null,
        takeProfit: take_profit ? parseFloat(take_profit) : null,
        rawPayload: JSON.stringify(body),
        processed: false,
      },
    });

    // Get bot settings
    const settings = await db.botSettings.findFirst();

    if (settings?.isRunning) {
      // Process signal with trailing stop data
      processSignal(signal.id, settings, {
        trailingStopPercent: trailing_stop_percent ? parseFloat(trailing_stop_percent) : null,
        trailingStopAmount: trailing_stop_amount ? parseFloat(trailing_stop_amount) : null,
        maxHoldingMinutes: max_holding_minutes ? parseInt(max_holding_minutes) : null,
      }).catch(console.error);
    }

    return NextResponse.json({
      success: true,
      signalId: signal.id,
      message: 'Signal received',
    });
  } catch (error) {
    console.error('Error processing TradingView webhook:', error);
    return NextResponse.json({ error: 'Failed to process signal' }, { status: 500 });
  }
}

interface TrailingStopData {
  trailingStopPercent: number | null;
  trailingStopAmount: number | null;
  maxHoldingMinutes: number | null;
}

interface BotSettingsFull {
  id: string;
  defaultQuantity: number;
  spxStrikeOffset: number;
  spxDeltaTarget: number;
  strikeSelectionMode: string;
  contractPriceMin: number;
  contractPriceMax: number;
  positionSizeMode: string;
  positionSizePercent: number;
  positionSizeAmount: number;
  defaultExpiry: string;
  defaultStopLoss: number | null;
  defaultTakeProfit: number | null;
  accountBalance: number | null;
  telegramBotToken: string | null;
  telegramChatId: string | null;
  telegramEnabled: boolean;
  allowMultipleTrades: boolean;
  maxOpenPositions: number;
  // Smart Trading Mode
  smartModeEnabled: boolean;
  maxDailyLoss: number;
  avoidLowLiquidityHours: boolean;
  avoidNewsEvents: boolean;
  // Spread & Liquidity
  checkSpread: boolean;
  checkLiquidity: boolean;
  maxSpreadPercent: number;
  minLiquidity: number;
  maxSlippagePercent: number;
}

async function processSignal(
  signalId: string,
  settings: BotSettingsFull,
  trailingData: TrailingStopData
) {
  try {
    const signal = await db.tradingViewSignal.findUnique({ where: { id: signalId } });
    if (!signal) return;

    // Check for existing open trades (Multiple Trades Control)
    const openTradesCount = await db.trade.count({
      where: { status: 'OPEN' },
    });

    if (!settings.allowMultipleTrades && openTradesCount > 0) {
      console.log('Signal rejected: A trade is already open. allowMultipleTrades is disabled.');
      await db.tradingViewSignal.update({
        where: { id: signalId },
        data: { 
          processed: true, 
          processedAt: new Date(),
        },
      });
      return;
    }

    if (settings.allowMultipleTrades && settings.maxOpenPositions > 0 && openTradesCount >= settings.maxOpenPositions) {
      console.log(`Signal rejected: Maximum open positions (${settings.maxOpenPositions}) reached.`);
      await db.tradingViewSignal.update({
        where: { id: signalId },
        data: { 
          processed: true, 
          processedAt: new Date(),
        },
      });
      return;
    }

    // Smart Trading Mode checks
    if (settings.smartModeEnabled) {
      // Check daily loss limit
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayClosedTrades = await db.trade.findMany({
        where: {
          status: 'CLOSED',
          closedAt: { gte: today },
        },
        select: { pnl: true },
      });
      const todayPnL = todayClosedTrades.reduce((sum, t) => sum + (t.pnl || 0), 0);
      
      if (todayPnL < -settings.maxDailyLoss) {
        console.log(`Signal rejected: Daily loss limit ($${settings.maxDailyLoss}) reached.`);
        await db.tradingViewSignal.update({
          where: { id: signalId },
          data: { processed: true, processedAt: new Date() },
        });
        return;
      }

      // Check low liquidity hours
      if (settings.avoidLowLiquidityHours) {
        const now = new Date();
        const etHour = (now.getUTCHours() - 5 + 24) % 24;
        if (etHour < 9.5 || etHour >= 16) {
          console.log('Signal rejected: Low liquidity period (pre-market/after-hours).');
          await db.tradingViewSignal.update({
            where: { id: signalId },
            data: { processed: true, processedAt: new Date() },
          });
          return;
        }
      }
    }

    // Determine instrument type
    let instrumentType = 'OPTION';
    let optionType: string | null = null;

    if (['AAPL', 'TSLA', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'META'].includes(signal.symbol)) {
      instrumentType = 'STOCK';
    } else if (['ES', 'NQ', 'YM', 'RTY'].includes(signal.symbol)) {
      instrumentType = 'FUTURE';
    } else if (signal.symbol.includes('USD')) {
      instrumentType = 'FOREX';
    } else if (signal.symbol === 'SPX') {
      instrumentType = 'OPTION';
      optionType = signal.action === 'CALL' ? 'CALL' : 'PUT';
    }

    // Calculate strike based on selection mode
    let calculatedStrike = signal.strike;
    
    if (signal.symbol === 'SPX' && !signal.strike) {
      calculatedStrike = await calculateStrike(settings, signal.action);
    }

    // Calculate quantity based on position sizing mode
    let calculatedQuantity = signal.quantity || settings.defaultQuantity || 1;
    
    if (!signal.quantity) {
      calculatedQuantity = await calculatePositionSize(settings, calculatedStrike);
    }

    // Calculate auto close time
    const autoCloseAt = signal.expiry?.includes('DTE') && signal.expiry !== '0DTE'
      ? new Date(Date.now() + parseInt(signal.expiry) * 86400000)
      : null;

    // Determine stop loss and take profit
    const stopLoss = signal.stopLoss || settings.defaultStopLoss;
    const takeProfit = signal.takeProfit || settings.defaultTakeProfit;

    // Create trade
    const trade = await db.trade.create({
      data: {
        symbol: signal.symbol,
        instrumentType,
        direction: signal.action,
        quantity: calculatedQuantity,
        entryPrice: signal.price || 0,
        strike: calculatedStrike,
        optionType,
        expiry: signal.expiry || settings.defaultExpiry || '0DTE',
        status: 'PENDING',
        stopLoss,
        takeProfit,
        trailingStopEnabled: !!trailingData.trailingStopPercent || !!trailingData.trailingStopAmount,
        trailingStopPercent: trailingData.trailingStopPercent,
        trailingStopAmount: trailingData.trailingStopAmount,
        maxHoldingMinutes: trailingData.maxHoldingMinutes || (signal.expiry === '0DTE' ? 390 : null),
        autoCloseAt,
      },
    });

    // Log
    await db.tradeLog.create({
      data: {
        tradeId: trade.id,
        action: 'CREATED',
        details: `Trade from TradingView: ${signal.strategy || 'Unknown'} - Strike Mode: ${settings.strikeSelectionMode}`,
      },
    });

    // Send to IB service
    try {
      await fetch('http://localhost:3003/trade/open', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tradeId: trade.id,
          symbol: trade.symbol,
          direction: trade.direction,
          quantity: trade.quantity,
          strike: trade.strike,
          stopLoss: trade.stopLoss,
          takeProfit: trade.takeProfit,
        }),
      });
    } catch {
      console.log('IB service not available');
    }

    // Send Telegram notification
    if (settings.telegramEnabled && settings.telegramBotToken && settings.telegramChatId) {
      const emoji = signal.action === 'CALL' ? '📈' : '📉';
      const message = `${emoji} *New Trade Opened*\n\n` +
        `📊 *Symbol:* ${signal.symbol}\n` +
        `🎯 *Direction:* ${signal.action}\n` +
        `📦 *Quantity:* ${trade.quantity}\n` +
        (calculatedStrike ? `📍 *Strike:* ${calculatedStrike}\n` : '') +
        (signal.strategy ? `📋 *Strategy:* ${signal.strategy}\n` : '') +
        `💰 *Position Size:* ${settings.positionSizeMode === 'PERCENTAGE' ? `${settings.positionSizePercent}%` : `$${settings.positionSizeAmount}`}\n` +
        `⏰ *Time:* ${new Date().toLocaleString()}\n\n` +
        `_Signal from TradingView_`;

      await fetch(`https://api.telegram.org/bot${settings.telegramBotToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: settings.telegramChatId,
          text: message,
          parse_mode: 'Markdown',
        }),
      });
    }

    // Mark signal processed
    await db.tradingViewSignal.update({
      where: { id: signalId },
      data: { processed: true, processedAt: new Date(), tradeId: trade.id },
    });

  } catch (error) {
    console.error('Error processing signal:', error);
  }
}

/**
 * Calculate strike based on selection mode
 */
async function calculateStrike(settings: BotSettingsFull, action: string): Promise<number | null> {
  const mode = settings.strikeSelectionMode;
  
  // Get SPX spot price
  let spotPrice = 5800; // Default fallback
  try {
    const priceRes = await fetch('http://localhost:3003/market/spx');
    if (priceRes.ok) {
      const priceData = await priceRes.json();
      spotPrice = priceData.price;
    }
  } catch {
    console.log('Could not get SPX price, using default');
  }

  switch (mode) {
    case 'CONTRACT_PRICE':
      // Find strike where option premium is within the specified range
      return await findStrikeByContractPrice(spotPrice, action, settings.contractPriceMin, settings.contractPriceMax);
    
    case 'OFFSET':
      // Use offset from spot price
      const offset = settings.spxStrikeOffset;
      return action === 'CALL'
        ? Math.ceil((spotPrice + offset) / 5) * 5
        : Math.floor((spotPrice - offset) / 5) * 5;
    
    case 'DELTA':
      // Find strike with target delta
      return await findStrikeByDelta(spotPrice, action, settings.spxDeltaTarget);
    
    case 'MANUAL':
    default:
      // No automatic calculation, rely on webhook
      return null;
  }
}

/**
 * Find strike where contract price is within range
 * This searches for ATM or near-ATM options with premium in the target range
 */
async function findStrikeByContractPrice(
  spotPrice: number,
  action: string,
  minPrice: number,
  maxPrice: number
): Promise<number> {
  // For SPX options, premium typically decreases as we go OTM
  // ATM options usually have highest premium for same expiry
  
  // Start from ATM and search outward
  const atmStrike = Math.round(spotPrice / 5) * 5;
  
  // For CALL: we need OTM strikes (higher than spot) which have lower premium
  // For PUT: we need OTM strikes (lower than spot) which have lower premium
  
  // Simple estimation: SPX ATM option premium is roughly 1-2% of spot
  // For 0DTE, premiums can be higher
  
  // This is a simplified calculation - in production, you'd query actual option chain
  const estimatedATMPremium = spotPrice * 0.005; // ~0.5% for ATM
  
  // If we want $300-400 premium and ATM is $2900, we need to go further OTM
  // Premium decreases roughly linearly with distance from ATM
  
  // Estimate: each 5 points OTM reduces premium by ~$10-20
  const premiumPerPoint = 2; // $2 per point reduction in premium
  const targetPremium = (minPrice + maxPrice) / 2;
  
  if (estimatedATMPremium > targetPremium) {
    // Need to go OTM
    const premiumDiff = estimatedATMPremium - targetPremium;
    const pointsNeeded = premiumDiff / premiumPerPoint;
    
    if (action === 'CALL') {
      return Math.ceil((spotPrice + pointsNeeded) / 5) * 5;
    } else {
      return Math.floor((spotPrice - pointsNeeded) / 5) * 5;
    }
  } else {
    // ATM or ITM needed
    if (action === 'CALL') {
      return Math.floor((spotPrice - 5) / 5) * 5; // Slightly ITM
    } else {
      return Math.ceil((spotPrice + 5) / 5) * 5; // Slightly ITM
    }
  }
}

/**
 * Find strike with target delta
 */
async function findStrikeByDelta(
  spotPrice: number,
  action: string,
  targetDelta: number
): Promise<number> {
  // Delta approximation for options:
  // ATM Call ~ 0.50 delta
  // Each 1% OTM reduces delta by ~0.02-0.03
  
  // For 0.30 delta, we need roughly 10% OTM
  const deltaDiff = 0.50 - targetDelta; // 0.20 for 0.30 delta
  
  // Roughly 1% price move = 0.02 delta change
  const percentOTM = deltaDiff / 0.02;
  const pointsOTM = spotPrice * (percentOTM / 100);
  
  if (action === 'CALL') {
    return Math.ceil((spotPrice + pointsOTM) / 5) * 5;
  } else {
    return Math.floor((spotPrice - pointsOTM) / 5) * 5;
  }
}

/**
 * Calculate position size based on mode
 */
async function calculatePositionSize(
  settings: BotSettingsFull,
  strike: number | null
): Promise<number> {
  const mode = settings.positionSizeMode;
  
  switch (mode) {
    case 'PERCENTAGE':
      // Calculate based on account balance percentage
      const balance = settings.accountBalance || 10000;
      const tradeAmount = (balance * settings.positionSizePercent) / 100;
      
      // Estimate contracts based on premium
      // If we know the strike, estimate premium
      const estimatedPremium = strike ? 350 : 100; // Default estimate
      return Math.max(1, Math.floor(tradeAmount / estimatedPremium));
    
    case 'AMOUNT':
      // Fixed dollar amount
      const estimatedPremiumForAmount = strike ? 350 : 100;
      return Math.max(1, Math.floor(settings.positionSizeAmount / estimatedPremiumForAmount));
    
    case 'QUANTITY':
    default:
      return settings.defaultQuantity || 1;
  }
}
