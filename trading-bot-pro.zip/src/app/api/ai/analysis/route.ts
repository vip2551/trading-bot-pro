import { NextRequest, NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import { db } from '@/lib/db';

/**
 * AI Trading Analysis API
 * تحليل التداول بالذكاء الاصطناعي
 */

// Initialize ZAI
let zaiInstance: Awaited<ReturnType<typeof ZAI.create>> | null = null;

async function getZAI() {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

// GET - Get AI recommendations
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const analysisType = searchParams.get('type') || 'general';

    if (!userId) {
      return NextResponse.json({ error: 'userId required' }, { status: 400 });
    }

    // Get recent trades and settings
    const recentTrades = await db.trade.findMany({
      where: { userId },
      take: 50,
      orderBy: { createdAt: 'desc' },
    });

    const settings = await db.botSettings.findUnique({
      where: { userId },
    });

    // Calculate stats for AI context
    const closedTrades = recentTrades.filter(t => t.status === 'CLOSED');
    const wins = closedTrades.filter(t => (t.pnl || 0) > 0);
    const losses = closedTrades.filter(t => (t.pnl || 0) < 0);
    const totalPnL = closedTrades.reduce((s, t) => s + (t.pnl || 0), 0);
    const winRate = closedTrades.length ? (wins.length / closedTrades.length) * 100 : 0;

    const context = {
      totalTrades: recentTrades.length,
      closedTrades: closedTrades.length,
      wins: wins.length,
      losses: losses.length,
      winRate: winRate.toFixed(1),
      totalPnL: totalPnL.toFixed(2),
      avgPnL: closedTrades.length ? (totalPnL / closedTrades.length).toFixed(2) : '0',
      recentTrades: recentTrades.slice(0, 10).map(t => ({
        symbol: t.symbol,
        direction: t.direction,
        pnl: t.pnl,
        status: t.status,
      })),
      settings: {
        maxRiskPerTrade: settings?.maxRiskPerTrade,
        positionSizeMode: settings?.positionSizeMode,
        smartModeEnabled: settings?.smartModeEnabled,
        maxDailyLoss: settings?.maxDailyLoss,
      },
    };

    const zai = await getZAI();

    let systemPrompt = '';
    let userPrompt = '';

    switch (analysisType) {
      case 'performance':
        systemPrompt = `You are an expert trading performance analyst. Analyze the trading data and provide insights in both English and Arabic.
          Format your response in clear sections with headers.
          Be specific with numbers and percentages.
          Provide actionable recommendations.`;
        userPrompt = `Analyze my trading performance:
          
          Statistics:
          - Total Trades: ${context.totalTrades}
          - Closed Trades: ${context.closedTrades}
          - Win Rate: ${context.winRate}%
          - Total P&L: $${context.totalPnL}
          - Average P&L per trade: $${context.avgPnL}
          - Wins: ${context.wins}, Losses: ${context.losses}
          
          Recent trades: ${JSON.stringify(context.recentTrades, null, 2)}
          
          Please provide:
          1. Performance Summary (ملخص الأداء)
          2. Strengths (نقاط القوة)
          3. Areas for Improvement (مجالات التحسين)
          4. Risk Assessment (تقييم المخاطر)
          5. Specific Recommendations (توصيات محددة)`;
        break;

      case 'market':
        systemPrompt = `You are an expert SPX options trader and market analyst. Provide market analysis and trading suggestions.
          Focus on 0DTE and weekly SPX options strategies.
          Consider current market conditions and volatility.`;
        userPrompt = `Provide market analysis for SPX options trading today.
          
          Current settings:
          - Position sizing: ${context.settings.positionSizeMode}
          - Max risk per trade: $${context.settings.maxRiskPerTrade}
          - Smart mode: ${context.settings.smartModeEnabled ? 'Enabled' : 'Disabled'}
          
          My trading stats:
          - Win rate: ${context.winRate}%
          - Recent P&L: $${context.totalPnL}
          
          Please provide:
          1. Market Outlook (نظرة السوق)
          2. Recommended Strategies (الاستراتيجيات الموصى بها)
          3. Risk Levels (مستويات المخاطر)
          4. Key Levels to Watch (مستويات مهمة)
          5. Trading Tips (نصائح التداول)`;
        break;

      case 'risk':
        systemPrompt = `You are a risk management expert specializing in options trading.
          Analyze trading behavior and provide risk management recommendations.`;
        userPrompt = `Analyze my risk management:
          
          Trading statistics:
          - Total trades: ${context.totalTrades}
          - Win rate: ${context.winRate}%
          - Total P&L: $${context.totalPnL}
          - Average trade: $${context.avgPnL}
          
          Current risk settings:
          - Max risk per trade: $${context.settings.maxRiskPerTrade}
          - Daily loss limit: $${context.settings.maxDailyLoss}
          - Smart mode: ${context.settings.smartModeEnabled ? 'Yes' : 'No'}
          
          Provide:
          1. Risk Score (درجة المخاطر) (1-10)
          2. Position Sizing Analysis (تحليل حجم المركز)
          3. Drawdown Risk (مخاطر التراجع)
          4. Recommendations (توصيات)
          5. Risk Management Rules (قواعد إدارة المخاطر)`;
        break;

      default:
        systemPrompt = `You are an expert trading coach and analyst. Provide comprehensive trading guidance in both English and Arabic.
          Be encouraging but realistic. Focus on actionable advice.`;
        userPrompt = `I'm trading SPX options with the following stats:
          
          - Total trades: ${context.totalTrades}
          - Win rate: ${context.winRate}%
          - Total P&L: $${context.totalPnL}
          - Recent performance: ${context.wins} wins, ${context.losses} losses
          
          Please provide:
          1. Overall Assessment (التقييم العام)
          2. What I'm doing well (ما أفعله جيداً)
          3. What to improve (ما يجب تحسينه)
          4. Today's action plan (خطة اليوم)
          5. Motivational tip (نصيحة تحفيزية)`;
    }

    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'assistant', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
      thinking: { type: 'disabled' },
    });

    const analysis = completion.choices[0]?.message?.content;

    return NextResponse.json({
      success: true,
      analysis,
      analysisType,
      context: {
        totalTrades: context.totalTrades,
        winRate: context.winRate,
        totalPnL: context.totalPnL,
      },
    });

  } catch (error) {
    console.error('AI Analysis error:', error);
    return NextResponse.json(
      { error: 'Failed to generate analysis', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}

// POST - Get custom analysis
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, question, context: customContext } = body;

    if (!userId || !question) {
      return NextResponse.json({ error: 'userId and question required' }, { status: 400 });
    }

    // Get user's trading context
    const recentTrades = await db.trade.findMany({
      where: { userId },
      take: 20,
      orderBy: { createdAt: 'desc' },
    });

    const closedTrades = recentTrades.filter(t => t.status === 'CLOSED');
    const totalPnL = closedTrades.reduce((s, t) => s + (t.pnl || 0), 0);
    const wins = closedTrades.filter(t => (t.pnl || 0) > 0);
    const winRate = closedTrades.length ? (wins.length / closedTrades.length) * 100 : 0;

    const tradingContext = `
      Trading Context:
      - Recent trades: ${recentTrades.length}
      - Win rate: ${winRate.toFixed(1)}%
      - Total P&L: $${totalPnL.toFixed(2)}
      ${customContext ? `- Additional context: ${customContext}` : ''}
    `;

    const zai = await getZAI();

    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `You are an expert SPX options trading assistant. Provide helpful, accurate, and actionable advice in both English and Arabic. 
            Be concise but thorough. Always consider risk management.
            Format responses clearly with headers and bullet points.`,
        },
        {
          role: 'user',
          content: `${tradingContext}\n\nQuestion: ${question}`,
        },
      ],
      thinking: { type: 'disabled' },
    });

    const answer = completion.choices[0]?.message?.content;

    return NextResponse.json({
      success: true,
      answer,
      question,
    });

  } catch (error) {
    console.error('AI Q&A error:', error);
    return NextResponse.json(
      { error: 'Failed to answer question' },
      { status: 500 }
    );
  }
}
