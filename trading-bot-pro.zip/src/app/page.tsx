"use client";

import { useState, useEffect } from "react";
import { useSession, signIn, signOut } from "next-auth/react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Bot,
  Play,
  Square,
  Settings,
  TrendingUp,
  TrendingDown,
  Activity,
  DollarSign,
  Target,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Clock,
  RefreshCw,
  Send,
  Plus,
  BarChart3,
  Zap,
  Shield,
  LineChart,
  TestTube,
  FlaskConical,
  Timer,
  Gauge,
  Layers,
  Crown,
  CreditCard,
  LogOut,
  LogIn,
  User,
  Sparkles,
  Lock,
  Check,
  X,
  Bell,
  BarChart,
  PieChart,
  PlayCircle,
  Users,
  History,
  Download,
  Filter,
  Info,
  HardDrive,
  Calculator,
  Calendar,
  BookOpen,
  Share2,
  Smartphone,
  ArrowRight,
  FileText,
  Brain,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger, DialogClose } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { toast, Toaster } from "sonner";
import { PlansManager } from "@/components/plans-manager";
import { LanguageSwitcher } from "@/components/language-switcher";
import { useLanguage } from "@/lib/i18n";
import { AnalyticsDashboard } from "@/components/analytics-dashboard";
import { BacktestingPanel } from "@/components/backtesting-panel";
import { NotificationSettings } from "@/components/notification-settings";
import { SecuritySettings } from "@/components/security-settings";
import { AdminPanel } from "@/components/admin-panel";
import { TradeHistory } from "@/components/trade-history";
import { StrikeAnalyzer } from "@/components/strike-analyzer";
import { PerformanceReport } from "@/components/performance-report";
import { HealthDashboard } from "@/components/health-dashboard";
import { PriceAlertsPanel } from "@/components/price-alerts";
import { BackupPanel } from "@/components/backup-panel";
import { SimulationMode } from "@/components/simulation-mode";
import { EconomicCalendar } from "@/components/economic-calendar";
import { TradingJournal } from "@/components/trading-journal";
import { StrategyPerformance } from "@/components/strategy-performance";
import { RiskCalculator } from "@/components/risk-calculator";
import { LivePositionTracking } from "@/components/live-position-tracking";
import { TaxReports } from "@/components/tax-reports";
import { PushNotifications } from "@/components/push-notifications";
import { SocialTrading } from "@/components/social-trading";
import { WhaleTracker } from "@/components/whale-tracker";

// Types
interface Subscription {
  id: string;
  plan: string;
  status: string;
  isTrial: boolean;
  trialEndsAt: string | null;
  maxTradesPerDay: number;
  maxActiveTrades: number;
  currentPeriodEnd: string | null;
}

interface BotSettings {
  id: string;
  isRunning: boolean;
  accountType: string;
  ibHost: string;
  ibPort: number;
  ibClientId: number;
  ibConnected: boolean;
  telegramBotToken: string | null;
  telegramChatId: string | null;
  telegramEnabled: boolean;
  // Trading Configuration
  defaultQuantity: number;
  maxRiskPerTrade: number;
  defaultExpiry: string;
  // Position Sizing
  positionSizeMode: string;
  positionSizePercent: number;
  positionSizeAmount: number;
  // SPX Options Settings
  spxStrikeOffset: number;
  spxDeltaTarget: number;
  strikeSelectionMode: string;
  // Contract Price Range
  contractPriceMin: number;
  contractPriceMax: number;
  // Risk Management Defaults
  defaultStopLoss: number | null;
  defaultTakeProfit: number | null;
  // Account Info
  accountBalance: number | null;
  availableFunds: number | null;
}

interface Trade {
  id: string;
  symbol: string;
  instrumentType: string;
  direction: string;
  quantity: number;
  filledQuantity: number;
  entryPrice: number;
  exitPrice: number | null;
  strike: number | null;
  optionType: string | null;
  status: string;
  pnl: number | null;
  trailingStopEnabled: boolean;
  isBracketOrder: boolean;
  maxHoldingMinutes: number | null;
  autoCloseAt: string | null;
  openedAt: string | null;
  closedAt: string | null;
  createdAt: string;
}

interface TVSignal {
  id: string;
  symbol: string;
  action: string;
  strategy: string | null;
  processed: boolean;
  createdAt: string;
}

const ACCOUNT_CONFIGS = {
  PAPER: { name: "Paper Trading", port: 7497, color: "text-blue-500", bgColor: "bg-blue-500/10" },
  LIVE: { name: "Live Trading", port: 7496, color: "text-red-500", bgColor: "bg-red-500/10" },
  SIMULATION: { name: "Simulation", port: 0, color: "text-purple-500", bgColor: "bg-purple-500/10" },
};

const PLANS = [
  {
    id: "TRIAL",
    name: "Free Trial",
    price: 0,
    period: "7 days",
    description: "Try all features free for 7 days",
    features: ["5 trades per day", "2 active trades", "Basic signals", "Telegram notifications"],
    popular: false,
    cta: "Start Free Trial",
  },
  {
    id: "BASIC",
    name: "Basic",
    price: 29,
    period: "/month",
    description: "Perfect for getting started",
    features: ["20 trades per day", "5 active trades", "Trailing stop", "Bracket orders", "Telegram notifications"],
    popular: false,
    cta: "Subscribe",
  },
  {
    id: "PRO",
    name: "Pro",
    price: 79,
    period: "/month",
    description: "For serious traders",
    features: ["Unlimited trades", "10 active trades", "Advanced analytics", "Priority support", "All Basic features"],
    popular: true,
    cta: "Subscribe",
  },
  {
    id: "ENTERPRISE",
    name: "Enterprise",
    price: 199,
    period: "/month",
    description: "For professional teams",
    features: ["Unlimited everything", "Dedicated support", "Custom integrations", "API access", "White-label options"],
    popular: false,
    cta: "Contact Sales",
  },
];

export default function Dashboard() {
  const { data: session, status } = useSession();
  const { t, isRTL, language } = useLanguage();
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [authLoading, setAuthLoading] = useState(false);
  const [showAuth, setShowAuth] = useState(false);

  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [settings, setSettings] = useState<BotSettings | null>(null);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [signals, setSignals] = useState<TVSignal[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("dashboard");
  const [showPricing, setShowPricing] = useState(false);
  const [billingPeriod, setBillingPeriod] = useState<"MONTHLY" | "YEARLY">("MONTHLY");

  // Settings states
  const [accountType, setAccountType] = useState("PAPER");
  const [ibHost, setIbHost] = useState("127.0.0.1");
  const [ibPort, setIbPort] = useState("7497");
  const [ibClientId, setIbClientId] = useState("1");
  const [telegramToken, setTelegramToken] = useState("");
  const [telegramChatId, setTelegramChatId] = useState("");

  // Trading Configuration states
  const [defaultQuantity, setDefaultQuantity] = useState("1");
  const [maxRiskPerTrade, setMaxRiskPerTrade] = useState("100");
  const [defaultExpiry, setDefaultExpiry] = useState("0DTE");
  // Position Sizing
  const [positionSizeMode, setPositionSizeMode] = useState("AMOUNT");
  const [positionSizePercent, setPositionSizePercent] = useState("5");
  const [positionSizeAmount, setPositionSizeAmount] = useState("500");
  // Strike Selection
  const [spxStrikeOffset, setSpxStrikeOffset] = useState("5");
  const [spxDeltaTarget, setSpxDeltaTarget] = useState("0.30");
  const [strikeSelectionMode, setStrikeSelectionMode] = useState("CONTRACT_PRICE");
  const [contractPriceMin, setContractPriceMin] = useState("300");
  const [contractPriceMax, setContractPriceMax] = useState("400");
  // Risk Management
  const [defaultStopLoss, setDefaultStopLoss] = useState("");
  const [defaultTakeProfit, setDefaultTakeProfit] = useState("");
  // Account Info
  const [accountBalance, setAccountBalance] = useState<number | null>(null);

  // Multiple Trades Control
  const [allowMultipleTrades, setAllowMultipleTrades] = useState(false);
  const [maxOpenPositions, setMaxOpenPositions] = useState("1");

  // Spread & Liquidity Control
  const [checkSpread, setCheckSpread] = useState(true);
  const [checkLiquidity, setCheckLiquidity] = useState(true);
  const [maxSpreadPercent, setMaxSpreadPercent] = useState("5");
  const [minLiquidity, setMinLiquidity] = useState("100");
  const [maxSlippage, setMaxSlippage] = useState("1");

  // Smart Trading Mode
  const [smartModeEnabled, setSmartModeEnabled] = useState(false);
  const [maxDailyLoss, setMaxDailyLoss] = useState("500");
  const [avoidLowLiquidityHours, setAvoidLowLiquidityHours] = useState(true);
  const [avoidNewsEvents, setAvoidNewsEvents] = useState(false);

  // Trade states
  const [manualSymbol, setManualSymbol] = useState("SPX");
  const [manualDirection, setManualDirection] = useState("CALL");
  const [manualQty, setManualQty] = useState("1");
  const [manualStrike, setManualStrike] = useState("");
  const [enableTrailing, setEnableTrailing] = useState(false);
  const [trailingType, setTrailingType] = useState<"percent" | "fixed">("percent");
  const [trailingValue, setTrailingValue] = useState("5");
  const [enableBracket, setEnableBracket] = useState(false);
  const [bracketSL, setBracketSL] = useState("");
  const [bracketTP, setBracketTP] = useState("");
  const [enableTimeExit, setEnableTimeExit] = useState(false);
  const [holdingMinutes, setHoldingMinutes] = useState("60");

  // Confirm states
  const [showLiveConfirm, setShowLiveConfirm] = useState(false);
  const [liveConfirmed, setLiveConfirmed] = useState(false);
  const [stats, setStats] = useState({ total: 0, open: 0, winRate: 0, pnl: 0 });

  // Auth handlers
  const handleAuth = async () => {
    setAuthLoading(true);
    try {
      if (authMode === "register") {
        const res = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password, name }),
        });
        const d = await res.json();
        if (d.success) {
          toast.success("Account created! Please sign in.");
          setAuthMode("login");
        } else {
          toast.error(d.error || "Registration failed");
        }
      } else {
        const result = await signIn("credentials", {
          email,
          password,
          redirect: false,
        });
        if (result?.error) {
          toast.error("Invalid credentials");
        } else {
          toast.success("Welcome back!");
          setShowAuth(false);
        }
      }
    } catch (e) {
      toast.error("Authentication failed");
    }
    setAuthLoading(false);
  };

  const handleSignOut = async () => {
    await signOut({ redirect: false });
    setSubscription(null);
    setSettings(null);
    setTrades([]);
    setSignals([]);
  };

  // Fetch data
  const fetchData = async () => {
    if (!session?.user?.id) return;
    try {
      const [subRes, sRes, tRes, sigRes] = await Promise.all([
        fetch(`/api/subscription?userId=${session.user.id}`),
        fetch(`/api/settings?userId=${session.user.id}`),
        fetch(`/api/trades?userId=${session.user.id}`),
        fetch(`/api/signals?userId=${session.user.id}`),
      ]);
      const [subData, sData, tData, sigData] = await Promise.all([
        subRes.json(),
        sRes.json(),
        tRes.json(),
        sigRes.json(),
      ]);

      if (subData.subscription) setSubscription(subData.subscription);
      if (sData.settings) {
        setSettings(sData.settings);
        setAccountType(sData.settings.accountType || "PAPER");
        setIbHost(sData.settings.ibHost);
        setIbPort(String(sData.settings.ibPort));
        setIbClientId(String(sData.settings.ibClientId));
        setTelegramToken(sData.settings.telegramBotToken || "");
        setTelegramChatId(sData.settings.telegramChatId || "");
        // Trading Configuration
        setDefaultQuantity(String(sData.settings.defaultQuantity || 1));
        setMaxRiskPerTrade(String(sData.settings.maxRiskPerTrade || 100));
        setDefaultExpiry(sData.settings.defaultExpiry || "0DTE");
        // Position Sizing
        setPositionSizeMode(sData.settings.positionSizeMode || "AMOUNT");
        setPositionSizePercent(String(sData.settings.positionSizePercent || 5));
        setPositionSizeAmount(String(sData.settings.positionSizeAmount || 500));
        // Strike Selection
        setSpxStrikeOffset(String(sData.settings.spxStrikeOffset || 5));
        setSpxDeltaTarget(String(sData.settings.spxDeltaTarget || 0.3));
        setStrikeSelectionMode(sData.settings.strikeSelectionMode || "CONTRACT_PRICE");
        setContractPriceMin(String(sData.settings.contractPriceMin || 300));
        setContractPriceMax(String(sData.settings.contractPriceMax || 400));
        // Risk Management
        setDefaultStopLoss(sData.settings.defaultStopLoss ? String(sData.settings.defaultStopLoss) : "");
        setDefaultTakeProfit(sData.settings.defaultTakeProfit ? String(sData.settings.defaultTakeProfit) : "");
        // Account Info
        setAccountBalance(sData.settings.accountBalance || null);
        // Multiple Trades
        setAllowMultipleTrades(sData.settings.allowMultipleTrades || false);
        setMaxOpenPositions(String(sData.settings.maxOpenPositions || 1));
        // Spread & Liquidity
        setCheckSpread(sData.settings.checkSpread ?? true);
        setCheckLiquidity(sData.settings.checkLiquidity ?? true);
        setMaxSpreadPercent(String(sData.settings.maxSpreadPercent || 5));
        setMinLiquidity(String(sData.settings.minLiquidity || 100));
        setMaxSlippage(String(sData.settings.maxSlippagePercent || 1));
      }
      setTrades(tData.trades || []);
      setSignals(sigData.signals || []);

      const closed = (tData.trades || []).filter((t: Trade) => t.status === "CLOSED");
      const wins = closed.filter((t: Trade) => (t.pnl || 0) > 0).length;
      setStats({
        total: tData.trades?.length || 0,
        open: tData.trades?.filter((t: Trade) => t.status === "OPEN").length || 0,
        winRate: closed.length ? (wins / closed.length) * 100 : 0,
        pnl: closed.reduce((s: number, t: Trade) => s + (t.pnl || 0), 0),
      });
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (session?.user) {
      setLoading(true);
      fetchData().then(() => setLoading(false));
      const iv = setInterval(fetchData, 10000);
      return () => clearInterval(iv);
    }
  }, [session]);

  // Check subscription access
  const hasAccess = () => {
    if (!subscription) return false;
    if (subscription.status !== "ACTIVE") return false;
    if (subscription.isTrial && subscription.trialEndsAt) {
      return new Date(subscription.trialEndsAt) > new Date();
    }
    return true;
  };

  const getTrialDaysLeft = () => {
    if (!subscription?.trialEndsAt) return 0;
    const ms = new Date(subscription.trialEndsAt).getTime() - Date.now();
    return Math.max(0, Math.ceil(ms / (1000 * 60 * 60 * 24)));
  };

  // Subscription handler
  const handleSubscribe = async (planId: string) => {
    if (planId === "TRIAL") {
      toast.info("Trial already active!");
      return;
    }
    if (planId === "ENTERPRISE") {
      toast.info("Please contact us for enterprise pricing");
      return;
    }

    try {
      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: session?.user?.id,
          plan: planId,
          billingPeriod,
        }),
      });
      const d = await res.json();
      if (d.url) {
        window.open(d.url, '_self');
      } else {
        toast.error(d.error || "Failed to create checkout");
      }
    } catch (e) {
      toast.error("Failed to start checkout");
    }
  };

  // Bot controls
  const startBot = async () => {
    const res = await fetch("/api/bot/start", { method: "POST" });
    const d = await res.json();
    if (d.success) toast.success("Started!"); else toast.error(d.error);
    fetchData();
  };

  const stopBot = async () => {
    const res = await fetch("/api/bot/stop", { method: "POST" });
    const d = await res.json();
    if (d.success) toast.success("Stopped!"); else toast.error(d.error);
    fetchData();
  };

  const connectIB = async () => {
    const res = await fetch("/api/ib/connect", { method: "POST" });
    const d = await res.json();
    if (d.success) toast.success("Connected!"); else toast.error(d.error);
    fetchData();
  };

  const testTelegram = async () => {
    const res = await fetch("/api/telegram/test", { method: "POST" });
    const d = await res.json();
    if (d.success) toast.success("Message sent!"); else toast.error(d.error);
  };

  const openTrade = async () => {
    if (!hasAccess()) {
      toast.error("Subscription required");
      return;
    }
    const res = await fetch("/api/trades/manual", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: session?.user?.id,
        symbol: manualSymbol,
        direction: manualDirection,
        quantity: parseInt(manualQty),
        strike: manualStrike ? parseFloat(manualStrike) : null,
        trailingStopEnabled: enableTrailing,
        trailingStopType: trailingType,
        trailingStopValue: parseFloat(trailingValue),
        isBracketOrder: enableBracket,
        stopLoss: bracketSL ? parseFloat(bracketSL) : null,
        takeProfit: bracketTP ? parseFloat(bracketTP) : null,
        maxHoldingMinutes: enableTimeExit ? parseInt(holdingMinutes) : null,
      }),
    });
    const d = await res.json();
    if (d.success) toast.success("Trade opened!"); else toast.error(d.error);
    fetchData();
  };

  const closeTrade = async (id: string) => {
    await fetch(`/api/trades/${id}/close`, { method: "POST" });
    toast.success("Closed!");
    fetchData();
  };

  const saveSettings = async () => {
    await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: session?.user?.id,
        accountType,
        ibHost,
        ibPort: parseInt(ibPort),
        ibClientId: parseInt(ibClientId),
        telegramBotToken: telegramToken,
        telegramChatId: telegramChatId,
        // Trading Configuration
        defaultQuantity: parseInt(defaultQuantity),
        maxRiskPerTrade: parseFloat(maxRiskPerTrade),
        defaultExpiry,
        // Position Sizing
        positionSizeMode,
        positionSizePercent: parseFloat(positionSizePercent),
        positionSizeAmount: parseFloat(positionSizeAmount),
        // Strike Selection
        spxStrikeOffset: parseInt(spxStrikeOffset),
        spxDeltaTarget: parseFloat(spxDeltaTarget),
        strikeSelectionMode,
        contractPriceMin: parseFloat(contractPriceMin),
        contractPriceMax: parseFloat(contractPriceMax),
        // Risk Management
        defaultStopLoss: defaultStopLoss ? parseFloat(defaultStopLoss) : null,
        defaultTakeProfit: defaultTakeProfit ? parseFloat(defaultTakeProfit) : null,
        // Multiple Trades
        allowMultipleTrades,
        maxOpenPositions: parseInt(maxOpenPositions),
        // Spread & Liquidity
        checkSpread,
        checkLiquidity,
        maxSpreadPercent: parseFloat(maxSpreadPercent),
        minLiquidity: parseInt(minLiquidity),
        maxSlippagePercent: parseFloat(maxSlippage),
        // Smart Trading Mode
        smartModeEnabled,
        maxDailyLoss: parseFloat(maxDailyLoss),
        avoidLowLiquidityHours,
        avoidNewsEvents,
      }),
    });
    toast.success("Settings saved successfully!");
    fetchData();
  };

  const changeAccountType = async (type: string) => {
    if (type === "LIVE" && accountType !== "LIVE") {
      setShowLiveConfirm(true);
      return;
    }
    await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accountType: type, ibPort: ACCOUNT_CONFIGS[type as keyof typeof ACCOUNT_CONFIGS].port }),
    });
    setAccountType(type);
    setIbPort(String(ACCOUNT_CONFIGS[type as keyof typeof ACCOUNT_CONFIGS].port));
    fetchData();
  };

  // Helpers
  const getDirIcon = (d: string) =>
    d === "CALL" || d === "BUY" ? <TrendingUp className="h-4 w-4 text-green-500" /> : <TrendingDown className="h-4 w-4 text-red-500" />;

  const getStatusColor = (s: string) => {
    switch (s) {
      case "ACTIVE":
        return "bg-green-500/10 text-green-500";
      case "EXPIRED":
      case "CANCELLED":
        return "bg-red-500/10 text-red-500";
      case "PAST_DUE":
        return "bg-yellow-500/10 text-yellow-500";
      default:
        return "bg-gray-500/10 text-gray-500";
    }
  };

  const getPlanBadge = (plan: string) => {
    switch (plan) {
      case "PRO":
        return <Badge className="bg-gradient-to-r from-purple-500 to-pink-500">PRO</Badge>;
      case "ENTERPRISE":
        return <Badge className="bg-gradient-to-r from-amber-500 to-orange-500">ENTERPRISE</Badge>;
      case "BASIC":
        return <Badge className="bg-blue-500/10 text-blue-500">BASIC</Badge>;
      default:
        return <Badge className="bg-gray-500/10 text-gray-500">TRIAL</Badge>;
    }
  };

  const timeRemaining = (d: string | null) => {
    if (!d) return null;
    const ms = new Date(d).getTime() - Date.now();
    if (ms <= 0) return "Expired";
    return `${Math.floor(ms / 60000)}m`;
  };

  const cfg = ACCOUNT_CONFIGS[accountType as keyof typeof ACCOUNT_CONFIGS];

  // Loading state
  if (status === "loading" || (session && loading)) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  // Not authenticated - Show Landing Page
  if (!session) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 flex flex-col">
        <Toaster position="top-right" />

        {/* Header */}
        <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bot className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold">Trading Bot Pro</h1>
            </div>
            <Button onClick={() => setShowAuth(true)}>
              <LogIn className="h-4 w-4 mr-2" /> Sign In
            </Button>
          </div>
        </header>

        {/* Hero Section */}
        <main className="container mx-auto px-4 py-16 flex-1">
          <div className="text-center max-w-4xl mx-auto mb-16">
            <Badge className="mb-4 bg-gradient-to-r from-green-500 to-emerald-500">
              <Sparkles className="h-3 w-3 mr-1" /> 7-Day Free Trial
            </Badge>
            <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-foreground to-foreground/70 bg-clip-text">
              Automate Your Trading
              <br />
              <span className="text-primary">With AI-Powered Signals</span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8">
              Connect TradingView strategies to Interactive Brokers. Get instant Telegram notifications.
              Trade stocks, options, futures, and forex automatically.
            </p>
            <div className="flex gap-4 justify-center">
              <Button size="lg" className="text-lg px-8" onClick={() => setShowAuth(true)}>
                Start Free Trial <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8" onClick={() => setShowPricing(true)}>
                View Pricing
              </Button>
            </div>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto mb-16">
            {[
              { icon: Zap, title: "TradingView Integration", desc: "Receive signals from any TradingView strategy via webhooks" },
              { icon: Bot, title: "Auto Execution", desc: "Execute trades automatically on Interactive Brokers" },
              { icon: Send, title: "Telegram Alerts", desc: "Get instant notifications for all trade events" },
            ].map((f, i) => (
              <Card key={i} className="text-center">
                <CardContent className="pt-6">
                  <f.icon className="h-12 w-12 mx-auto mb-4 text-primary" />
                  <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                  <p className="text-muted-foreground">{f.desc}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Pricing Preview */}
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-8">Simple, Transparent Pricing</h3>
            <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
              {PLANS.slice(0, 3).map((plan) => (
                <Card key={plan.id} className={plan.popular ? "border-primary relative" : ""}>
                  {plan.popular && (
                    <Badge className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary">
                      Most Popular
                    </Badge>
                  )}
                  <CardHeader className="text-center">
                    <CardTitle>{plan.name}</CardTitle>
                    <div className="text-3xl font-bold">
                      ${billingPeriod === "YEARLY" ? Math.round(plan.price * 12 * 0.8) : plan.price}
                      <span className="text-base font-normal text-muted-foreground">
                        {billingPeriod === "YEARLY" ? "/year" : plan.period}
                      </span>
                    </div>
                    <CardDescription>{plan.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {plan.features.map((f, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm">
                          <Check className="h-4 w-4 text-green-500" />
                          {f}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button
                      className="w-full"
                      variant={plan.popular ? "default" : "outline"}
                      onClick={() => setShowAuth(true)}
                    >
                      {plan.cta}
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
            <div className="mt-6">
              <Button variant="ghost" onClick={() => setBillingPeriod(billingPeriod === "MONTHLY" ? "YEARLY" : "MONTHLY")}>
                Save 20% with yearly billing
              </Button>
            </div>
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t py-6 bg-background/80">
          <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
            <p>Trading Bot Pro © 2024. All rights reserved.</p>
          </div>
        </footer>

        {/* Auth Dialog */}
        <Dialog open={showAuth} onOpenChange={setShowAuth}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>{authMode === "login" ? "Sign In" : "Create Account"}</DialogTitle>
              <DialogDescription>
                {authMode === "login"
                  ? "Sign in to access your trading dashboard"
                  : "Start your 7-day free trial today"}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {authMode === "register" && (
                <div>
                  <Label>Name</Label>
                  <Input
                    placeholder="Your name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
              )}
              <div>
                <Label>Email</Label>
                <Input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div>
                <Label>Password</Label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>
            <DialogFooter className="flex-col gap-2">
              <Button className="w-full" onClick={handleAuth} disabled={authLoading}>
                {authLoading ? <RefreshCw className="h-4 w-4 animate-spin mr-2" /> : null}
                {authMode === "login" ? "Sign In" : "Create Account"}
              </Button>
              <Button
                variant="ghost"
                className="w-full"
                onClick={() => setAuthMode(authMode === "login" ? "register" : "login")}
              >
                {authMode === "login" ? "Need an account? Sign up" : "Already have an account? Sign in"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // Authenticated - Show Dashboard
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/20 flex flex-col">
      <Toaster position="top-right" />

      {/* Trial Banner */}
      {subscription?.isTrial && getTrialDaysLeft() > 0 && (
        <div className="bg-gradient-to-r from-primary/10 to-primary/5 border-b py-2 px-4 text-center text-sm">
          <Sparkles className="h-4 w-4 inline mr-2 text-primary" />
          You have <strong>{getTrialDaysLeft()} days</strong> left in your free trial.
          <Button variant="link" className="px-2" onClick={() => setShowPricing(true)}>
            Upgrade Now
          </Button>
        </div>
      )}

      {/* Expired Banner */}
      {subscription && !hasAccess() && (
        <div className="bg-red-500/10 border-b py-2 px-4 text-center text-sm text-red-500">
          <AlertTriangle className="h-4 w-4 inline mr-2" />
          Your subscription has expired.{" "}
          <Button variant="link" className="px-2 text-red-500" onClick={() => setShowPricing(true)}>
            Renew Now
          </Button>
        </div>
      )}

      {/* Live Confirm Dialog */}
      <AlertDialog open={showLiveConfirm} onOpenChange={setShowLiveConfirm}>
        <AlertDialogContent className="border-red-500/50">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-red-500 flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" /> Warning: Live Account
            </AlertDialogTitle>
            <AlertDialogDescription>
              <p className="text-red-500 font-semibold mb-3">You are switching to LIVE trading!</p>
              <ul className="list-disc list-inside space-y-1 text-sm mb-4">
                <li>Real money at risk</li>
                <li>Test on paper first</li>
                <li>Use proper risk management</li>
              </ul>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={liveConfirmed}
                  onChange={(e) => setLiveConfirmed(e.target.checked)}
                  className="h-4 w-4"
                />
                <span className="text-sm">I understand the risks</span>
              </label>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setShowLiveConfirm(false)}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={!liveConfirmed}
              onClick={() => {
                changeAccountType("LIVE");
                setShowLiveConfirm(false);
                setLiveConfirmed(false);
              }}
              className="bg-red-600"
            >
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Pricing Dialog */}
      <Dialog open={showPricing} onOpenChange={setShowPricing}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl">Choose Your Plan</DialogTitle>
            <DialogDescription>
              Select the plan that best fits your trading needs
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center mb-4">
            <div className="bg-muted rounded-lg p-1 flex">
              <Button
                variant={billingPeriod === "MONTHLY" ? "default" : "ghost"}
                size="sm"
                onClick={() => setBillingPeriod("MONTHLY")}
              >
                Monthly
              </Button>
              <Button
                variant={billingPeriod === "YEARLY" ? "default" : "ghost"}
                size="sm"
                onClick={() => setBillingPeriod("YEARLY")}
              >
                Yearly <Badge className="ml-2 bg-green-500">Save 20%</Badge>
              </Button>
            </div>
          </div>
          <div className="grid md:grid-cols-4 gap-4">
            {PLANS.map((plan) => (
              <Card key={plan.id} className={plan.popular ? "border-primary relative" : ""}>
                {plan.popular && (
                  <Badge className="absolute -top-2 left-1/2 -translate-x-1/2 bg-primary">
                    Popular
                  </Badge>
                )}
                <CardHeader className="text-center pb-2">
                  <CardTitle className="text-lg">{plan.name}</CardTitle>
                  <div className="text-2xl font-bold">
                    ${billingPeriod === "YEARLY" ? Math.round(plan.price * 12 * 0.8) : plan.price}
                    <span className="text-sm font-normal text-muted-foreground">
                      {billingPeriod === "YEARLY" ? "/yr" : plan.period}
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <ul className="space-y-1 text-xs">
                    {plan.features.map((f, i) => (
                      <li key={i} className="flex items-center gap-1">
                        <Check className="h-3 w-3 text-green-500 shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button
                    className="w-full"
                    variant={plan.popular ? "default" : "outline"}
                    size="sm"
                    onClick={() => handleSubscribe(plan.id)}
                    disabled={subscription?.plan === plan.id && plan.id !== "TRIAL"}
                  >
                    {subscription?.plan === plan.id ? "Current Plan" : plan.cta}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Bot className="h-7 w-7 text-primary" />
              {settings?.isRunning && <span className="absolute -top-1 -right-1 h-2 w-2 bg-green-500 rounded-full animate-pulse" />}
            </div>
            <div>
              <h1 className="text-xl font-bold">Trading Bot Pro</h1>
              <div className="flex items-center gap-2">
                {getPlanBadge(subscription?.plan || "TRIAL")}
              </div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <LanguageSwitcher />
            <Select value={accountType} onValueChange={changeAccountType}>
              <SelectTrigger className="w-36" />
              <SelectContent>
                <SelectItem value="SIMULATION"><FlaskConical className="h-4 w-4 mr-2 inline text-purple-500" />{t('simulation')}</SelectItem>
                <SelectItem value="PAPER"><TestTube className="h-4 w-4 mr-2 inline text-blue-500" />{t('paperTrading')}</SelectItem>
                <SelectItem value="LIVE"><AlertTriangle className="h-4 w-4 mr-2 inline text-red-500" />{t('liveTrading')}</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline" size="icon" onClick={() => setShowPricing(true)}>
              <Crown className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={handleSignOut}>
              <LogOut className="h-4 w-4" />
            </Button>
            {settings?.isRunning ? (
              <Button variant="destructive" size="sm" onClick={stopBot}><Square className="h-4 w-4 mr-1" />{t('stop')}</Button>
            ) : (
              <Button size="sm" onClick={startBot} className="bg-green-600"><Play className="h-4 w-4 mr-1" />{t('start')}</Button>
            )}
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="container mx-auto px-4 py-6 flex-1">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="flex-wrap h-auto gap-1">
            <TabsTrigger value="dashboard"><Activity className="h-4 w-4 mr-2" />{t('dashboard')}</TabsTrigger>
            <TabsTrigger value="analytics"><BarChart3 className="h-4 w-4 mr-2" />{t('analytics')}</TabsTrigger>
            <TabsTrigger value="trades"><LineChart className="h-4 w-4 mr-2" />{t('trades')}</TabsTrigger>
            <TabsTrigger value="history"><History className="h-4 w-4 mr-2" />{t('tradeHistory')}</TabsTrigger>
            <TabsTrigger value="simulation"><FlaskConical className="h-4 w-4 mr-2" />{t('simulation')}</TabsTrigger>
            <TabsTrigger value="calendar"><Calendar className="h-4 w-4 mr-2" />{t('calendar')}</TabsTrigger>
            <TabsTrigger value="journal"><BookOpen className="h-4 w-4 mr-2" />{t('journal')}</TabsTrigger>
            <TabsTrigger value="strategies"><PieChart className="h-4 w-4 mr-2" />{t('strategies')}</TabsTrigger>
            <TabsTrigger value="risk"><Calculator className="h-4 w-4 mr-2" />{t('riskManagement')}</TabsTrigger>
            <TabsTrigger value="positions"><Target className="h-4 w-4 mr-2" />{t('positions')}</TabsTrigger>
            <TabsTrigger value="signals"><Zap className="h-4 w-4 mr-2" />{t('signals')}</TabsTrigger>
            <TabsTrigger value="strikes"><Target className="h-4 w-4 mr-2" />{t('strikeAnalyzer')}</TabsTrigger>
            <TabsTrigger value="performance"><BarChart className="h-4 w-4 mr-2" />{t('performanceSummary')}</TabsTrigger>
            <TabsTrigger value="alerts"><Bell className="h-4 w-4 mr-2" />{t('priceAlerts')}</TabsTrigger>
            <TabsTrigger value="webhook"><RefreshCw className="h-4 w-4 mr-2" />{t('webhook')}</TabsTrigger>
            <TabsTrigger value="tax"><FileText className="h-4 w-4 mr-2" />{t('tax')}</TabsTrigger>
            <TabsTrigger value="social"><Share2 className="h-4 w-4 mr-2" />{t('social')}</TabsTrigger>
            <TabsTrigger value="whales"><Brain className="h-4 w-4 mr-2" />{t('whales')}</TabsTrigger>
            <TabsTrigger value="push"><Smartphone className="h-4 w-4 mr-2" />{t('push')}</TabsTrigger>
            <TabsTrigger value="health"><Activity className="h-4 w-4 mr-2" />{t('healthStatus')}</TabsTrigger>
            <TabsTrigger value="backup"><HardDrive className="h-4 w-4 mr-2" />{t('backup')}</TabsTrigger>
            <TabsTrigger value="backtest"><PlayCircle className="h-4 w-4 mr-2" />{t('backtest')}</TabsTrigger>
            <TabsTrigger value="settings"><Settings className="h-4 w-4 mr-2" />{t('settings')}</TabsTrigger>
            <TabsTrigger value="notifications"><Send className="h-4 w-4 mr-2" />{t('notifications')}</TabsTrigger>
            <TabsTrigger value="security"><Shield className="h-4 w-4 mr-2" />{t('security')}</TabsTrigger>
            <TabsTrigger value="plans"><Crown className="h-4 w-4 mr-2" />{t('plans')}</TabsTrigger>
            {session?.user?.isAdmin && (
              <TabsTrigger value="admin"><Users className="h-4 w-4 mr-2" />{t('admin')}</TabsTrigger>
            )}
          </TabsList>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { l: t('totalTrades'), v: stats.total, i: BarChart3 },
                { l: t('openTrades'), v: stats.open, i: Activity, c: "text-blue-500" },
                { l: t('winRate'), v: `${stats.winRate.toFixed(1)}%`, i: Target },
                { l: t('totalPnL'), v: `$${stats.pnl.toFixed(2)}`, i: DollarSign, c: stats.pnl >= 0 ? "text-green-500" : "text-red-500" },
              ].map((s, i) => (
                <Card key={i}>
                  <CardContent className="p-4 flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground">{s.l}</p>
                      <p className={`text-2xl font-bold ${s.c || ""}`}>{s.v}</p>
                    </div>
                    <s.i className={`h-8 w-8 ${s.c || "text-muted-foreground"}`} />
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Active Trades & Signals */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader><CardTitle className="flex items-center gap-2"><Activity className="h-5 w-5" />Active Trades</CardTitle></CardHeader>
                <CardContent>
                  <ScrollArea className="h-72">
                    {trades.filter(t => t.status === "OPEN").length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full py-8 text-muted-foreground">
                        <Shield className="h-12 w-12 mb-2" /><p>No active trades</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {trades.filter(t => t.status === "OPEN").map(t => (
                          <div key={t.id} className="p-3 rounded-lg border bg-muted/30">
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                {getDirIcon(t.direction)}
                                <span className="font-semibold">{t.symbol}</span>
                                {t.strike && <Badge variant="outline">{t.strike}</Badge>}
                              </div>
                              <Button size="sm" variant="destructive" onClick={() => closeTrade(t.id)}>Close</Button>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {t.trailingStopEnabled && <Badge className="bg-cyan-500/10 text-cyan-500 text-xs"><Gauge className="h-3 w-3 mr-1" />TS</Badge>}
                              {t.isBracketOrder && <Badge className="bg-orange-500/10 text-orange-500 text-xs"><Layers className="h-3 w-3 mr-1" />Bracket</Badge>}
                              {t.maxHoldingMinutes && <Badge className="bg-violet-500/10 text-violet-500 text-xs"><Timer className="h-3 w-3 mr-1" />{timeRemaining(t.autoCloseAt)}</Badge>}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><CardTitle className="flex items-center gap-2"><Zap className="h-5 w-5" />Recent Signals</CardTitle></CardHeader>
                <CardContent>
                  <ScrollArea className="h-72">
                    {signals.length === 0 ? (
                      <div className="flex flex-col items-center justify-center h-full py-8 text-muted-foreground">
                        <Zap className="h-12 w-12 mb-2" /><p>No signals yet</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        {signals.slice(0, 10).map(s => (
                          <div key={s.id} className="p-3 rounded-lg border bg-muted/30 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {getDirIcon(s.action)}
                              <span className="font-medium">{s.symbol}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              {s.processed ? <CheckCircle className="h-4 w-4 text-green-500" /> : <Clock className="h-4 w-4 text-yellow-500" />}
                              <span className="text-xs text-muted-foreground">{new Date(s.createdAt).toLocaleTimeString()}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Trades */}
          <TabsContent value="trades" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold">Trade History</h2>
              <Dialog>
                <DialogTrigger asChild>
                  <Button disabled={!hasAccess()}>
                    <Plus className="h-4 w-4 mr-2" />Manual Trade
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Open Manual Trade</DialogTitle></DialogHeader>
                  <div className="grid gap-4 py-4">
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label>Symbol</Label>
                      <Select value={manualSymbol} onValueChange={setManualSymbol}>
                        <SelectTrigger className="col-span-3" />
                        <SelectContent>
                          <SelectItem value="SPX">SPX</SelectItem>
                          <SelectItem value="ES">ES</SelectItem>
                          <SelectItem value="GC">GC</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label>Direction</Label>
                      <Select value={manualDirection} onValueChange={setManualDirection}>
                        <SelectTrigger className="col-span-3" />
                        <SelectContent>
                          <SelectItem value="CALL">CALL</SelectItem>
                          <SelectItem value="PUT">PUT</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label>Qty</Label>
                      <Input type="number" value={manualQty} onChange={e => setManualQty(e.target.value)} className="col-span-3" />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label>Strike</Label>
                      <Input type="number" placeholder="Auto" value={manualStrike} onChange={e => setManualStrike(e.target.value)} className="col-span-3" />
                    </div>
                    <Separator />
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2"><Gauge className="h-4 w-4 text-cyan-500" /><Label>Trailing Stop</Label></div>
                      <Switch checked={enableTrailing} onCheckedChange={setEnableTrailing} />
                    </div>
                    {enableTrailing && (
                      <div className="grid grid-cols-4 items-center gap-4 pl-6">
                        <Select value={trailingType} onValueChange={v => setTrailingType(v as "percent" | "fixed")}>
                          <SelectTrigger />
                          <SelectContent>
                            <SelectItem value="percent">%</SelectItem>
                            <SelectItem value="fixed">$</SelectItem>
                          </SelectContent>
                        </Select>
                        <Input type="number" value={trailingValue} onChange={e => setTrailingValue(e.target.value)} className="col-span-3" />
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2"><Layers className="h-4 w-4 text-orange-500" /><Label>Bracket (SL/TP)</Label></div>
                      <Switch checked={enableBracket} onCheckedChange={setEnableBracket} />
                    </div>
                    {enableBracket && (
                      <div className="grid grid-cols-2 gap-4 pl-6">
                        <div><Label className="text-xs text-red-500">Stop Loss</Label><Input type="number" value={bracketSL} onChange={e => setBracketSL(e.target.value)} /></div>
                        <div><Label className="text-xs text-green-500">Take Profit</Label><Input type="number" value={bracketTP} onChange={e => setBracketTP(e.target.value)} /></div>
                      </div>
                    )}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2"><Timer className="h-4 w-4 text-violet-500" /><Label>Time Exit</Label></div>
                      <Switch checked={enableTimeExit} onCheckedChange={setEnableTimeExit} />
                    </div>
                    {enableTimeExit && (
                      <div className="grid grid-cols-4 items-center gap-4 pl-6">
                        <Label className="text-xs">Min</Label>
                        <Input type="number" value={holdingMinutes} onChange={e => setHoldingMinutes(e.target.value)} className="col-span-3" />
                      </div>
                    )}
                  </div>
                  <DialogFooter><Button onClick={openTrade}>Open Trade</Button></DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
            <Card>
              <CardContent className="p-0">
                <ScrollArea className="h-80">
                  <table className="w-full">
                    <thead className="sticky top-0 bg-background"><tr className="border-b">
                      <th className="text-left p-2">Symbol</th><th className="text-left p-2">Dir</th><th className="text-left p-2">Entry</th><th className="text-left p-2">P&L</th><th className="text-left p-2">Status</th>
                    </tr></thead>
                    <tbody>
                      {trades.map(t => (
                        <tr key={t.id} className="border-b hover:bg-muted/30">
                          <td className="p-2 font-medium">{t.symbol}</td>
                          <td className="p-2">{getDirIcon(t.direction)} {t.direction}</td>
                          <td className="p-2 font-mono">${t.entryPrice.toFixed(2)}</td>
                          <td className={`p-2 font-mono ${(t.pnl || 0) >= 0 ? "text-green-500" : "text-red-500"}`}>${(t.pnl || 0).toFixed(2)}</td>
                          <td className="p-2"><Badge className={getStatusColor(t.status)}>{t.status}</Badge></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Signals */}
          <TabsContent value="signals" className="space-y-6">
            <h2 className="text-xl font-bold">TradingView Signals</h2>
            <Card><CardContent className="p-0">
              <ScrollArea className="h-80">
                <div className="p-4 space-y-2">
                  {signals.length === 0 ? <div className="text-center py-8 text-muted-foreground"><Zap className="h-12 w-12 mx-auto mb-2" /><p>No signals yet</p></div> : signals.map(s => (
                    <div key={s.id} className="p-3 rounded-lg border bg-muted/30 flex items-center justify-between">
                      <div className="flex items-center gap-3">{getDirIcon(s.action)}<span className="font-bold">{s.symbol}</span></div>
                      <Badge className={s.processed ? "bg-green-500/10 text-green-500" : "bg-yellow-500/10 text-yellow-500"}>
                        {s.processed ? <CheckCircle className="h-3 w-3 mr-1" /> : <Clock className="h-3 w-3 mr-1" />}{s.processed ? "Done" : "Pending"}
                      </Badge>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent></Card>
          </TabsContent>

          {/* Trade History */}
          <TabsContent value="history" className="space-y-6">
            <h2 className="text-xl font-bold">{t('tradeHistory')}</h2>
            <TradeHistory trades={trades} onCloseTrade={closeTrade} />
          </TabsContent>

          {/* Strike Analyzer */}
          <TabsContent value="strikes" className="space-y-6">
            <h2 className="text-xl font-bold">{t('strikeAnalyzer')}</h2>
            <StrikeAnalyzer
              spotPrice={accountBalance ? 5800 : 5800}
              contractPriceMin={parseFloat(contractPriceMin)}
              contractPriceMax={parseFloat(contractPriceMax)}
              targetDelta={parseFloat(spxDeltaTarget)}
            />
          </TabsContent>

          {/* Performance Report */}
          <TabsContent value="performance" className="space-y-6">
            <h2 className="text-xl font-bold">{t('performanceSummary')}</h2>
            <PerformanceReport trades={trades} accountBalance={accountBalance || undefined} />
          </TabsContent>

          {/* Settings */}
          <TabsContent value="settings" className="space-y-6">
            <h2 className="text-xl font-bold">Settings</h2>
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader><CardTitle>Interactive Brokers</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4">
                    <div className="grid grid-cols-3 items-center gap-4"><Label>Host</Label><Input value={ibHost} onChange={e => setIbHost(e.target.value)} className="col-span-2" disabled={accountType === "SIMULATION"} /></div>
                    <div className="grid grid-cols-3 items-center gap-4"><Label>Port</Label><Input value={ibPort} onChange={e => setIbPort(e.target.value)} className="col-span-2" disabled={accountType === "SIMULATION"} /></div>
                    <div className="grid grid-cols-3 items-center gap-4"><Label>Client ID</Label><Input value={ibClientId} onChange={e => setIbClientId(e.target.value)} className="col-span-2" disabled={accountType === "SIMULATION"} /></div>
                  </div>
                  {accountType !== "SIMULATION" && <Button onClick={connectIB}>Connect</Button>}
                </CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle>Telegram</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid gap-4">
                    <div className="grid grid-cols-3 items-center gap-4"><Label>Token</Label><Input type="password" value={telegramToken} onChange={e => setTelegramToken(e.target.value)} className="col-span-2" /></div>
                    <div className="grid grid-cols-3 items-center gap-4"><Label>Chat ID</Label><Input value={telegramChatId} onChange={e => setTelegramChatId(e.target.value)} className="col-span-2" /></div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" onClick={testTelegram}><Send className="h-4 w-4 mr-2" />Test</Button>
                    <Button variant="outline" onClick={saveSettings}>Save</Button>
                  </div>
                </CardContent>
              </Card>
              {/* Trading Configuration */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="h-5 w-5 text-primary" /> Trading Configuration
                  </CardTitle>
                  <CardDescription>Configure position sizing and strike selection for automated trading</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Position Sizing */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                      <DollarSign className="h-4 w-4" /> Position Sizing (تحديد حجم الصفقة)
                    </h4>
                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <Label className="text-xs">Sizing Mode</Label>
                        <Select value={positionSizeMode} onValueChange={setPositionSizeMode}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="AMOUNT">مبلغ ثابت ($)</SelectItem>
                            <SelectItem value="PERCENTAGE">نسبة من المحفظة (%)</SelectItem>
                            <SelectItem value="QUANTITY">عدد عقود ثابت</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      {positionSizeMode === "AMOUNT" && (
                        <div>
                          <Label className="text-xs">مبلغ التداول ($)</Label>
                          <Input 
                            type="number" 
                            value={positionSizeAmount} 
                            onChange={e => setPositionSizeAmount(e.target.value)} 
                            placeholder="500"
                          />
                          <p className="text-xs text-muted-foreground mt-1">البوت سيشتري عقود بقيمة هذا المبلغ</p>
                        </div>
                      )}
                      
                      {positionSizeMode === "PERCENTAGE" && (
                        <div>
                          <Label className="text-xs">نسبة من المحفظة (%)</Label>
                          <Input 
                            type="number" 
                            step="0.5"
                            value={positionSizePercent} 
                            onChange={e => setPositionSizePercent(e.target.value)} 
                            placeholder="5"
                          />
                          <p className="text-xs text-muted-foreground mt-1">
                            مثال: 5% من رصيد $10,000 = $500
                          </p>
                        </div>
                      )}
                      
                      {positionSizeMode === "QUANTITY" && (
                        <div>
                          <Label className="text-xs">عدد العقود</Label>
                          <Input 
                            type="number" 
                            value={defaultQuantity} 
                            onChange={e => setDefaultQuantity(e.target.value)} 
                            min="1"
                          />
                          <p className="text-xs text-muted-foreground mt-1">عدد ثابت من العقود لكل صفقة</p>
                        </div>
                      )}
                      
                      <div>
                        <Label className="text-xs">Default Expiry</Label>
                        <Select value={defaultExpiry} onValueChange={setDefaultExpiry}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="0DTE">0DTE (نفس اليوم)</SelectItem>
                            <SelectItem value="WEEKLY">أسبوعي</SelectItem>
                            <SelectItem value="MONTHLY">شهري</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    {/* Account Balance Display */}
                    {accountBalance && (
                      <div className="p-3 rounded-lg bg-muted/50">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">رصيد الحساب:</span>
                          <span className="font-bold">${accountBalance?.toLocaleString()}</span>
                        </div>
                        {positionSizeMode === "PERCENTAGE" && (
                          <div className="flex items-center justify-between text-sm mt-1">
                            <span className="text-muted-foreground">حجم الصفقة:</span>
                            <span className="font-bold text-primary">
                              ${((accountBalance * parseFloat(positionSizePercent)) / 100).toFixed(2)}
                            </span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  <Separator />

                  {/* Strike Selection */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                      <Target className="h-4 w-4" /> Strike Selection (اختيار الاسترايك)
                    </h4>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-xs">Selection Mode</Label>
                        <Select value={strikeSelectionMode} onValueChange={setStrikeSelectionMode}>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="CONTRACT_PRICE">سعر العقد (موصى به)</SelectItem>
                            <SelectItem value="OFFSET">Offset from Spot</SelectItem>
                            <SelectItem value="DELTA">Delta Target</SelectItem>
                            <SelectItem value="MANUAL">Manual (Webhook)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    {/* Contract Price Range */}
                    {strikeSelectionMode === "CONTRACT_PRICE" && (
                      <div className="p-4 rounded-lg border border-primary/20 bg-primary/5">
                        <h5 className="text-sm font-medium mb-3">نطاق سعر العقد المطلوب</h5>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label className="text-xs">الحد الأدنى ($)</Label>
                            <Input 
                              type="number" 
                              value={contractPriceMin} 
                              onChange={e => setContractPriceMin(e.target.value)} 
                              placeholder="300"
                            />
                          </div>
                          <div>
                            <Label className="text-xs">الحد الأقصى ($)</Label>
                            <Input 
                              type="number" 
                              value={contractPriceMax} 
                              onChange={e => setContractPriceMax(e.target.value)} 
                              placeholder="400"
                            />
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground mt-3">
                          💡 البوت سيبحث عن استرايك قريب من سعر SPX الحالي بحيث يكون سعر العقد (Premium) بين {contractPriceMin}$ و {contractPriceMax}$
                        </p>
                      </div>
                    )}
                    
                    {/* Offset Mode */}
                    {strikeSelectionMode === "OFFSET" && (
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label className="text-xs">Strike Offset (points)</Label>
                          <Input 
                            type="number" 
                            value={spxStrikeOffset} 
                            onChange={e => setSpxStrikeOffset(e.target.value)} 
                          />
                          <p className="text-xs text-muted-foreground mt-1">+5 = 5 نقاط فوق السعر الحالي</p>
                        </div>
                      </div>
                    )}
                    
                    {/* Delta Mode */}
                    {strikeSelectionMode === "DELTA" && (
                      <div>
                        <Label className="text-xs">Target Delta</Label>
                        <Input 
                          type="number" 
                          step="0.05"
                          value={spxDeltaTarget} 
                          onChange={e => setSpxDeltaTarget(e.target.value)} 
                        />
                        <p className="text-xs text-muted-foreground mt-1">0.30 = 30 delta options</p>
                      </div>
                    )}
                  </div>

                  <Separator />

                  {/* Risk Management Defaults */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                      <Shield className="h-4 w-4" /> Risk Management (إدارة المخاطر)
                    </h4>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label className="text-xs">Stop Loss الافتراضي ($)</Label>
                        <Input 
                          type="number" 
                          value={defaultStopLoss} 
                          onChange={e => setDefaultStopLoss(e.target.value)} 
                          placeholder="اختياري"
                        />
                      </div>
                      <div>
                        <Label className="text-xs">Take Profit الافتراضي ($)</Label>
                        <Input 
                          type="number" 
                          value={defaultTakeProfit} 
                          onChange={e => setDefaultTakeProfit(e.target.value)} 
                          placeholder="اختياري"
                        />
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Multiple Trades Control */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                      <Layers className="h-4 w-4" /> {t('multipleTradesControl')} (التحكم في الصفقات المتعددة)
                    </h4>
                    <div className="p-4 rounded-lg border border-primary/20 bg-primary/5">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <Label className="font-medium">{t('allowMultipleTrades')}</Label>
                          <p className="text-xs text-muted-foreground mt-1">
                            {allowMultipleTrades 
                              ? t('multipleTradesModeDescription').replace('{max}', maxOpenPositions)
                              : t('singleTradeModeDescription')
                            }
                          </p>
                        </div>
                        <Switch
                          checked={allowMultipleTrades}
                          onCheckedChange={setAllowMultipleTrades}
                        />
                      </div>
                      
                      {allowMultipleTrades && (
                        <div className="mt-4 p-3 rounded-lg bg-muted/50">
                          <div className="flex items-center justify-between">
                            <Label className="text-xs">{t('maxOpenPositions')}</Label>
                            <div className="flex items-center gap-2">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setMaxOpenPositions(Math.max(1, parseInt(maxOpenPositions) - 1).toString())}
                                disabled={parseInt(maxOpenPositions) <= 1}
                              >
                                -
                              </Button>
                              <span className="w-8 text-center font-bold">{maxOpenPositions}</span>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => setMaxOpenPositions((parseInt(maxOpenPositions) + 1).toString())}
                                disabled={parseInt(maxOpenPositions) >= 10}
                              >
                                +
                              </Button>
                            </div>
                          </div>
                          <p className="text-xs text-muted-foreground mt-2">
                            {t('maxOpenPositionsDescription')}
                          </p>
                        </div>
                      )}
                      
                      {!allowMultipleTrades && (
                        <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-500/10 text-amber-600 text-sm">
                          <AlertTriangle className="h-4 w-4 shrink-0" />
                          <span>{t('existingTradeWarning')}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <Separator />

                  {/* Spread & Liquidity Control */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                      <Gauge className="h-4 w-4" /> {t('spreadLiquidity')} (السبريد والسيولة)
                    </h4>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="p-4 rounded-lg border">
                        <div className="flex items-center justify-between mb-3">
                          <Label className="text-sm font-medium">{t('spreadCheck')}</Label>
                          <Switch checked={checkSpread} onCheckedChange={setCheckSpread} />
                        </div>
                        {checkSpread && (
                          <div className="space-y-2">
                            <Label className="text-xs">{t('maxSpread')}</Label>
                            <div className="flex items-center gap-2">
                              <Input
                                type="number"
                                value={maxSpreadPercent}
                                onChange={e => setMaxSpreadPercent(e.target.value)}
                                className="w-20"
                              />
                              <span className="text-sm text-muted-foreground">%</span>
                            </div>
                            <p className="text-xs text-muted-foreground">{t('spreadDescription')}</p>
                          </div>
                        )}
                      </div>
                      
                      <div className="p-4 rounded-lg border">
                        <div className="flex items-center justify-between mb-3">
                          <Label className="text-sm font-medium">{t('liquidityCheck')}</Label>
                          <Switch checked={checkLiquidity} onCheckedChange={setCheckLiquidity} />
                        </div>
                        {checkLiquidity && (
                          <div className="space-y-2">
                            <Label className="text-xs">{t('minLiquidityRequired')}</Label>
                            <div className="flex items-center gap-2">
                              <Input
                                type="number"
                                value={minLiquidity}
                                onChange={e => setMinLiquidity(e.target.value)}
                                className="w-24"
                              />
                              <span className="text-sm text-muted-foreground">{t('contractsCount')}</span>
                            </div>
                            <p className="text-xs text-muted-foreground">{t('liquidityDescription')}</p>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="p-4 rounded-lg border border-blue-500/20 bg-blue-500/5">
                      <div className="flex items-center justify-between">
                        <div>
                          <Label className="text-sm font-medium">{t('maxSlippage')}</Label>
                          <p className="text-xs text-muted-foreground mt-1">{t('slippageDescription')}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            step="0.1"
                            value={maxSlippage}
                            onChange={e => setMaxSlippage(e.target.value)}
                            className="w-20"
                          />
                          <span className="text-sm text-muted-foreground">%</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <Separator />

                  {/* Smart Trading Mode */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-sm text-muted-foreground flex items-center gap-2">
                      <Sparkles className="h-4 w-4" /> {t('smartTradingMode')} (وضع التداول الذكي)
                    </h4>
                    <div className="p-4 rounded-lg border border-primary/20 bg-primary/5">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <Label className="font-medium">{t('enableSmartMode')}</Label>
                          <p className="text-xs text-muted-foreground mt-1">{t('smartTradingModeDescription')}</p>
                        </div>
                        <Switch checked={smartModeEnabled} onCheckedChange={setSmartModeEnabled} />
                      </div>

                      {smartModeEnabled && (
                        <div className="space-y-4 mt-4">
                          {/* Daily Loss Limit */}
                          <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20">
                            <div className="flex items-center gap-2 mb-2">
                              <AlertTriangle className="h-4 w-4 text-red-500" />
                              <Label className="text-sm font-medium text-red-600">{t('dailyLossProtection')}</Label>
                            </div>
                            <div className="flex items-center gap-2">
                              <Label className="text-xs">{t('maxDailyLossLimit')}</Label>
                              <Input
                                type="number"
                                value={maxDailyLoss}
                                onChange={e => setMaxDailyLoss(e.target.value)}
                                className="w-24"
                              />
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">{t('maxDailyLossDescription')}</p>
                          </div>

                          {/* Avoid Low Liquidity Hours */}
                          <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                            <div>
                              <Label className="text-sm">{t('avoidLowLiquidityHours')}</Label>
                              <p className="text-xs text-muted-foreground">{t('avoidLowLiquidityHoursDescription')}</p>
                            </div>
                            <Switch checked={avoidLowLiquidityHours} onCheckedChange={setAvoidLowLiquidityHours} />
                          </div>

                          {/* Avoid News Events */}
                          <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                            <div>
                              <Label className="text-sm">{t('avoidNewsEvents')}</Label>
                              <p className="text-xs text-muted-foreground">{t('avoidNewsEventsDescription')}</p>
                            </div>
                            <Switch checked={avoidNewsEvents} onCheckedChange={setAvoidNewsEvents} />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex justify-end">
                    <Button onClick={saveSettings} className="bg-green-600 hover:bg-green-700">
                      <Check className="h-4 w-4 mr-2" /> حفظ الإعدادات
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="h-5 w-5 text-primary" /> Subscription
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Current Plan: {getPlanBadge(subscription?.plan || "TRIAL")}</p>
                      {subscription?.isTrial && subscription.trialEndsAt && (
                        <p className="text-sm text-muted-foreground">
                          Trial ends: {new Date(subscription.trialEndsAt).toLocaleDateString()}
                        </p>
                      )}
                      {subscription?.currentPeriodEnd && !subscription.isTrial && (
                        <p className="text-sm text-muted-foreground">
                          Renews: {new Date(subscription.currentPeriodEnd).toLocaleDateString()}
                        </p>
                      )}
                    </div>
                    <Button onClick={() => setShowPricing(true)}>
                      <CreditCard className="h-4 w-4 mr-2" /> Manage Subscription
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Webhook */}
          <TabsContent value="webhook" className="space-y-6">
            <h2 className="text-xl font-bold">TradingView Webhook</h2>
            <Card>
              <CardHeader><CardTitle>Webhook URL</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-lg bg-muted font-mono text-sm break-all">
                  {typeof window !== "undefined" ? `${window.location.origin}/api/webhook/tradingview` : "/api/webhook/tradingview"}
                </div>
                <Button variant="outline" onClick={() => {
                  navigator.clipboard.writeText(`${window.location.origin}/api/webhook/tradingview`);
                  toast.success("Copied!");
                }}>Copy URL</Button>
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>JSON Format</CardTitle></CardHeader>
              <CardContent>
                <pre className="p-4 rounded-lg bg-muted overflow-x-auto text-sm">
{`{
  "symbol": "SPX",
  "action": "CALL",
  "quantity": 1,
  "strike": 5800,
  "stop_loss": 5750,
  "take_profit": 5850,
  "trailing_stop_percent": 5,
  "max_holding_minutes": 60
}`}
                </pre>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Plans */}
          <TabsContent value="plans" className="space-y-6">
            <PlansManager />
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-6">
            <AnalyticsDashboard userId={session?.user?.id || ""} />
          </TabsContent>

          {/* Backtest */}
          <TabsContent value="backtest" className="space-y-6">
            <BacktestingPanel userId={session?.user?.id || ""} />
          </TabsContent>

          {/* Notifications */}
          <TabsContent value="notifications" className="space-y-6">
            <NotificationSettings userId={session?.user?.id || ""} />
          </TabsContent>

          {/* Price Alerts */}
          <TabsContent value="alerts" className="space-y-6">
            <PriceAlertsPanel />
          </TabsContent>

          {/* Health Monitoring */}
          <TabsContent value="health" className="space-y-6">
            <HealthDashboard />
          </TabsContent>

          {/* Backup */}
          <TabsContent value="backup" className="space-y-6">
            <BackupPanel />
          </TabsContent>

          {/* Security */}
          <TabsContent value="security" className="space-y-6">
            <SecuritySettings
              userId={session?.user?.id || ""}
              email={session?.user?.email || ""}
              emailVerified={false}
              twoFactorEnabled={false}
            />
          </TabsContent>

          {/* Admin */}
          {session?.user?.isAdmin && (
            <TabsContent value="admin" className="space-y-6">
              <AdminPanel isAdmin={true} />
            </TabsContent>
          )}

          {/* Simulation Mode */}
          <TabsContent value="simulation" className="space-y-6">
            <SimulationMode />
          </TabsContent>

          {/* Economic Calendar */}
          <TabsContent value="calendar" className="space-y-6">
            <EconomicCalendar />
          </TabsContent>

          {/* Trading Journal */}
          <TabsContent value="journal" className="space-y-6">
            <TradingJournal trades={trades} />
          </TabsContent>

          {/* Strategy Performance */}
          <TabsContent value="strategies" className="space-y-6">
            <StrategyPerformance trades={trades} />
          </TabsContent>

          {/* Risk Calculator */}
          <TabsContent value="risk" className="space-y-6">
            <RiskCalculator />
          </TabsContent>

          {/* Live Position Tracking */}
          <TabsContent value="positions" className="space-y-6">
            <LivePositionTracking trades={trades.filter(t => t.status === 'OPEN')} />
          </TabsContent>

          {/* Tax Reports */}
          <TabsContent value="tax" className="space-y-6">
            <TaxReports trades={trades} />
          </TabsContent>

          {/* Social Trading */}
          <TabsContent value="social" className="space-y-6">
            <SocialTrading />
          </TabsContent>

          {/* Whale Tracker */}
          <TabsContent value="whales" className="space-y-6">
            <WhaleTracker />
          </TabsContent>

          {/* Push Notifications */}
          <TabsContent value="push" className="space-y-6">
            <PushNotifications />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t py-4 bg-background/80">
        <div className="container mx-auto px-4 flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center gap-4">
            <span>Trading Bot Pro</span>
            {getPlanBadge(subscription?.plan || "TRIAL")}
          </div>
          <span>{session.user?.email}</span>
        </div>
      </footer>
    </div>
  );
}


