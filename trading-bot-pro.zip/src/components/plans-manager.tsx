"use client";

import { useState, useEffect } from "react";
import {
  Crown,
  Plus,
  Edit,
  Trash2,
  Save,
  X,
  RefreshCw,
  DollarSign,
  TrendingUp,
  Layers,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";

interface Plan {
  id: string;
  name: string;
  displayName: string;
  description: string | null;
  priceMonthly: number;
  priceYearly: number;
  currency: string;
  maxTradesPerDay: number;
  maxActiveTrades: number;
  trialDays: number;
  features: string | null;
  isPopular: boolean;
  isActive: boolean;
  sortOrder: number;
}

export function PlansManager() {
  const [plans, setPlans] = useState<Plan[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingPlan, setEditingPlan] = useState<Plan | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [newPlan, setNewPlan] = useState<Partial<Plan>>({
    name: "",
    displayName: "",
    description: "",
    priceMonthly: 0,
    priceYearly: 0,
    maxTradesPerDay: 5,
    maxActiveTrades: 2,
    trialDays: 0,
    isPopular: false,
  });

  const fetchPlans = async () => {
    try {
      const res = await fetch("/api/plans");
      const data = await res.json();
      setPlans(data.plans || []);
    } catch (e) {
      console.error(e);
      toast.error("Failed to load plans");
    }
    setLoading(false);
  };

  useEffect(() => {
    const loadPlans = async () => {
      try {
        const res = await fetch("/api/plans");
        const data = await res.json();
        setPlans(data.plans || []);
      } catch (e) {
        console.error(e);
      }
      setLoading(false);
    };
    loadPlans();
  }, []);

  const seedPlans = async () => {
    try {
      const res = await fetch("/api/admin/seed", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        toast.success("Default plans created!");
        fetchPlans();
      } else {
        toast.info(data.message || "Plans already exist");
      }
    } catch (e) {
      toast.error("Failed to seed plans");
    }
  };

  const updatePlan = async (planId: string, updates: Partial<Plan>) => {
    try {
      const res = await fetch(`/api/plans/${planId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updates),
      });
      const data = await res.json();
      if (data.success) {
        toast.success("Plan updated!");
        fetchPlans();
      } else {
        toast.error(data.error || "Failed to update");
      }
    } catch (e) {
      toast.error("Failed to update plan");
    }
  };

  const deletePlan = async (planId: string) => {
    try {
      const res = await fetch(`/api/plans/${planId}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        toast.success("Plan deleted!");
        fetchPlans();
      }
    } catch (e) {
      toast.error("Failed to delete plan");
    }
  };

  const createPlan = async () => {
    try {
      const res = await fetch("/api/plans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newPlan),
      });
      const data = await res.json();
      if (data.success) {
        toast.success("Plan created!");
        setShowAddDialog(false);
        setNewPlan({
          name: "",
          displayName: "",
          description: "",
          priceMonthly: 0,
          priceYearly: 0,
          maxTradesPerDay: 5,
          maxActiveTrades: 2,
          trialDays: 0,
          isPopular: false,
        });
        fetchPlans();
      } else {
        toast.error(data.error || "Failed to create");
      }
    } catch (e) {
      toast.error("Failed to create plan");
    }
  };

  const saveEdit = async () => {
    if (!editingPlan) return;
    await updatePlan(editingPlan.id, editingPlan);
    setShowEditDialog(false);
    setEditingPlan(null);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <RefreshCw className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Subscription Plans</h2>
          <p className="text-muted-foreground">Manage your pricing plans and limits</p>
        </div>
        <div className="flex gap-2">
          {plans.length === 0 && (
            <Button variant="outline" onClick={seedPlans}>
              <RefreshCw className="h-4 w-4 mr-2" /> Load Defaults
            </Button>
          )}
          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="h-4 w-4 mr-2" /> Add Plan
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {plans.map((plan) => (
          <Card key={plan.id} className={`relative ${plan.isPopular ? "border-primary" : ""}`}>
            {plan.isPopular && (
              <Badge className="absolute -top-2 left-1/2 -translate-x-1/2 bg-primary">
                Popular
              </Badge>
            )}
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{plan.displayName}</CardTitle>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => {
                      setEditingPlan(plan);
                      setShowEditDialog(true);
                    }}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-red-500"
                    onClick={() => deletePlan(plan.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-baseline gap-1">
                <span className="text-3xl font-bold">${plan.priceMonthly}</span>
                <span className="text-muted-foreground">/month</span>
              </div>
              <div className="text-sm text-muted-foreground">
                Yearly: ${plan.priceYearly}/year
              </div>

              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="flex items-center gap-1">
                  <TrendingUp className="h-4 w-4 text-green-500" />
                  <span>
                    {plan.maxTradesPerDay === -1 ? "∞" : plan.maxTradesPerDay} daily
                  </span>
                </div>
                <div className="flex items-center gap-1">
                  <Layers className="h-4 w-4 text-blue-500" />
                  <span>
                    {plan.maxActiveTrades === -1 ? "∞" : plan.maxActiveTrades} active
                  </span>
                </div>
              </div>

              {plan.trialDays > 0 && (
                <Badge className="bg-green-500/10 text-green-500">
                  {plan.trialDays} days trial
                </Badge>
              )}

              <div className="flex items-center justify-between pt-2">
                <span className="text-sm text-muted-foreground">Active</span>
                <Switch
                  checked={plan.isActive}
                  onCheckedChange={(checked) => updatePlan(plan.id, { isActive: checked })}
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Plan</DialogTitle>
          </DialogHeader>
          {editingPlan && (
            <div className="space-y-4">
              <div className="grid gap-2">
                <Label>Display Name</Label>
                <Input
                  value={editingPlan.displayName}
                  onChange={(e) => setEditingPlan({ ...editingPlan, displayName: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label>Description</Label>
                <Input
                  value={editingPlan.description || ""}
                  onChange={(e) => setEditingPlan({ ...editingPlan, description: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Monthly Price ($)</Label>
                  <Input
                    type="number"
                    value={editingPlan.priceMonthly}
                    onChange={(e) => setEditingPlan({ ...editingPlan, priceMonthly: parseFloat(e.target.value) })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label>Yearly Price ($)</Label>
                  <Input
                    type="number"
                    value={editingPlan.priceYearly}
                    onChange={(e) => setEditingPlan({ ...editingPlan, priceYearly: parseFloat(e.target.value) })}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Daily Trades (-1 = ∞)</Label>
                  <Input
                    type="number"
                    value={editingPlan.maxTradesPerDay}
                    onChange={(e) => setEditingPlan({ ...editingPlan, maxTradesPerDay: parseInt(e.target.value) })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label>Active Trades (-1 = ∞)</Label>
                  <Input
                    type="number"
                    value={editingPlan.maxActiveTrades}
                    onChange={(e) => setEditingPlan({ ...editingPlan, maxActiveTrades: parseInt(e.target.value) })}
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label>Trial Days</Label>
                <Input
                  type="number"
                  value={editingPlan.trialDays}
                  onChange={(e) => setEditingPlan({ ...editingPlan, trialDays: parseInt(e.target.value) })}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label>Mark as Popular</Label>
                <Switch
                  checked={editingPlan.isPopular}
                  onCheckedChange={(checked) => setEditingPlan({ ...editingPlan, isPopular: checked })}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditDialog(false)}>Cancel</Button>
            <Button onClick={saveEdit}><Save className="h-4 w-4 mr-2" />Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Add New Plan</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>Plan ID (e.g., BASIC)</Label>
                <Input
                  value={newPlan.name || ""}
                  onChange={(e) => setNewPlan({ ...newPlan, name: e.target.value.toUpperCase() })}
                />
              </div>
              <div className="grid gap-2">
                <Label>Display Name</Label>
                <Input
                  value={newPlan.displayName || ""}
                  onChange={(e) => setNewPlan({ ...newPlan, displayName: e.target.value })}
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label>Description</Label>
              <Input
                value={newPlan.description || ""}
                onChange={(e) => setNewPlan({ ...newPlan, description: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>Monthly Price ($)</Label>
                <Input
                  type="number"
                  value={newPlan.priceMonthly || 0}
                  onChange={(e) => setNewPlan({ ...newPlan, priceMonthly: parseFloat(e.target.value) })}
                />
              </div>
              <div className="grid gap-2">
                <Label>Yearly Price ($)</Label>
                <Input
                  type="number"
                  value={newPlan.priceYearly || 0}
                  onChange={(e) => setNewPlan({ ...newPlan, priceYearly: parseFloat(e.target.value) })}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label>Daily Trades</Label>
                <Input
                  type="number"
                  value={newPlan.maxTradesPerDay || 5}
                  onChange={(e) => setNewPlan({ ...newPlan, maxTradesPerDay: parseInt(e.target.value) })}
                />
              </div>
              <div className="grid gap-2">
                <Label>Active Trades</Label>
                <Input
                  type="number"
                  value={newPlan.maxActiveTrades || 2}
                  onChange={(e) => setNewPlan({ ...newPlan, maxActiveTrades: parseInt(e.target.value) })}
                />
              </div>
            </div>
            <div className="grid gap-2">
              <Label>Trial Days</Label>
              <Input
                type="number"
                value={newPlan.trialDays || 0}
                onChange={(e) => setNewPlan({ ...newPlan, trialDays: parseInt(e.target.value) })}
              />
            </div>
            <div className="flex items-center justify-between">
              <Label>Mark as Popular</Label>
              <Switch
                checked={newPlan.isPopular || false}
                onCheckedChange={(checked) => setNewPlan({ ...newPlan, isPopular: checked })}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Cancel</Button>
            <Button onClick={createPlan}><Plus className="h-4 w-4 mr-2" />Create</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
