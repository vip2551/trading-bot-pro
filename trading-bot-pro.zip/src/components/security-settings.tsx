"use client";

import { useState } from "react";
import {
  Shield,
  Key,
  Mail,
  Smartphone,
  RefreshCw,
  Check,
  AlertTriangle,
  QrCode,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";

interface SecuritySettingsProps {
  userId: string;
  email: string;
  emailVerified: boolean;
  twoFactorEnabled: boolean;
}

export function SecuritySettings({ userId, email, emailVerified, twoFactorEnabled: initial2FA }: SecuritySettingsProps) {
  const [loading, setLoading] = useState(false);
  const [emailVerifiedState, setEmailVerifiedState] = useState(emailVerified);
  const [twoFactorEnabled, setTwoFactorEnabled] = useState(initial2FA);
  
  // 2FA Setup
  const [show2FADialog, setShow2FADialog] = useState(false);
  const [qrCode, setQrCode] = useState("");
  const [secret, setSecret] = useState("");
  const [verificationCode, setVerificationCode] = useState("");

  // Password Reset
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [resetEmail, setResetEmail] = useState(email);

  const sendVerificationEmail = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/auth/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success("Verification email sent! Check your inbox.");
      } else {
        toast.error(data.error || "Failed to send email");
      }
    } catch (e) {
      toast.error("Failed to send verification email");
    }
    setLoading(false);
  };

  const setup2FA = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/auth/2fa", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      const data = await res.json();
      if (data.success) {
        setQrCode(data.qrCode);
        setSecret(data.secret);
        setShow2FADialog(true);
      } else {
        toast.error(data.error || "Failed to setup 2FA");
      }
    } catch (e) {
      toast.error("Failed to setup 2FA");
    }
    setLoading(false);
  };

  const verify2FA = async () => {
    if (!verificationCode || verificationCode.length < 6) {
      toast.error("Enter 6-digit code");
      return;
    }
    
    setLoading(true);
    try {
      const res = await fetch("/api/auth/2fa", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, secret, token: verificationCode }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success("2FA enabled successfully!");
        setTwoFactorEnabled(true);
        setShow2FADialog(false);
        setVerificationCode("");
      } else {
        toast.error(data.error || "Invalid code");
      }
    } catch (e) {
      toast.error("Failed to verify 2FA");
    }
    setLoading(false);
  };

  const disable2FA = async () => {
    if (!confirm("Are you sure you want to disable 2FA?")) return;
    
    setLoading(true);
    try {
      const res = await fetch("/api/auth/2fa", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success("2FA disabled");
        setTwoFactorEnabled(false);
      } else {
        toast.error(data.error || "Failed to disable 2FA");
      }
    } catch (e) {
      toast.error("Failed to disable 2FA");
    }
    setLoading(false);
  };

  const requestPasswordReset = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/auth/reset-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: resetEmail }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success("Password reset email sent!");
        setShowResetDialog(false);
      } else {
        toast.error(data.error || "Failed to send reset email");
      }
    } catch (e) {
      toast.error("Failed to send reset email");
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Shield className="h-6 w-6 text-primary" />
        <h2 className="text-2xl font-bold">Security Settings</h2>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Email Verification */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Mail className="h-5 w-5 text-blue-500" />
              <CardTitle>Email Verification</CardTitle>
            </div>
            <CardDescription>Verify your email address</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
              <div className="flex items-center gap-2">
                <span className="text-sm">{email}</span>
                {emailVerifiedState ? (
                  <Badge className="bg-green-500/10 text-green-500">
                    <Check className="h-3 w-3 mr-1" /> Verified
                  </Badge>
                ) : (
                  <Badge className="bg-yellow-500/10 text-yellow-500">
                    <AlertTriangle className="h-3 w-3 mr-1" /> Not Verified
                  </Badge>
                )}
              </div>
            </div>
            {!emailVerifiedState && (
              <Button
                variant="outline"
                className="w-full"
                onClick={sendVerificationEmail}
                disabled={loading}
              >
                {loading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Mail className="h-4 w-4 mr-2" />}
                Send Verification Email
              </Button>
            )}
          </CardContent>
        </Card>

        {/* Two-Factor Authentication */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Smartphone className="h-5 w-5 text-purple-500" />
              <CardTitle>Two-Factor Auth</CardTitle>
            </div>
            <CardDescription>Add extra security to your account</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-lg bg-muted">
              <span>2FA Status</span>
              {twoFactorEnabled ? (
                <Badge className="bg-green-500/10 text-green-500">
                  <Shield className="h-3 w-3 mr-1" /> Enabled
                </Badge>
              ) : (
                <Badge className="bg-gray-500/10 text-gray-500">
                  <Key className="h-3 w-3 mr-1" /> Disabled
                </Badge>
              )}
            </div>
            <div className="flex gap-2">
              {!twoFactorEnabled ? (
                <Button className="flex-1" onClick={setup2FA} disabled={loading}>
                  {loading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Shield className="h-4 w-4 mr-2" />}
                  Enable 2FA
                </Button>
              ) : (
                <Button variant="destructive" className="flex-1" onClick={disable2FA} disabled={loading}>
                  Disable 2FA
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Password */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Key className="h-5 w-5 text-orange-500" />
              <CardTitle>Password</CardTitle>
            </div>
            <CardDescription>Manage your account password</CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              variant="outline"
              className="w-full"
              onClick={() => setShowResetDialog(true)}
            >
              <Key className="h-4 w-4 mr-2" /> Change Password
            </Button>
          </CardContent>
        </Card>

        {/* Session Info */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-green-500" />
              <CardTitle>Security Summary</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm">Email Verified</span>
                {emailVerifiedState ? (
                  <Check className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                )}
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm">2FA Enabled</span>
                {twoFactorEnabled ? (
                  <Check className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-yellow-500" />
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 2FA Setup Dialog */}
      <Dialog open={show2FADialog} onOpenChange={setShow2FADialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Setup Two-Factor Authentication</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Scan this QR code with your authenticator app (Google Authenticator, Authy, etc.)
            </p>
            {qrCode && (
              <div className="flex justify-center p-4 bg-white rounded-lg">
                <img src={qrCode} alt="2FA QR Code" className="h-48 w-48" />
              </div>
            )}
            <div>
              <Label>Or enter this code manually:</Label>
              <Input value={secret} readOnly className="font-mono text-center" />
            </div>
            <div>
              <Label>Enter verification code</Label>
              <Input
                placeholder="000000"
                value={verificationCode}
                onChange={(e) => setVerificationCode(e.target.value.replace(/\D/g, "").slice(0, 6))}
                className="text-center text-2xl tracking-widest"
                maxLength={6}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShow2FADialog(false)}>Cancel</Button>
            <Button onClick={verify2FA} disabled={loading || verificationCode.length < 6}>
              {loading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Check className="h-4 w-4 mr-2" />}
              Verify & Enable
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Password Reset Dialog */}
      <Dialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              A password reset link will be sent to your email address.
            </p>
            <div>
              <Label>Email</Label>
              <Input
                type="email"
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowResetDialog(false)}>Cancel</Button>
            <Button onClick={requestPasswordReset} disabled={loading}>
              {loading ? <RefreshCw className="h-4 w-4 mr-2 animate-spin" /> : <Mail className="h-4 w-4 mr-2" />}
              Send Reset Link
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
