import { NextAuthOptions } from 'next-auth';
import CredentialsProvider from 'next-auth/providers/credentials';
import { PrismaAdapter } from '@next-auth/prisma-adapter';
import bcrypt from 'bcryptjs';
import { db } from './db';

export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(db),
  session: {
    strategy: 'jwt',
  },
  pages: {
    signIn: '/auth/signin',
    signOut: '/auth/signout',
    error: '/auth/error',
  },
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.email || !credentials?.password) {
          return null;
        }

        const user = await db.user.findUnique({
          where: { email: credentials.email },
          include: {
            subscription: {
              include: { plan: true },
            },
          },
        });

        if (!user || !user.password) {
          return null;
        }

        const passwordMatch = await bcrypt.compare(
          credentials.password,
          user.password
        );

        if (!passwordMatch) {
          return null;
        }

        const sub = user.subscription;

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          subscription: sub ? {
            plan: sub.planName || sub.plan?.name || 'TRIAL',
            status: sub.status,
            isTrial: sub.isTrial,
            trialEndsAt: sub.trialEndsAt,
            maxTradesPerDay: sub.maxTradesPerDay,
            maxActiveTrades: sub.maxActiveTrades,
          } : null,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.subscription = (user as any).subscription;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        (session.user as any).subscription = token.subscription;
      }
      return session;
    },
  },
  secret: process.env.NEXTAUTH_SECRET || 'trading-bot-secret-key-2024',
};

declare module 'next-auth' {
  interface Session {
    user: {
      id: string;
      email: string;
      name?: string | null;
      subscription?: {
        plan: string;
        status: string;
        isTrial: boolean;
        trialEndsAt: Date | null;
        maxTradesPerDay: number;
        maxActiveTrades: number;
      } | null;
    };
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id: string;
    subscription?: {
      plan: string;
      status: string;
      isTrial: boolean;
      trialEndsAt: Date | null;
      maxTradesPerDay: number;
      maxActiveTrades: number;
    } | null;
  }
}
