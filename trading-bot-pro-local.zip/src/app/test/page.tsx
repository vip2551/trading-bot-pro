export default function TestPage() {
  return (
    <div style={{ padding: 20, fontFamily: 'system-ui' }}>
      <h1>صفحة اختبار</h1>
      <p>إذا كنت ترى هذه الصفحة، فالمشكلة في الصفحة الرئيسية</p>
    </div>
  );
}
