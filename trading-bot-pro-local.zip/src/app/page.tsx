"use client";

import { useState, useEffect, useCallback } from "react";
import {
  Bot,
  Play,
  Square,
  Settings,
  TrendingUp,
  TrendingDown,
  Activity,
  DollarSign,
  Target,
  RefreshCw,
  Zap,
  Shield,
  History,
  Save,
  Wifi,
  WifiOff,
  Bell,
  MessageSquare,
  Calculator,
  Send,
  Radio,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Info,
  BarChart3,
  LineChart,
  PieChart,
  Brain,
  Fish,
  Newspaper,
  Users,
  FileText,
  Lock,
  Globe,
  HelpCircle,
  Database,
  TestTube,
  Calendar,
  Briefcase,
  Languages,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  Crown,
  Check,
  Star,
  LogOut,
  User,
  Mail,
  KeyRound,
  Smartphone,
  ArrowUpRight,
  ArrowDownRight,
  Timer,
  Wallet,
  TrendingUpIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { toast, Toaster } from "sonner";
import { Progress } from "@/components/ui/progress";

// Translations
const translations = {
  en: {
    title: "Trading Bot Pro",
    demo: "Demo",
    trades: "trades",
    start: "Start",
    stop: "Stop",
    dashboard: "Dashboard",
    tradesTab: "Trades",
    manual: "Manual",
    strike: "Strike",
    ai: "AI",
    analytics: "Analytics",
    charts: "Charts",
    whales: "Whales",
    connection: "Connection",
    webhook: "Webhook",
    notifications: "Notifications",
    risk: "Risk",
    journal: "Journal",
    calendar: "Calendar",
    security: "Security",
    backup: "Backup",
    help: "Help",
    totalTrades: "Total Trades",
    openTrades: "Open Trades",
    winRate: "Win Rate",
    totalPL: "Total P&L",
    botStatus: "Bot Status",
    running: "Running",
    stopped: "Stopped",
    stopBot: "Stop Bot",
    startBot: "Start Bot",
    interactiveBrokers: "Interactive Brokers",
    connected: "Connected",
    notConnected: "Not Connected",
    online: "Online",
    offline: "Offline",
    enabled: "Enabled",
    disabled: "Disabled",
    active: "Active",
    inactive: "Inactive",
    strikeMode: "Strike Mode",
    points: "pts",
    recentTrades: "Recent Trades",
    noTrades: "No trades yet",
    allTrades: "All Trades",
    manualTrade: "Manual Trade",
    executeTrade: "Execute a trade manually",
    symbol: "Symbol",
    direction: "Direction",
    quantity: "Quantity",
    strikeOptional: "Strike (optional)",
    auto: "Auto",
    executeTradeBtn: "Execute Trade",
    startBotFirst: "Start Bot First",
    strikeSelectionSettings: "Strike Selection Settings",
    configureStrikes: "Configure how strikes are selected",
    strikeSelectionMode: "Strike Selection Mode",
    strikeModeOffset: "OFFSET - Fixed strikes from ATM",
    strikeModePrice: "CONTRACT_PRICE - Price range based",
    strikeModeDelta: "DELTA - Delta target based",
    strikeModeManual: "MANUAL - Manual selection",
    chooseStrikes: "Choose how strikes are automatically selected for options trades",
    contractPriceRange: "Contract Price Range ($)",
    min: "Min",
    max: "Max",
    strikeOffset: "Strike Offset",
    pointsFromATM: "Points from ATM (OFFSET mode)",
    deltaTarget: "Delta Target",
    deltaValue: "Delta value (DELTA mode)",
    saveSettings: "Save Settings",
    aiMarketAnalysis: "AI Market Analysis",
    aiPowered: "AI-powered market insights",
    runAnalysis: "Run Analysis",
    marketSentiment: "Market Sentiment",
    bullish: "Bullish",
    bearish: "Bearish",
    neutral: "Neutral",
    performance: "Performance",
    performanceChart: "Performance Chart",
    winLossRatio: "Win/Loss Ratio",
    win: "Win",
    loss: "Loss",
    tradingCharts: "Trading Charts",
    priceCharts: "Price charts will appear here",
    whaleTracker: "Whale Tracker",
    trackMovements: "Track large market movements",
    largeCallBlock: "Large CALL Block",
    largePutBlock: "Large PUT Block",
    minAgo: "min ago",
    configureIB: "Configure IB TWS or Gateway",
    host: "Host",
    port: "Port",
    clientId: "Client ID",
    startBotConnect: "Start bot to connect",
    webhookURL: "Webhook URL",
    useInTradingView: "Use in TradingView alerts",
    webhookTester: "Webhook Tester",
    testIntegration: "Test TradingView webhook integration",
    sendTestWebhook: "Send Test Webhook",
    telegramNotifications: "Telegram Notifications",
    receiveNotifications: "Receive trade notifications",
    enableTelegram: "Enable Telegram",
    receiveOnTelegram: "Receive notifications",
    botToken: "Bot Token",
    chatId: "Chat ID",
    test: "Test",
    riskManagement: "Risk Management",
    riskParameters: "Configure risk parameters",
    maxRiskPerTrade: "Max Risk Per Trade ($)",
    defaultQuantity: "Default Quantity",
    maxOpenPositions: "Max Open Positions",
    maxDailyLoss: "Max Daily Loss ($)",
    important: "Important",
    protectAccountInfo: "These settings help protect your account.",
    tradingJournal: "Trading Journal",
    documentTrades: "Document your trades",
    journalEntries: "Journal entries will appear here",
    economicCalendar: "Economic Calendar",
    upcomingEvents: "Upcoming market events",
    fomcMeeting: "FOMC Meeting",
    cpiData: "CPI Data",
    securitySettings: "Security Settings",
    protectAccountTitle: "Protect your account",
    twoFactor: "Two-Factor Authentication",
    extraSecurity: "Add extra security",
    sessionTimeout: "Session Timeout",
    autoLogout: "Auto logout after inactivity",
    backupRestore: "Backup & Restore",
    manageData: "Manage your data",
    exportData: "Export Data",
    importData: "Import Data",
    lastBackup: "Last Backup",
    never: "Never",
    backupNow: "Backup Now",
    userGuide: "User Guide",
    howToUse: "How to use the bot",
    step1Title: "1. Start the Bot",
    step1Desc: "Click the Start button to connect to Interactive Brokers and begin trading.",
    step2Title: "2. Configure Strike Settings",
    step2Desc: "Go to Strike tab to set how strikes are selected for options.",
    step3Title: "3. Set Up Notifications",
    step3Desc: "Enable Telegram in Notifications tab to receive trade alerts.",
    step4Title: "4. TradingView Webhook",
    step4Desc: "Use the webhook URL in TradingView alerts to trigger trades.",
    open: "Open",
    closed: "Closed",
    pending: "Pending",
    botStarted: "Bot started!",
    botStopped: "Bot stopped!",
    settingsSaved: "Settings saved!",
    tradeExecuted: "Trade executed!",
    telegramTestOk: "Telegram test OK!",
    webhookTestOk: "Webhook test OK!",
    failed: "Failed",
    language: "Language",
    arabic: "العربية",
    english: "English",
    plans: "Plans",
    choosePlan: "Choose Your Plan",
    currentPlan: "Current Plan",
    upgradePlan: "Upgrade Plan",
    monthly: "Monthly",
    yearly: "Yearly",
    perMonth: "/month",
    perYear: "/year",
    subscribe: "Subscribe",
    popular: "Popular",
    unlimited: "Unlimited",
    tradesPerDay: "trades/day",
    activeTrades: "active trades",
    daysFree: "days free",
    login: "Login",
    register: "Register",
    logout: "Logout",
    email: "Email",
    password: "Password",
    confirmPassword: "Confirm Password",
    forgotPassword: "Forgot Password?",
    resetPassword: "Reset Password",
    noAccount: "Don't have an account?",
    hasAccount: "Already have an account?",
    createAccount: "Create Account",
    rememberMe: "Remember me",
    twoFactorAuth: "Two-Factor Authentication",
    enable2FA: "Enable 2FA",
    disable2FA: "Disable 2FA",
    enterCode: "Enter 6-digit code",
    scanQR: "Scan QR code with authenticator app",
    orEnterManually: "Or enter manually:",
    verify: "Verify",
  },
  ar: {
    title: "بوت التداول برو",
    demo: "تجريبي",
    trades: "صفقات",
    start: "تشغيل",
    stop: "إيقاف",
    dashboard: "لوحة التحكم",
    tradesTab: "الصفقات",
    manual: "يدوي",
    strike: "الاسترايك",
    ai: "الذكاء الاصطناعي",
    analytics: "التحليلات",
    charts: "الرسوم البيانية",
    whales: "الحيتان",
    connection: "الاتصال",
    webhook: "الويب هوك",
    notifications: "الإشعارات",
    risk: "المخاطر",
    journal: "اليومية",
    calendar: "التقويم",
    security: "الأمان",
    backup: "النسخ الاحتياطي",
    help: "المساعدة",
    totalTrades: "إجمالي الصفقات",
    openTrades: "الصفقات المفتوحة",
    winRate: "نسبة الفوز",
    totalPL: "إجمالي الربح/الخسارة",
    botStatus: "حالة البوت",
    running: "يعمل",
    stopped: "متوقف",
    stopBot: "إيقاف البوت",
    startBot: "تشغيل البوت",
    interactiveBrokers: "انتراكتيف بروكرز",
    connected: "متصل",
    notConnected: "غير متصل",
    online: "متصل",
    offline: "غير متصل",
    enabled: "مفعّل",
    disabled: "معطّل",
    active: "نشط",
    inactive: "غير نشط",
    strikeMode: "وضع الاسترايك",
    points: "نقاط",
    recentTrades: "الصفقات الأخيرة",
    noTrades: "لا توجد صفقات بعد",
    allTrades: "جميع الصفقات",
    manualTrade: "صفقة يدوية",
    executeTrade: "تنفيذ صفقة يدوياً",
    symbol: "الرمز",
    direction: "الاتجاه",
    quantity: "الكمية",
    strikeOptional: "الاسترايك (اختياري)",
    auto: "تلقائي",
    executeTradeBtn: "تنفيذ الصفقة",
    startBotFirst: "شغّل البوت أولاً",
    strikeSelectionSettings: "إعدادات اختيار الاسترايك",
    configureStrikes: "تكوين طريقة اختيار الاسترايك",
    strikeSelectionMode: "وضع اختيار الاسترايك",
    strikeModeOffset: "OFFSET - استرايكات ثابتة من ATM",
    strikeModePrice: "CONTRACT_PRICE - بناءً على نطاق السعر",
    strikeModeDelta: "DELTA - بناءً على الدلتا",
    strikeModeManual: "MANUAL - اختيار يدوي",
    chooseStrikes: "اختر كيفية اختيار الاسترايكات تلقائياً لصفقات الخيارات",
    contractPriceRange: "نطاق سعر العقد ($)",
    min: "أدنى",
    max: "أقصى",
    strikeOffset: "إزاحة الاسترايك",
    pointsFromATM: "النقاط من ATM (وضع OFFSET)",
    deltaTarget: "الهدف الدلتا",
    deltaValue: "قيمة الدلتا (وضع DELTA)",
    saveSettings: "حفظ الإعدادات",
    aiMarketAnalysis: "تحليل السوق بالذكاء الاصطناعي",
    aiPowered: "رؤى السوق بالذكاء الاصطناعي",
    runAnalysis: "تشغيل التحليل",
    marketSentiment: "معنويات السوق",
    bullish: "صعودي",
    bearish: "هابط",
    neutral: "محايد",
    performance: "الأداء",
    performanceChart: "رسم بياني للأداء",
    winLossRatio: "نسبة الفوز/الخسارة",
    win: "فوز",
    loss: "خسارة",
    tradingCharts: "رسوم التداول البيانية",
    priceCharts: "الرسوم البيانية للأسعار ستظهر هنا",
    whaleTracker: "متتبع الحيتان",
    trackMovements: "تتبع حركات السوق الكبيرة",
    largeCallBlock: "كتلة CALL كبيرة",
    largePutBlock: "كتلة PUT كبيرة",
    minAgo: "دقيقة مضت",
    configureIB: "تكوين IB TWS أو Gateway",
    host: "المضيف",
    port: "المنفذ",
    clientId: "معرف العميل",
    startBotConnect: "شغّل البوت للاتصال",
    webhookURL: "رابط الويب هوك",
    useInTradingView: "استخدم في تنبيهات TradingView",
    webhookTester: "اختبار الويب هوك",
    testIntegration: "اختبار تكامل TradingView webhook",
    sendTestWebhook: "إرسال ويب هوك تجريبي",
    telegramNotifications: "إشعارات تيليجرام",
    receiveNotifications: "استلام إشعارات الصفقات",
    enableTelegram: "تفعيل تيليجرام",
    receiveOnTelegram: "استلام الإشعارات",
    botToken: "توكن البوت",
    chatId: "معرف المحادثة",
    test: "اختبار",
    riskManagement: "إدارة المخاطر",
    riskParameters: "تكوين معايير المخاطر",
    maxRiskPerTrade: "أقصى مخاطرة للصفقة ($)",
    defaultQuantity: "الكمية الافتراضية",
    maxOpenPositions: "أقصى صفقات مفتوحة",
    maxDailyLoss: "أقصى خسارة يومية ($)",
    important: "مهم",
    protectAccountInfo: "هذه الإعدادات تساعد في حماية حسابك.",
    tradingJournal: "يومية التداول",
    documentTrades: "وثّق صفقاتك",
    journalEntries: "إدخالات اليومية ستظهر هنا",
    economicCalendar: "التقويم الاقتصادي",
    upcomingEvents: "أحداث السوق القادمة",
    fomcMeeting: "اجتماع FOMC",
    cpiData: "بيانات مؤشر الأسعار",
    securitySettings: "إعدادات الأمان",
    protectAccountTitle: "احمِ حسابك",
    twoFactor: "المصادقة الثنائية",
    extraSecurity: "أضف أماناً إضافياً",
    sessionTimeout: "مهلة الجلسة",
    autoLogout: "تسجيل خروج تلقائي بعد الخمول",
    backupRestore: "النسخ الاحتياطي والاستعادة",
    manageData: "إدارة بياناتك",
    exportData: "تصدير البيانات",
    importData: "استيراد البيانات",
    lastBackup: "آخر نسخة احتياطية",
    never: "أبداً",
    backupNow: "نسخ احتياطي الآن",
    userGuide: "دليل المستخدم",
    howToUse: "كيفية استخدام البوت",
    step1Title: "1. تشغيل البوت",
    step1Desc: "اضغط على زر التشغيل للاتصال بـ Interactive Brokers والبدء في التداول.",
    step2Title: "2. تكوين إعدادات الاسترايك",
    step2Desc: "اذهب إلى تبويب الاسترايك لضبط كيفية اختيار الاسترايكات للخيارات.",
    step3Title: "3. إعداد الإشعارات",
    step3Desc: "فعّل تيليجرام في تبويب الإشعارات لاستلام تنبيهات الصفقات.",
    step4Title: "4. ويب هوك TradingView",
    step4Desc: "استخدم رابط الويب هوك في تنبيهات TradingView لتشغيل الصفقات.",
    open: "مفتوح",
    closed: "مغلق",
    pending: "معلق",
    botStarted: "تم تشغيل البوت!",
    botStopped: "تم إيقاف البوت!",
    settingsSaved: "تم حفظ الإعدادات!",
    tradeExecuted: "تم تنفيذ الصفقة!",
    telegramTestOk: "نجح اختبار تيليجرام!",
    webhookTestOk: "نجح اختبار الويب هوك!",
    failed: "فشل",
    language: "اللغة",
    arabic: "العربية",
    english: "English",
    plans: "الباقات",
    choosePlan: "اختر باقتك",
    currentPlan: "الباقة الحالية",
    upgradePlan: "ترقية الباقة",
    monthly: "شهري",
    yearly: "سنوي",
    perMonth: "/شهر",
    perYear: "/سنة",
    subscribe: "اشترك",
    popular: "الأكثر شعبية",
    unlimited: "غير محدود",
    tradesPerDay: "صفقة/يوم",
    activeTrades: "صفقة نشطة",
    daysFree: "أيام مجاناً",
    login: "تسجيل الدخول",
    register: "إنشاء حساب",
    logout: "تسجيل الخروج",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    confirmPassword: "تأكيد كلمة المرور",
    forgotPassword: "نسيت كلمة المرور؟",
    resetPassword: "إعادة تعيين كلمة المرور",
    noAccount: "ليس لديك حساب؟",
    hasAccount: "لديك حساب بالفعل؟",
    createAccount: "إنشاء حساب",
    rememberMe: "تذكرني",
    twoFactorAuth: "المصادقة الثنائية",
    enable2FA: "تفعيل المصادقة الثنائية",
    disable2FA: "إلغاء تفعيل المصادقة الثنائية",
    enterCode: "أدخل الرمز المكون من 6 أرقام",
    scanQR: "امسح رمز QR بتطبيق المصادقة",
    orEnterManually: "أو أدخل يدوياً:",
    verify: "تحقق",
  }
};

type Language = "en" | "ar";

// Types
interface BotSettings {
  id: string;
  isRunning: boolean;
  accountType: string;
  strikeSelectionMode: string;
  contractPriceMin: number;
  contractPriceMax: number;
  spxStrikeOffset: number;
  spxDeltaTarget: number;
  ibHost: string;
  ibPort: number;
  ibClientId: number;
  ibConnected: boolean;
  telegramEnabled: boolean;
  telegramBotToken: string | null;
  telegramChatId: string | null;
}

interface Trade {
  id: string;
  symbol: string;
  direction: string;
  quantity: number;
  entryPrice: number;
  exitPrice: number | null;
  strike: number | null;
  optionType: string | null;
  status: string;
  pnl: number | null;
  createdAt: string;
}

interface IBStatus {
  connected: boolean;
  accountType: string;
  message: string;
}

export default function Dashboard() {
  // Language
  const [lang, setLang] = useState<Language>("ar");
  const t = translations[lang];
  const isRTL = lang === "ar";
  
  // Bot state
  const [isBotRunning, setIsBotRunning] = useState(false);
  const [settings, setSettings] = useState<BotSettings | null>(null);
  const [tradesList, setTrades] = useState<Trade[]>([]);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [saving, setSaving] = useState(false);
  const [togglingBot, setTogglingBot] = useState(false);
  const [ibStatus, setIbStatus] = useState<IBStatus | null>(null);

  // Stats
  const [stats, setStats] = useState({ total: 0, open: 0, winRate: 0, pnl: 0 });

  // Strike Settings
  const [strikeSelectionMode, setStrikeSelectionMode] = useState("OFFSET");
  const [contractPriceMin, setContractPriceMin] = useState("300");
  const [contractPriceMax, setContractPriceMax] = useState("400");
  const [spxStrikeOffset, setSpxStrikeOffset] = useState("5");
  const [spxDeltaTarget, setSpxDeltaTarget] = useState("0.3");

  // IB Connection Settings
  const [ibHost, setIbHost] = useState("127.0.0.1");
  const [ibPort, setIbPort] = useState("7497");
  const [ibClientId, setIbClientId] = useState("1");

  // Telegram Settings
  const [telegramEnabled, setTelegramEnabled] = useState(false);
  const [telegramBotToken, setTelegramBotToken] = useState("");
  const [telegramChatId, setTelegramChatId] = useState("");

  // Manual Trade
  const [manualSymbol, setManualSymbol] = useState("SPX");
  const [manualDirection, setManualDirection] = useState("CALL");
  const [manualQuantity, setManualQuantity] = useState("1");
  const [manualStrike, setManualStrike] = useState("");

  // AI Analysis
  const [aiAnalysis, setAiAnalysis] = useState<string>("");

  // Fetch all data
  const fetchData = useCallback(async () => {
    try {
      // Fetch trades
      const tradesRes = await fetch('/api/trades').catch(() => null);
      if (tradesRes?.ok) {
        const tradesData = await tradesRes.json();
        const allTrades = tradesData.trades || [];
        setTrades(allTrades);

        const closed = allTrades.filter((tr: Trade) => tr.status === "CLOSED");
        const openTradesList = allTrades.filter((tr: Trade) => tr.status === "OPEN" || tr.status === "PENDING");
        const wins = closed.filter((tr: Trade) => (tr.pnl || 0) > 0);

        setStats({
          total: allTrades.length,
          open: openTradesList.length,
          winRate: closed.length > 0 ? (wins.length / closed.length) * 100 : 0,
          pnl: closed.reduce((sum: number, tr: Trade) => sum + (tr.pnl || 0), 0),
        });
      }

      // Fetch settings
      const settingsRes = await fetch('/api/settings?userId=demo').catch(() => null);
      if (settingsRes?.ok) {
        const settingsData = await settingsRes.json();
        
        if (settingsData?.settings) {
          const s = settingsData.settings;
          setSettings(s);
          setIsBotRunning(s.isRunning || false);
          setStrikeSelectionMode(s.strikeSelectionMode || "OFFSET");
          setContractPriceMin(String(s.contractPriceMin || 300));
          setContractPriceMax(String(s.contractPriceMax || 400));
          setSpxStrikeOffset(String(s.spxStrikeOffset || 5));
          setSpxDeltaTarget(String(s.spxDeltaTarget || 0.3));
          setIbHost(s.ibHost || "127.0.0.1");
          setIbPort(String(s.ibPort || 7497));
          setIbClientId(String(s.ibClientId || 1));
          setTelegramEnabled(s.telegramEnabled || false);
          setTelegramBotToken(s.telegramBotToken || "");
          setTelegramChatId(s.telegramChatId || "");
        }
      }

      // Fetch IB status
      const ibRes = await fetch('/api/ib').catch(() => null);
      if (ibRes?.ok) {
        setIbStatus(await ibRes.json());
      }
    } catch (error) {
      console.error('Fetch error:', error);
    }
  }, []);

  // Initial load
  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, [fetchData]);

  // Start bot
  const startBot = async () => {
    if (togglingBot) return;
    setTogglingBot(true);
    try {
      const res = await fetch("/api/bot/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: "demo" }),
      });
      const data = await res.json();
      if (data.success) {
        setIsBotRunning(true);
        if (data.settings) setSettings(data.settings);
        if (data.ibStatus) setIbStatus(data.ibStatus);
        toast.success(t.botStarted);
      } else {
        toast.error(data.error || t.failed);
      }
    } catch {
      toast.error(t.failed);
    } finally {
      setTogglingBot(false);
    }
  };

  // Stop bot
  const stopBot = async () => {
    if (togglingBot) return;
    setTogglingBot(true);
    try {
      const res = await fetch("/api/bot/stop", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: "demo" }),
      });
      const data = await res.json();
      if (data.success) {
        setIsBotRunning(false);
        if (data.settings) setSettings(data.settings);
        toast.success(t.botStopped);
      } else {
        toast.error(data.error || t.failed);
      }
    } catch {
      toast.error(t.failed);
    } finally {
      setTogglingBot(false);
    }
  };

  // Save settings
  const saveSettings = async (data: Record<string, unknown>) => {
    if (saving) return;
    setSaving(true);
    try {
      const res = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId: "demo", ...data }),
      });
      const result = await res.json();
      if (result.success) {
        if (result.settings) setSettings(result.settings);
        toast.success(t.settingsSaved);
      } else {
        toast.error(t.failed);
      }
    } catch {
      toast.error(t.failed);
    } finally {
      setSaving(false);
    }
  };

  // Manual trade
  const executeManualTrade = async () => {
    try {
      const res = await fetch("/api/trades/manual", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: "demo",
          symbol: manualSymbol,
          direction: manualDirection,
          quantity: parseInt(manualQuantity) || 1,
          strike: manualStrike ? parseFloat(manualStrike) : null,
        }),
      });
      const data = await res.json();
      if (data.success) {
        toast.success(t.tradeExecuted);
        fetchData();
      } else {
        toast.error(data.error || t.failed);
      }
    } catch {
      toast.error(t.failed);
    }
  };

  // Test Telegram
  const testTelegram = async () => {
    try {
      const res = await fetch("/api/telegram", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          action: "test_message", 
          userId: "demo",
          botToken: telegramBotToken,
          chatId: telegramChatId
        }),
      });
      const data = await res.json();
      if (data.success) toast.success(t.telegramTestOk);
      else toast.error(data.error || t.failed);
    } catch {
      toast.error(t.failed);
    }
  };

  // Test Webhook
  const testWebhook = async () => {
    try {
      const res = await fetch("/api/webhook/tradingview", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "CALL", symbol: "SPX", price: 5000 }),
      });
      const data = await res.json();
      if (data.success) toast.success(t.webhookTestOk);
      else toast.error(t.failed);
    } catch {
      toast.error(t.failed);
    }
  };

  // AI Analysis
  const runAIAnalysis = async () => {
    setAiAnalysis(lang === "ar" ? "جاري تحليل ظروف السوق..." : "Analyzing market conditions...");
    try {
      const res = await fetch("/api/ai/analysis", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ symbol: "SPX" }),
      });
      const data = await res.json();
      if (data.analysis) setAiAnalysis(data.analysis);
      else setAiAnalysis(lang === "ar" ? "غير قادر على تحليل ظروف السوق." : "Unable to analyze market conditions.");
    } catch {
      setAiAnalysis(lang === "ar" ? "التحليل غير متاح. يرجى المحاولة مرة أخرى." : "Analysis unavailable. Please try again.");
    }
  };

  const getDirectionIcon = (dir: string) => 
    dir === "CALL" || dir === "BUY" 
      ? <TrendingUp className="h-4 w-4 text-green-500" /> 
      : <TrendingDown className="h-4 w-4 text-red-500" />;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "OPEN": return <Badge className="bg-green-500">{t.open}</Badge>;
      case "CLOSED": return <Badge variant="secondary">{t.closed}</Badge>;
      case "PENDING": return <Badge variant="outline">{t.pending}</Badge>;
      default: return <Badge variant="destructive">{status}</Badge>;
    }
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-background via-background to-muted/20 ${isRTL ? 'rtl' : 'ltr'}`} dir={isRTL ? 'rtl' : 'ltr'}>
      <Toaster position="top-right" />

      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Bot className="h-7 w-7 text-primary" />
              {isBotRunning && (
                <span className="absolute -top-1 -right-1 h-2 w-2 bg-green-500 rounded-full animate-pulse" />
              )}
            </div>
            <div>
              <h1 className="text-xl font-bold">{t.title}</h1>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs">{t.demo}</Badge>
                <Badge variant="outline" className="text-xs">{stats.total} {t.trades}</Badge>
                {ibStatus?.connected && (
                  <Badge className="bg-green-500 text-xs"><Wifi className="h-3 w-3 mr-1" />IB</Badge>
                )}
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Language Toggle */}
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setLang(lang === "ar" ? "en" : "ar")}
            >
              <Languages className="h-4 w-4 mr-1" />
              {lang === "ar" ? "EN" : "عر"}
            </Button>
            
            {isBotRunning ? (
              <Button variant="destructive" size="sm" onClick={stopBot} disabled={togglingBot}>
                <Square className="h-4 w-4 mr-1" /> {t.stop}
              </Button>
            ) : (
              <Button size="sm" onClick={startBot} className="bg-green-600 hover:bg-green-700" disabled={togglingBot}>
                <Play className="h-4 w-4 mr-1" /> {t.start}
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          {/* Tabs in two rows */}
          <div className="relative mb-6">
            <TabsList className="flex-wrap h-auto gap-1 p-2 bg-muted/50 rounded-lg w-full grid grid-cols-6 sm:grid-cols-9">
              <TabsTrigger value="dashboard" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Activity className="h-4 w-4 text-blue-500" /><span className="hidden sm:inline text-xs">{t.dashboard}</span></TabsTrigger>
              <TabsTrigger value="trades" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><History className="h-4 w-4 text-purple-500" /><span className="hidden sm:inline text-xs">{t.tradesTab}</span></TabsTrigger>
              <TabsTrigger value="manual" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Send className="h-4 w-4 text-green-500" /><span className="hidden sm:inline text-xs">{t.manual}</span></TabsTrigger>
              <TabsTrigger value="strike" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Target className="h-4 w-4 text-orange-500" /><span className="hidden sm:inline text-xs">{t.strike}</span></TabsTrigger>
              <TabsTrigger value="ai" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Brain className="h-4 w-4 text-pink-500" /><span className="hidden sm:inline text-xs">{t.ai}</span></TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><BarChart3 className="h-4 w-4 text-cyan-500" /><span className="hidden sm:inline text-xs">{t.analytics}</span></TabsTrigger>
              <TabsTrigger value="charts" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><LineChart className="h-4 w-4 text-indigo-500" /><span className="hidden sm:inline text-xs">{t.charts}</span></TabsTrigger>
              <TabsTrigger value="whales" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Fish className="h-4 w-4 text-teal-500" /><span className="hidden sm:inline text-xs">{t.whales}</span></TabsTrigger>
              <TabsTrigger value="connection" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">{ibStatus?.connected ? <Wifi className="h-4 w-4 text-green-500" /> : <WifiOff className="h-4 w-4 text-red-500" />}<span className="hidden sm:inline text-xs">{t.connection}</span></TabsTrigger>
              <TabsTrigger value="webhook" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><TestTube className="h-4 w-4 text-amber-500" /><span className="hidden sm:inline text-xs">{t.webhook}</span></TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Bell className="h-4 w-4 text-red-400" /><span className="hidden sm:inline text-xs">{t.notifications}</span></TabsTrigger>
              <TabsTrigger value="risk" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Calculator className="h-4 w-4 text-yellow-500" /><span className="hidden sm:inline text-xs">{t.risk}</span></TabsTrigger>
              <TabsTrigger value="journal" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><FileText className="h-4 w-4 text-slate-500" /><span className="hidden sm:inline text-xs">{t.journal}</span></TabsTrigger>
              <TabsTrigger value="calendar" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Calendar className="h-4 w-4 text-blue-400" /><span className="hidden sm:inline text-xs">{t.calendar}</span></TabsTrigger>
              <TabsTrigger value="security" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Lock className="h-4 w-4 text-gray-600" /><span className="hidden sm:inline text-xs">{t.security}</span></TabsTrigger>
              <TabsTrigger value="backup" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><Database className="h-4 w-4 text-emerald-500" /><span className="hidden sm:inline text-xs">{t.backup}</span></TabsTrigger>
              <TabsTrigger value="help" className="flex items-center gap-1 px-3 py-2 data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"><HelpCircle className="h-4 w-4 text-sky-500" /><span className="hidden sm:inline text-xs">{t.help}</span></TabsTrigger>
            </TabsList>
          </div>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card><CardContent className="p-4 flex items-center justify-between"><div><p className="text-sm text-muted-foreground">{t.totalTrades}</p><p className="text-2xl font-bold">{stats.total}</p></div><Activity className="h-8 w-8 text-primary" /></CardContent></Card>
              <Card><CardContent className="p-4 flex items-center justify-between"><div><p className="text-sm text-muted-foreground">{t.openTrades}</p><p className="text-2xl font-bold text-blue-500">{stats.open}</p></div><Zap className="h-8 w-8 text-blue-500" /></CardContent></Card>
              <Card><CardContent className="p-4 flex items-center justify-between"><div><p className="text-sm text-muted-foreground">{t.winRate}</p><p className="text-2xl font-bold">{stats.winRate.toFixed(1)}%</p></div><Target className="h-8 w-8 text-green-500" /></CardContent></Card>
              <Card><CardContent className="p-4 flex items-center justify-between"><div><p className="text-sm text-muted-foreground">{t.totalPL}</p><p className={`text-2xl font-bold ${stats.pnl >= 0 ? "text-green-500" : "text-red-500"}`}>${stats.pnl.toFixed(2)}</p></div><DollarSign className={`h-8 w-8 ${stats.pnl >= 0 ? "text-green-500" : "text-red-500"}`} /></CardContent></Card>
            </div>

            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Bot className="h-5 w-5" />{t.botStatus}</CardTitle></CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`h-3 w-3 rounded-full ${isBotRunning ? "bg-green-500 animate-pulse" : "bg-gray-400"}`} />
                    <span className="text-lg font-medium">{isBotRunning ? t.running : t.stopped}</span>
                  </div>
                  {isBotRunning ? (
                    <Button variant="destructive" onClick={stopBot} disabled={togglingBot}><Square className="h-4 w-4 mr-2" />{t.stopBot}</Button>
                  ) : (
                    <Button onClick={startBot} className="bg-green-600 hover:bg-green-700" disabled={togglingBot}><Play className="h-4 w-4 mr-2" />{t.startBot}</Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card>
                <CardHeader><CardTitle className="flex items-center gap-2 text-sm">{ibStatus?.connected ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4 text-red-500" />}{t.interactiveBrokers}</CardTitle></CardHeader>
                <CardContent><div className="flex items-center justify-between"><span className="text-sm text-muted-foreground">{ibStatus?.connected ? `${t.connected} (${ibStatus.accountType})` : t.notConnected}</span><Badge variant={ibStatus?.connected ? "default" : "secondary"}>{ibStatus?.connected ? t.online : t.offline}</Badge></div></CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle className="flex items-center gap-2 text-sm">{telegramEnabled ? <CheckCircle className="h-4 w-4 text-green-500" /> : <Info className="h-4 w-4 text-muted-foreground" />}Telegram</CardTitle></CardHeader>
                <CardContent><div className="flex items-center justify-between"><span className="text-sm text-muted-foreground">{telegramEnabled ? t.enabled : t.disabled}</span><Badge variant={telegramEnabled ? "default" : "secondary"}>{telegramEnabled ? t.active : t.inactive}</Badge></div></CardContent>
              </Card>
              <Card>
                <CardHeader><CardTitle className="flex items-center gap-2 text-sm"><Shield className="h-4 w-4" />{t.strikeMode}</CardTitle></CardHeader>
                <CardContent><div className="flex items-center justify-between"><span className="text-sm text-muted-foreground">{strikeSelectionMode}</span><Badge variant="outline">{spxStrikeOffset} {t.points}</Badge></div></CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><History className="h-5 w-5" />{t.recentTrades}</CardTitle></CardHeader>
              <CardContent>
                {tradesList.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">{t.noTrades}</p>
                ) : (
                  <ScrollArea className="h-64">
                    <div className="space-y-2">
                      {tradesList.slice(0, 10).map((trade) => (
                        <div key={trade.id} className="flex items-center justify-between p-2 rounded bg-muted/50">
                          <div className="flex items-center gap-2">
                            {getDirectionIcon(trade.direction)}
                            <span className="font-medium">{trade.symbol}</span>
                            <span className="text-sm text-muted-foreground">{trade.direction}</span>
                          </div>
                          {getStatusBadge(trade.status)}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Trades */}
          <TabsContent value="trades" className="space-y-6">
            <Card>
              <CardHeader><CardTitle>{t.allTrades}</CardTitle></CardHeader>
              <CardContent>
                {tradesList.length === 0 ? (
                  <p className="text-muted-foreground text-center py-8">{t.noTrades}</p>
                ) : (
                  <ScrollArea className="h-96">
                    <div className="space-y-2">
                      {tradesList.map((trade) => (
                        <div key={trade.id} className="flex items-center justify-between p-3 rounded border">
                          <div className="flex items-center gap-3">
                            {getDirectionIcon(trade.direction)}
                            <div>
                              <span className="font-medium">{trade.symbol}</span>
                              <span className="text-sm text-muted-foreground ml-2">{trade.direction} x{trade.quantity}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            {trade.pnl !== null && (
                              <span className={trade.pnl >= 0 ? "text-green-500" : "text-red-500"}>
                                ${trade.pnl.toFixed(2)}
                              </span>
                            )}
                            {getStatusBadge(trade.status)}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Manual Trade */}
          <TabsContent value="manual" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t.manualTrade}</CardTitle>
                <CardDescription>{t.executeTrade}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>{t.symbol}</Label>
                    <Input value={manualSymbol} onChange={(e) => setManualSymbol(e.target.value)} />
                  </div>
                  <div>
                    <Label>{t.direction}</Label>
                    <Select value={manualDirection} onValueChange={setManualDirection}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CALL">CALL</SelectItem>
                        <SelectItem value="PUT">PUT</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>{t.quantity}</Label>
                    <Input type="number" value={manualQuantity} onChange={(e) => setManualQuantity(e.target.value)} />
                  </div>
                  <div>
                    <Label>{t.strikeOptional}</Label>
                    <Input placeholder={t.auto} value={manualStrike} onChange={(e) => setManualStrike(e.target.value)} />
                  </div>
                </div>
                <Button onClick={executeManualTrade} className="w-full" disabled={!isBotRunning}>
                  {isBotRunning ? t.executeTradeBtn : t.startBotFirst}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Strike Settings */}
          <TabsContent value="strike" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t.strikeSelectionSettings}</CardTitle>
                <CardDescription>{t.configureStrikes}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>{t.strikeSelectionMode}</Label>
                  <Select value={strikeSelectionMode} onValueChange={setStrikeSelectionMode}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="OFFSET">{t.strikeModeOffset}</SelectItem>
                      <SelectItem value="CONTRACT_PRICE">{t.strikeModePrice}</SelectItem>
                      <SelectItem value="DELTA">{t.strikeModeDelta}</SelectItem>
                      <SelectItem value="MANUAL">{t.strikeModeManual}</SelectItem>
                    </SelectContent>
                  </Select>
                  <p className="text-sm text-muted-foreground mt-1">{t.chooseStrikes}</p>
                </div>

                {strikeSelectionMode === "CONTRACT_PRICE" && (
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label>{t.contractPriceRange} - {t.min}</Label>
                      <Input type="number" value={contractPriceMin} onChange={(e) => setContractPriceMin(e.target.value)} />
                    </div>
                    <div>
                      <Label>{t.max}</Label>
                      <Input type="number" value={contractPriceMax} onChange={(e) => setContractPriceMax(e.target.value)} />
                    </div>
                  </div>
                )}

                {strikeSelectionMode === "OFFSET" && (
                  <div>
                    <Label>{t.pointsFromATM}</Label>
                    <Input type="number" value={spxStrikeOffset} onChange={(e) => setSpxStrikeOffset(e.target.value)} />
                  </div>
                )}

                {strikeSelectionMode === "DELTA" && (
                  <div>
                    <Label>{t.deltaValue}</Label>
                    <Input type="number" step="0.01" value={spxDeltaTarget} onChange={(e) => setSpxDeltaTarget(e.target.value)} />
                  </div>
                )}

                <Button onClick={() => saveSettings({ strikeSelectionMode, contractPriceMin: parseFloat(contractPriceMin), contractPriceMax: parseFloat(contractPriceMax), spxStrikeOffset: parseFloat(spxStrikeOffset), spxDeltaTarget: parseFloat(spxDeltaTarget) })} disabled={saving}>
                  <Save className="h-4 w-4 mr-2" />{t.saveSettings}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI Analysis */}
          <TabsContent value="ai" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><Brain className="h-5 w-5" />{t.aiMarketAnalysis}</CardTitle>
                <CardDescription>{t.aiPowered}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button onClick={runAIAnalysis}><Brain className="h-4 w-4 mr-2" />{t.runAnalysis}</Button>
                {aiAnalysis && (
                  <div className="p-4 bg-muted rounded-lg">
                    <p className="whitespace-pre-wrap">{aiAnalysis}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><BarChart3 className="h-5 w-5" />{t.performance}</CardTitle></CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center bg-muted rounded-lg">
                  <p className="text-muted-foreground">{t.performanceChart}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Charts */}
          <TabsContent value="charts" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><LineChart className="h-5 w-5" />{t.tradingCharts}</CardTitle></CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center bg-muted rounded-lg">
                  <p className="text-muted-foreground">{t.priceCharts}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Whales */}
          <TabsContent value="whales" className="space-y-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Fish className="h-5 w-5" />{t.whaleTracker}</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 bg-green-500/10 rounded-lg border border-green-500/20">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-green-500" />
                      <span className="font-medium">{t.largeCallBlock}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">SPX 5000 CALL - 500 contracts • 15 {t.minAgo}</p>
                  </div>
                  <div className="p-4 bg-red-500/10 rounded-lg border border-red-500/20">
                    <div className="flex items-center gap-2">
                      <TrendingDown className="h-5 w-5 text-red-500" />
                      <span className="font-medium">{t.largePutBlock}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">SPX 4950 PUT - 300 contracts • 32 {t.minAgo}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Connection */}
          <TabsContent value="connection" className="space-y-6">
            <Card>
              <CardHeader><CardTitle>{t.configureIB}</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label>{t.host}</Label>
                    <Input value={ibHost} onChange={(e) => setIbHost(e.target.value)} />
                  </div>
                  <div>
                    <Label>{t.port}</Label>
                    <Input value={ibPort} onChange={(e) => setIbPort(e.target.value)} />
                  </div>
                  <div>
                    <Label>{t.clientId}</Label>
                    <Input value={ibClientId} onChange={(e) => setIbClientId(e.target.value)} />
                  </div>
                </div>
                <Button onClick={() => saveSettings({ ibHost, ibPort: parseInt(ibPort), ibClientId: parseInt(ibClientId) })} disabled={saving}>
                  <Save className="h-4 w-4 mr-2" />{t.saveSettings}
                </Button>
                <p className="text-sm text-muted-foreground">{t.startBotConnect}</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader><CardTitle>{t.webhookURL}</CardTitle></CardHeader>
              <CardContent>
                <code className="block p-3 bg-muted rounded-lg text-sm">/api/webhook/tradingview</code>
                <p className="text-sm text-muted-foreground mt-2">{t.useInTradingView}</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Webhook Tester */}
          <TabsContent value="webhook" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t.webhookTester}</CardTitle>
                <CardDescription>{t.testIntegration}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button onClick={testWebhook}><TestTube className="h-4 w-4 mr-2" />{t.sendTestWebhook}</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications */}
          <TabsContent value="notifications" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t.telegramNotifications}</CardTitle>
                <CardDescription>{t.receiveNotifications}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>{t.enableTelegram}</Label>
                  <Switch checked={telegramEnabled} onCheckedChange={setTelegramEnabled} />
                </div>
                <div>
                  <Label>{t.botToken}</Label>
                  <Input placeholder="123456:ABC-DEF..." value={telegramBotToken} onChange={(e) => setTelegramBotToken(e.target.value)} />
                </div>
                <div>
                  <Label>{t.chatId}</Label>
                  <Input placeholder="-100123456789" value={telegramChatId} onChange={(e) => setTelegramChatId(e.target.value)} />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => saveSettings({ telegramEnabled, telegramBotToken, telegramChatId })} disabled={saving}>
                    <Save className="h-4 w-4 mr-2" />{t.saveSettings}
                  </Button>
                  <Button variant="secondary" onClick={testTelegram}><TestTube className="h-4 w-4 mr-2" />{t.test}</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Risk Management */}
          <TabsContent value="risk" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t.riskManagement}</CardTitle>
                <CardDescription>{t.riskParameters}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>{t.maxRiskPerTrade}</Label>
                    <Input type="number" defaultValue="100" />
                  </div>
                  <div>
                    <Label>{t.defaultQuantity}</Label>
                    <Input type="number" defaultValue="1" />
                  </div>
                  <div>
                    <Label>{t.maxOpenPositions}</Label>
                    <Input type="number" defaultValue="3" />
                  </div>
                  <div>
                    <Label>{t.maxDailyLoss}</Label>
                    <Input type="number" defaultValue="500" />
                  </div>
                </div>
                <div className="p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                  <p className="text-sm"><AlertTriangle className="h-4 w-4 inline mr-1 text-yellow-500" />{t.important}: {t.protectAccountInfo}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Journal */}
          <TabsContent value="journal" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t.tradingJournal}</CardTitle>
                <CardDescription>{t.documentTrades}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-center py-8">{t.journalEntries}</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Calendar */}
          <TabsContent value="calendar" className="space-y-6">
            <Card>
              <CardHeader><CardTitle>{t.economicCalendar}</CardTitle></CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      <span className="font-medium">{t.fomcMeeting}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">Fed Interest Rate Decision</p>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      <span className="font-medium">{t.cpiData}</span>
                    </div>
                    <p className="text-sm text-muted-foreground">Consumer Price Index Release</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Security */}
          <TabsContent value="security" className="space-y-6">
            <Card>
              <CardHeader><CardTitle>{t.securitySettings}</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{t.twoFactor}</p>
                    <p className="text-sm text-muted-foreground">{t.extraSecurity}</p>
                  </div>
                  <Switch />
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">{t.sessionTimeout}</p>
                    <p className="text-sm text-muted-foreground">{t.autoLogout}</p>
                  </div>
                  <Select defaultValue="30">
                    <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 min</SelectItem>
                      <SelectItem value="30">30 min</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Backup */}
          <TabsContent value="backup" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t.backupRestore}</CardTitle>
                <CardDescription>{t.manageData}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex gap-4">
                  <Button variant="outline"><Database className="h-4 w-4 mr-2" />{t.exportData}</Button>
                  <Button variant="outline"><Database className="h-4 w-4 mr-2" />{t.importData}</Button>
                </div>
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">{t.lastBackup}: {t.never}</span>
                  <Button size="sm">{t.backupNow}</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Help */}
          <TabsContent value="help" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{t.userGuide}</CardTitle>
                <CardDescription>{t.howToUse}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-4">
                  <div className="p-4 bg-muted rounded-lg">
                    <h3 className="font-medium flex items-center gap-2"><Play className="h-4 w-4 text-green-500" />{t.step1Title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{t.step1Desc}</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h3 className="font-medium flex items-center gap-2"><Target className="h-4 w-4 text-orange-500" />{t.step2Title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{t.step2Desc}</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h3 className="font-medium flex items-center gap-2"><Bell className="h-4 w-4 text-red-400" />{t.step3Title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{t.step3Desc}</p>
                  </div>
                  <div className="p-4 bg-muted rounded-lg">
                    <h3 className="font-medium flex items-center gap-2"><TestTube className="h-4 w-4 text-amber-500" />{t.step4Title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{t.step4Desc}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t py-4 mt-auto">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          Trading Bot Pro &copy; 2024
        </div>
      </footer>
    </div>
  );
}
