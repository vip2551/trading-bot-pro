import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Get all plans
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const activeOnly = searchParams.get('active') === 'true';

    const plans = await db.plan.findMany({
      where: activeOnly ? { isActive: true } : undefined,
      orderBy: { sortOrder: 'asc' },
      include: {
        _count: {
          select: { subscriptions: true }
        }
      }
    });

    // Transform features from JSON string
    const transformedPlans = plans.map(plan => ({
      ...plan,
      features: plan.features ? JSON.parse(plan.features) : [],
      subscriberCount: plan._count.subscriptions
    }));

    return NextResponse.json({ plans: transformedPlans });

  } catch (error) {
    console.error('Get plans error:', error);
    return NextResponse.json({ error: 'Failed to get plans' }, { status: 500 });
  }
}

// POST - Create or update plan (admin only)
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const {
      id,
      name,
      displayName,
      description,
      priceMonthly,
      priceYearly,
      maxTradesPerDay,
      maxActiveTrades,
      trialDays,
      features,
      isPopular,
      isActive,
      sortOrder
    } = body;

    if (id) {
      // Update existing plan
      const plan = await db.plan.update({
        where: { id },
        data: {
          displayName,
          description,
          priceMonthly,
          priceYearly,
          maxTradesPerDay,
          maxActiveTrades,
          trialDays,
          features: features ? JSON.stringify(features) : null,
          isPopular,
          isActive,
          sortOrder
        }
      });

      return NextResponse.json({ success: true, plan });
    } else {
      // Create new plan
      const plan = await db.plan.create({
        data: {
          name,
          displayName,
          description,
          priceMonthly: priceMonthly || 0,
          priceYearly: priceYearly || 0,
          maxTradesPerDay: maxTradesPerDay || 5,
          maxActiveTrades: maxActiveTrades || 2,
          trialDays: trialDays || 0,
          features: features ? JSON.stringify(features) : null,
          isPopular: isPopular || false,
          isActive: isActive !== false,
          sortOrder: sortOrder || 0
        }
      });

      return NextResponse.json({ success: true, plan });
    }

  } catch (error) {
    console.error('Save plan error:', error);
    return NextResponse.json({ error: 'Failed to save plan' }, { status: 500 });
  }
}

// DELETE - Delete plan (admin only)
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: 'Plan ID required' }, { status: 400 });
    }

    // Check if plan has subscribers
    const plan = await db.plan.findUnique({
      where: { id },
      include: { _count: { select: { subscriptions: true } } }
    });

    if (plan && plan._count.subscriptions > 0) {
      return NextResponse.json({ 
        error: 'Cannot delete plan with active subscribers' 
      }, { status: 400 });
    }

    await db.plan.delete({ where: { id } });

    return NextResponse.json({ success: true });

  } catch (error) {
    console.error('Delete plan error:', error);
    return NextResponse.json({ error: 'Failed to delete plan' }, { status: 500 });
  }
}

// PUT - Initialize default plans
export async function PUT(request: NextRequest) {
  try {
    const defaultPlans = [
      {
        name: 'TRIAL',
        displayName: 'تجريبي مجاني',
        displayNameEn: 'Free Trial',
        description: 'تجربة مجانية لمدة 7 أيام',
        priceMonthly: 0,
        priceYearly: 0,
        maxTradesPerDay: 5,
        maxActiveTrades: 2,
        trialDays: 7,
        features: ['5 صفقات يومياً', 'صفقتان نشطتان', 'إشعارات تيليجرام', 'دعم فني بالبريد'],
        isPopular: false,
        sortOrder: 1
      },
      {
        name: 'BASIC',
        displayName: 'الأساسية',
        displayNameEn: 'Basic',
        description: 'للمتداولين المبتدئين',
        priceMonthly: 29,
        priceYearly: 290,
        maxTradesPerDay: 10,
        maxActiveTrades: 3,
        trialDays: 0,
        features: ['10 صفقات يومياً', '3 صفقات نشطة', 'إشعارات تيليجرام', 'تحديثات السعر كل دقيقة', 'دعم فني'],
        isPopular: false,
        sortOrder: 2
      },
      {
        name: 'PRO',
        displayName: 'المحترف',
        displayNameEn: 'Pro',
        description: 'للمتداولين المحترفين',
        priceMonthly: 79,
        priceYearly: 790,
        maxTradesPerDay: -1,
        maxActiveTrades: 5,
        trialDays: 0,
        features: ['صفقات غير محدودة', '5 صفقات نشطة', 'إشعارات تيليجرام', 'تحديثات السعر', 'تتبع الحيتان', 'تحليل AI', 'دعم أولوية 24/7'],
        isPopular: true,
        sortOrder: 3
      },
      {
        name: 'ENTERPRISE',
        displayName: 'المؤسسات',
        displayNameEn: 'Enterprise',
        description: 'للفرق والمؤسسات',
        priceMonthly: 199,
        priceYearly: 1990,
        maxTradesPerDay: -1,
        maxActiveTrades: -1,
        trialDays: 0,
        features: ['صفقات غير محدودة', 'صفقات نشطة غير محدودة', 'API كامل', 'تقارير متقدمة', 'مدير حساب خاص', 'تدريب مخصص', 'SLA مضمون'],
        isPopular: false,
        sortOrder: 4
      }
    ];

    for (const planData of defaultPlans) {
      await db.plan.upsert({
        where: { name: planData.name },
        create: {
          name: planData.name,
          displayName: planData.displayName,
          description: planData.description,
          priceMonthly: planData.priceMonthly,
          priceYearly: planData.priceYearly,
          maxTradesPerDay: planData.maxTradesPerDay,
          maxActiveTrades: planData.maxActiveTrades,
          trialDays: planData.trialDays,
          features: JSON.stringify(planData.features),
          isPopular: planData.isPopular,
          isActive: true,
          sortOrder: planData.sortOrder
        },
        update: {
          displayName: planData.displayName,
          description: planData.description,
          priceMonthly: planData.priceMonthly,
          priceYearly: planData.priceYearly,
          maxTradesPerDay: planData.maxTradesPerDay,
          maxActiveTrades: planData.maxActiveTrades,
          trialDays: planData.trialDays,
          features: JSON.stringify(planData.features),
          isPopular: planData.isPopular,
          sortOrder: planData.sortOrder
        }
      });
    }

    const plans = await db.plan.findMany({
      orderBy: { sortOrder: 'asc' }
    });

    return NextResponse.json({ 
      success: true, 
      message: 'تم إنشاء الباقات الافتراضية',
      plans 
    });

  } catch (error) {
    console.error('Init plans error:', error);
    return NextResponse.json({ error: 'Failed to initialize plans' }, { status: 500 });
  }
}
