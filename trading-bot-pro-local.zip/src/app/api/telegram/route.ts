import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { 
  telegramService, 
  TELEGRAM_COMMANDS, 
  TELEGRAM_COMMAND_HELP 
} from '@/lib/telegram-service';

// GET - Get Telegram config status
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const action = searchParams.get('action');

    if (!userId) {
      return NextResponse.json({ error: 'userId required' }, { status: 400 });
    }

    // Get user's telegram settings from database
    const settings = await db.botSettings.findUnique({
      where: { userId }
    });

    if (action === 'commands') {
      return NextResponse.json({
        commands: Object.entries(TELEGRAM_COMMANDS).map(([name, cmd]) => ({
          name,
          command: cmd
        })),
        help: TELEGRAM_COMMAND_HELP
      });
    }

    if (action === 'test' && settings?.telegramBotToken) {
      // Test connection
      telegramService.configure({
        botToken: settings.telegramBotToken,
        chatId: settings.telegramChatId || '',
        enabled: true,
        language: 'en',
        notifications: {
          tradeExecuted: true,
          tradeClosed: true,
          orderFilled: true,
          dailyReport: true,
          weeklyReport: true,
          errorAlerts: true,
          systemAlerts: true,
          whaleActivity: true,
          priceUpdates: true
        }
      });

      const testResult = await telegramService.testConnection();
      return NextResponse.json(testResult);
    }

    return NextResponse.json({
      configured: !!(settings?.telegramBotToken && settings?.telegramChatId),
      enabled: settings?.telegramEnabled || false,
      hasBotToken: !!settings?.telegramBotToken,
      hasChatId: !!settings?.telegramChatId,
      botToken: settings?.telegramBotToken ? `${settings.telegramBotToken.substring(0, 10)}...` : null,
      chatId: settings?.telegramChatId || null
    });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// POST - Configure or test Telegram
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, userId, botToken, chatId, enabled, keepExistingToken } = body;

    if (!userId) {
      return NextResponse.json({ error: 'userId required' }, { status: 400 });
    }

    if (action === 'configure') {
      // Get existing settings
      const existingSettings = await db.botSettings.findUnique({
        where: { userId }
      });

      // Determine which token to use
      let finalBotToken = botToken;
      let finalChatId = chatId;

      if (keepExistingToken && existingSettings?.telegramBotToken) {
        finalBotToken = existingSettings.telegramBotToken;
      }

      // Validate config
      if (!finalBotToken || !finalChatId) {
        return NextResponse.json({ 
          error: 'Bot token and Chat ID are required' 
        }, { status: 400 });
      }

      // Test connection first
      telegramService.configure({
        botToken: finalBotToken,
        chatId: finalChatId,
        enabled: true,
        language: 'en',
        notifications: {
          tradeExecuted: true,
          tradeClosed: true,
          orderFilled: true,
          dailyReport: true,
          weeklyReport: true,
          errorAlerts: true,
          systemAlerts: true,
          whaleActivity: true,
          priceUpdates: true
        }
      });

      const testResult = await telegramService.testConnection();
      if (!testResult.success) {
        return NextResponse.json({ 
          success: false,
          error: `Invalid bot token: ${testResult.error}` 
        }, { status: 400 });
      }

      // Verify chat ID
      const chatResult = await telegramService.getChatInfo(finalChatId);
      if (!chatResult.success) {
        return NextResponse.json({ 
          success: false,
          error: `Invalid chat ID: ${chatResult.error}` 
        }, { status: 400 });
      }

      // Save to database
      await db.botSettings.upsert({
        where: { userId },
        create: {
          userId,
          telegramBotToken: finalBotToken,
          telegramChatId: finalChatId,
          telegramEnabled: true
        },
        update: {
          telegramBotToken: finalBotToken,
          telegramChatId: finalChatId,
          telegramEnabled: true
        }
      });

      return NextResponse.json({ 
        success: true, 
        message: 'Telegram configured successfully',
        botInfo: testResult.botInfo,
        chatInfo: chatResult.chat
      });
    }

    if (action === 'test_message') {
      const settings = await db.botSettings.findUnique({
        where: { userId }
      });

      const token = botToken || settings?.telegramBotToken;
      const chat = chatId || settings?.telegramChatId;
      
      if (!token || !chat) {
        return NextResponse.json({ 
          error: 'Telegram not configured' 
        }, { status: 400 });
      }

      telegramService.configure({
        botToken: token,
        chatId: chat,
        enabled: true,
        language: 'en',
        notifications: {
          tradeExecuted: true,
          tradeClosed: true,
          orderFilled: true,
          dailyReport: true,
          weeklyReport: true,
          errorAlerts: true,
          systemAlerts: true,
          whaleActivity: true,
          priceUpdates: true
        }
      });

      const result = await telegramService.sendMessage({
        chatId: chat,
        text: `🧪 <b>Test Message</b>\n\nTelegram integration working!\n\n<i>From Trading Bot Pro</i>`,
        parseMode: 'HTML'
      }, true);

      return NextResponse.json(result);
    }

    if (action === 'toggle') {
      // Update in database
      await db.botSettings.upsert({
        where: { userId },
        create: {
          userId,
          telegramEnabled: enabled || false
        },
        update: {
          telegramEnabled: enabled || false
        }
      });
      
      return NextResponse.json({ 
        success: true, 
        enabled,
        message: enabled ? 'Telegram notifications enabled' : 'Telegram notifications disabled'
      });
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
