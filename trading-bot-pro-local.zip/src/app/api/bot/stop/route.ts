import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to ensure user exists
async function ensureUserExists(userId: string) {
  try {
    let user = await db.user.findUnique({ where: { id: userId } });
    if (!user) {
      user = await db.user.create({
        data: { id: userId, email: `${userId}@demo.local`, name: userId },
      });
    }
    return user;
  } catch (error) {
    console.error('Error ensuring user exists:', error);
    return null;
  }
}

// POST - Stop the bot
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));
    const userId = body.userId || 'demo';

    // Ensure user exists
    await ensureUserExists(userId);

    let settings = await db.botSettings.findUnique({
      where: { userId },
    });

    if (!settings) {
      settings = await db.botSettings.create({
        data: { userId, isRunning: false },
      });
    } else {
      settings = await db.botSettings.update({
        where: { id: settings.id },
        data: { isRunning: false, ibConnected: false },
      });
    }

    // Stop IB service
    try {
      await fetch('http://localhost:3003/bot/stop', {
        method: 'POST',
      });
    } catch (err) {
      console.log('IB service not available (this is OK)');
    }

    return NextResponse.json({ 
      success: true, 
      settings,
      message: 'Bot stopped successfully'
    });
  } catch (error) {
    console.error('Error stopping bot:', error);
    return NextResponse.json({ 
      error: 'Failed to stop bot',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
