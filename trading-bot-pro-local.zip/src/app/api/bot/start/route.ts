import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper to ensure user exists
async function ensureUserExists(userId: string) {
  try {
    let user = await db.user.findUnique({ where: { id: userId } });
    if (!user) {
      user = await db.user.create({
        data: { id: userId, email: `${userId}@demo.local`, name: userId },
      });
    }
    return user;
  } catch (error) {
    console.error('Error ensuring user exists:', error);
    return null;
  }
}

// POST - Start the bot with recovery
export async function POST(request: NextRequest) {
  try {
    const body = await request.json().catch(() => ({}));
    const userId = body.userId || 'demo';

    // Ensure user exists
    await ensureUserExists(userId);

    let settings = await db.botSettings.findUnique({
      where: { userId },
    });

    if (!settings) {
      settings = await db.botSettings.create({
        data: { userId, isRunning: true },
      });
    } else {
      settings = await db.botSettings.update({
        where: { id: settings.id },
        data: { isRunning: true },
      });
    }

    // Get open trades for recovery info
    const openTrades = await db.trade.findMany({
      where: {
        userId,
        status: 'OPEN',
      },
    });

    const pendingTrades = await db.trade.findMany({
      where: {
        userId,
        status: 'PENDING',
        createdAt: {
          gte: new Date(Date.now() - 30 * 60 * 1000), // Last 30 minutes
        },
      },
    });

    // Trades that need trailing stop monitoring
    const trailingStopTrades = openTrades.filter(t => t.trailingStopEnabled);
    
    // Trades with bracket orders
    const bracketOrders = openTrades.filter(t => t.isBracketOrder);

    // Auto-close trades
    const autoCloseTrades = openTrades.filter(t => 
      t.autoCloseAt && new Date(t.autoCloseAt) > new Date()
    );

    // Recovery summary
    const recoveryInfo = {
      openTrades: openTrades.length,
      pendingTrades: pendingTrades.length,
      trailingStopTrades: trailingStopTrades.length,
      bracketOrders: bracketOrders.length,
      autoCloseTrades: autoCloseTrades.length,
    };

    // Start IB service connection with recovery
    let ibStatus = { connected: false, message: 'IB service not available' };
    try {
      const ibRes = await fetch('http://localhost:3003/bot/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId }),
      });
      
      if (ibRes.ok) {
        ibStatus = await ibRes.json();
        
        // Update IB connection status
        await db.botSettings.update({
          where: { id: settings.id },
          data: { ibConnected: ibStatus.connected },
        });
      }
    } catch (err) {
      console.log('IB service not available (this is OK for paper trading)');
    }

    // Create recovery log
    if (openTrades.length > 0 || pendingTrades.length > 0) {
      try {
        await db.auditLog.create({
          data: {
            userId,
            action: 'BOT_START_WITH_RECOVERY',
            entity: 'BOT',
            details: JSON.stringify(recoveryInfo),
            status: 'SUCCESS',
          },
        });
      } catch (e) {
        console.log('Could not create audit log (non-critical)');
      }
    }

    return NextResponse.json({ 
      success: true, 
      settings,
      recovery: recoveryInfo,
      ibStatus,
      message: openTrades.length > 0 
        ? `Bot started. Recovered ${openTrades.length} open trades.` 
        : 'Bot started successfully',
    });
  } catch (error) {
    console.error('Error starting bot:', error);
    return NextResponse.json({ 
      error: 'Failed to start bot',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
