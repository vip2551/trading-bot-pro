import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET - Fetch bot settings
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId') || 'demo';

    // Get user-specific settings
    let settings = await db.botSettings.findUnique({
      where: { userId },
    });

    if (!settings) {
      // First, ensure the user exists (create if not exists)
      let user = await db.user.findUnique({ where: { id: userId } });
      if (!user) {
        user = await db.user.create({
          data: {
            id: userId,
            email: `${userId}@demo.local`,
            name: userId,
            password: 'demo_password_' + userId,
          },
        });
      }

      // Now create the settings with the user relation
      settings = await db.botSettings.create({
        data: { userId },
      });
    }

    // Return all settings including telegram fields
    return NextResponse.json({
      settings: {
        isRunning: settings.isRunning,
        ibHost: settings.ibHost,
        ibPort: settings.ibPort,
        ibClientId: settings.ibClientId,
        strikeSelectionMode: settings.strikeSelectionMode,
        contractPriceMin: settings.contractPriceMin,
        contractPriceMax: settings.contractPriceMax,
        spxStrikeOffset: settings.spxStrikeOffset,
        spxDeltaTarget: settings.spxDeltaTarget,
        telegramEnabled: settings.telegramEnabled,
        telegramBotToken: settings.telegramBotToken || '',
        telegramChatId: settings.telegramChatId || '',
      }
    });
  } catch (error) {
    console.error('Error fetching settings:', error);
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 });
  }
}

// POST - Update bot settings
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, ...settingsData } = body;
    const uid = userId || 'demo';

    console.log('Saving settings for user:', uid, 'data:', settingsData);

    // Check if settings exist
    let settings = await db.botSettings.findUnique({
      where: { userId: uid },
    });

    if (!settings) {
      // First, ensure the user exists
      let user = await db.user.findUnique({ where: { id: uid } });
      if (!user) {
        user = await db.user.create({
          data: {
            id: uid,
            email: `${uid}@demo.local`,
            name: uid,
            password: 'demo_password_' + uid,
          },
        });
      }

      settings = await db.botSettings.create({
        data: { userId: uid, ...settingsData },
      });
    } else {
      settings = await db.botSettings.update({
        where: { userId: uid },
        data: settingsData,
      });
    }

    console.log('Settings saved:', settings);

    return NextResponse.json({
      success: true,
      settings: {
        isRunning: settings.isRunning,
        ibHost: settings.ibHost,
        ibPort: settings.ibPort,
        ibClientId: settings.ibClientId,
        strikeSelectionMode: settings.strikeSelectionMode,
        contractPriceMin: settings.contractPriceMin,
        contractPriceMax: settings.contractPriceMax,
        spxStrikeOffset: settings.spxStrikeOffset,
        spxDeltaTarget: settings.spxDeltaTarget,
        telegramEnabled: settings.telegramEnabled,
        telegramBotToken: settings.telegramBotToken || '',
        telegramChatId: settings.telegramChatId || '',
      }
    });
  } catch (error) {
    console.error('Error updating settings:', error);
    return NextResponse.json({ error: 'Failed to update settings' }, { status: 500 });
  }
}
