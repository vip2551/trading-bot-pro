import { NextRequest, NextResponse } from 'next/server';

// Auto Trading API - Proxy to auto-trader mini-service

const AUTO_TRADER_URL = 'http://localhost:3005';

async function proxyRequest(path: string, method: string, body?: any) {
  try {
    const res = await fetch(`${AUTO_TRADER_URL}${path}`, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined
    });
    return await res.json();
  } catch (error) {
    console.error('Auto trader proxy error:', error);
    return { error: 'Auto trader service unavailable', success: false };
  }
}

// GET - Get auto trading status
export async function GET(request: NextRequest) {
  const status = await proxyRequest('/status', 'GET');
  return NextResponse.json(status);
}

// POST - Control auto trading
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, ...config } = body;
    
    let result;
    
    switch (action) {
      case 'enable':
        result = await proxyRequest('/enable', 'POST', config);
        break;
      case 'disable':
        result = await proxyRequest('/disable', 'POST');
        break;
      case 'config':
        result = await proxyRequest('/config', 'POST', config);
        break;
      case 'run':
        result = await proxyRequest('/run', 'POST');
        break;
      default:
        result = { error: 'Invalid action', success: false };
    }
    
    return NextResponse.json(result);
  } catch (error) {
    return NextResponse.json({ error: 'Invalid request', success: false }, { status: 400 });
  }
}
