import type { Metadata } from "next";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

export const metadata: Metadata = {
  title: "Trading Bot Pro",
  description: "Automated trading bot",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" className="dark">
      <body className="bg-slate-900 text-white antialiased">
        {children}
        <Toaster position="top-right" />
      </body>
    </html>
  );
}
