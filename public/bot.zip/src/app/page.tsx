"use client";

import { useState } from "react";
import {
  Bot,
  Play,
  Square,
  Activity,
  DollarSign,
  Target,
  Zap,
  Shield,
  History,
  Wifi,
  WifiOff,
  Bell,
  TrendingUp,
  TrendingDown,
  CheckCircle,
  XCircle,
  Info,
  Send,
  Brain,
  BarChart3,
  LineChart,
  Fish,
  TestTube,
  Calculator,
  FileText,
  Calendar,
  Lock,
  Database,
  HelpCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";

export default function Dashboard() {
  const [isBotRunning, setIsBotRunning] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [stats] = useState({ total: 0, open: 0, winRate: 0, pnl: 0 });
  const [ibConnected] = useState(false);
  const [telegramEnabled, setTelegramEnabled] = useState(false);
  const [telegramBotToken, setTelegramBotToken] = useState("");
  const [telegramChatId, setTelegramChatId] = useState("");
  const [strikeSelectionMode, setStrikeSelectionMode] = useState("OFFSET");
  const [spxStrikeOffset, setSpxStrikeOffset] = useState("5");
  const [ibHost, setIbHost] = useState("127.0.0.1");
  const [ibPort, setIbPort] = useState("7497");
  const [ibClientId, setIbClientId] = useState("1");
  const [maxRisk, setMaxRisk] = useState("100");
  const [maxPositions, setMaxPositions] = useState("3");
  const [manualSymbol, setManualSymbol] = useState("SPX");
  const [manualDirection, setManualDirection] = useState("CALL");
  const [manualQuantity, setManualQuantity] = useState("1");
  const [manualStrike, setManualStrike] = useState("");

  const getDirectionIcon = (dir: string) => {
    if (dir === "CALL" || dir === "BUY") {
      return <TrendingUp className="h-4 w-4 text-green-500" />;
    }
    return <TrendingDown className="h-4 w-4 text-red-500" />;
  };

  const getStatusBadge = (status: string) => {
    if (status === "OPEN") return <Badge className="bg-green-500">مفتوح</Badge>;
    if (status === "CLOSED") return <Badge variant="secondary">مغلق</Badge>;
    if (status === "PENDING") return <Badge variant="outline">معلق</Badge>;
    return <Badge variant="destructive">{status}</Badge>;
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-slate-700 bg-slate-900">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="relative">
              <Bot className="h-8 w-8 text-emerald-400" />
              {isBotRunning && (
                <span className="absolute -top-1 -right-1 h-3 w-3 bg-green-500 rounded-full animate-pulse" />
              )}
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">بوت التداول برو</h1>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-xs border-slate-600 text-slate-300">تجريبي</Badge>
                <Badge variant="outline" className="text-xs border-slate-600 text-slate-300">{stats.total} صفقات</Badge>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isBotRunning ? (
              <Button variant="destructive" size="sm" onClick={() => setIsBotRunning(false)}>
                <Square className="h-4 w-4 ml-1" /> إيقاف
              </Button>
            ) : (
              <Button size="sm" onClick={() => setIsBotRunning(true)} className="bg-emerald-600 hover:bg-emerald-700">
                <Play className="h-4 w-4 ml-1" /> تشغيل
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Main */}
      <main className="container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="mb-6 overflow-x-auto">
            <TabsList className="inline-flex gap-1 p-2 bg-slate-800 rounded-lg flex-wrap">
              <TabsTrigger value="dashboard" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Activity className="h-4 w-4 text-blue-400" />
                <span className="hidden sm:inline">لوحة التحكم</span>
              </TabsTrigger>
              <TabsTrigger value="trades" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <History className="h-4 w-4 text-purple-400" />
                <span className="hidden sm:inline">الصفقات</span>
              </TabsTrigger>
              <TabsTrigger value="manual" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Send className="h-4 w-4 text-green-400" />
                <span className="hidden sm:inline">يدوي</span>
              </TabsTrigger>
              <TabsTrigger value="strike" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Target className="h-4 w-4 text-orange-400" />
                <span className="hidden sm:inline">الاسترايك</span>
              </TabsTrigger>
              <TabsTrigger value="ai" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Brain className="h-4 w-4 text-pink-400" />
                <span className="hidden sm:inline">الذكاء</span>
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <BarChart3 className="h-4 w-4 text-cyan-400" />
                <span className="hidden sm:inline">التحليلات</span>
              </TabsTrigger>
              <TabsTrigger value="charts" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <LineChart className="h-4 w-4 text-indigo-400" />
                <span className="hidden sm:inline">الرسوم</span>
              </TabsTrigger>
              <TabsTrigger value="whales" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Fish className="h-4 w-4 text-teal-400" />
                <span className="hidden sm:inline">الحيتان</span>
              </TabsTrigger>
              <TabsTrigger value="connection" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                {ibConnected ? <Wifi className="h-4 w-4 text-green-400" /> : <WifiOff className="h-4 w-4 text-red-400" />}
                <span className="hidden sm:inline">الاتصال</span>
              </TabsTrigger>
              <TabsTrigger value="webhook" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <TestTube className="h-4 w-4 text-amber-400" />
                <span className="hidden sm:inline">ويب هوك</span>
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Bell className="h-4 w-4 text-rose-400" />
                <span className="hidden sm:inline">الإشعارات</span>
              </TabsTrigger>
              <TabsTrigger value="risk" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Calculator className="h-4 w-4 text-yellow-400" />
                <span className="hidden sm:inline">المخاطر</span>
              </TabsTrigger>
              <TabsTrigger value="journal" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <FileText className="h-4 w-4 text-slate-400" />
                <span className="hidden sm:inline">اليومية</span>
              </TabsTrigger>
              <TabsTrigger value="calendar" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Calendar className="h-4 w-4 text-blue-300" />
                <span className="hidden sm:inline">التقويم</span>
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Lock className="h-4 w-4 text-gray-400" />
                <span className="hidden sm:inline">الأمان</span>
              </TabsTrigger>
              <TabsTrigger value="backup" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <Database className="h-4 w-4 text-emerald-400" />
                <span className="hidden sm:inline">النسخ</span>
              </TabsTrigger>
              <TabsTrigger value="help" className="flex items-center gap-1 px-3 py-2 text-xs data-[state=active]:bg-emerald-600 data-[state=active]:text-white">
                <HelpCircle className="h-4 w-4 text-sky-400" />
                <span className="hidden sm:inline">المساعدة</span>
              </TabsTrigger>
            </TabsList>
          </div>

          {/* Dashboard */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-400">إجمالي الصفقات</p>
                    <p className="text-2xl font-bold text-white">{stats.total}</p>
                  </div>
                  <Activity className="h-8 w-8 text-blue-400" />
                </CardContent>
              </Card>
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-400">الصفقات المفتوحة</p>
                    <p className="text-2xl font-bold text-cyan-400">{stats.open}</p>
                  </div>
                  <Zap className="h-8 w-8 text-cyan-400" />
                </CardContent>
              </Card>
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-400">نسبة الفوز</p>
                    <p className="text-2xl font-bold text-white">{stats.winRate.toFixed(1)}%</p>
                  </div>
                  <Target className="h-8 w-8 text-green-400" />
                </CardContent>
              </Card>
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm text-slate-400">إجمالي P&L</p>
                    <p className="text-2xl font-bold text-green-400">${stats.pnl.toFixed(2)}</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-400" />
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <Bot className="h-5 w-5 text-emerald-400" />
                  حالة البوت
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={`h-4 w-4 rounded-full ${isBotRunning ? "bg-green-500 animate-pulse" : "bg-slate-600"}`} />
                    <span className="text-lg font-medium text-white">{isBotRunning ? "يعمل" : "متوقف"}</span>
                  </div>
                  {isBotRunning ? (
                    <Button variant="destructive" onClick={() => setIsBotRunning(false)}>
                      <Square className="h-4 w-4 ml-2" />
                      إيقاف البوت
                    </Button>
                  ) : (
                    <Button onClick={() => setIsBotRunning(true)} className="bg-emerald-600 hover:bg-emerald-700">
                      <Play className="h-4 w-4 ml-2" />
                      تشغيل البوت
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm text-white">
                    <XCircle className="h-4 w-4 text-red-400" />
                    انتراكتيف بروكرز
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-400">غير متصل</span>
                    <Badge variant="secondary">غير متصل</Badge>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm text-white">
                    <Info className="h-4 w-4 text-slate-400" />
                    Telegram
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-400">{telegramEnabled ? "مفعّل" : "معطّل"}</span>
                    <Badge variant="secondary">{telegramEnabled ? "نشط" : "غير نشط"}</Badge>
                  </div>
                </CardContent>
              </Card>
              <Card className="bg-slate-800 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-sm text-white">
                    <Shield className="h-4 w-4 text-amber-400" />
                    وضع الاسترايك
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-slate-400">{strikeSelectionMode}</span>
                    <Badge variant="outline" className="border-slate-600 text-slate-300">{spxStrikeOffset} نقاط</Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card className="bg-slate-800 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-white">
                  <History className="h-5 w-5 text-purple-400" />
                  الصفقات الأخيرة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-slate-400 text-center py-8">لا توجد صفقات بعد</p>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Trades */}
          <TabsContent value="trades">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white">جميع الصفقات</CardTitle></CardHeader>
              <CardContent><p className="text-slate-400 text-center py-8">لا توجد صفقات بعد</p></CardContent>
            </Card>
          </TabsContent>

          {/* Manual */}
          <TabsContent value="manual">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white">صفقة يدوية</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-slate-300">الرمز</Label>
                    <Select value={manualSymbol} onValueChange={setManualSymbol}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="SPX">SPX</SelectItem>
                        <SelectItem value="SPY">SPY</SelectItem>
                        <SelectItem value="QQQ">QQQ</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">الاتجاه</Label>
                    <Select value={manualDirection} onValueChange={setManualDirection}>
                      <SelectTrigger className="bg-slate-700 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="CALL">CALL</SelectItem>
                        <SelectItem value="PUT">PUT</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">الكمية</Label>
                    <Input type="number" value={manualQuantity} onChange={(e) => setManualQuantity(e.target.value)} className="bg-slate-700 border-slate-600 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">الاسترايك</Label>
                    <Input type="number" value={manualStrike} onChange={(e) => setManualStrike(e.target.value)} className="bg-slate-700 border-slate-600 text-white" placeholder="اختياري" />
                  </div>
                </div>
                <Button className="w-full bg-emerald-600 hover:bg-emerald-700">تنفيذ الصفقة</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Strike */}
          <TabsContent value="strike">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white">إعدادات الاسترايك</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-slate-300">وضع الاختيار</Label>
                  <Select value={strikeSelectionMode} onValueChange={setStrikeSelectionMode}>
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="OFFSET">OFFSET</SelectItem>
                      <SelectItem value="CONTRACT_PRICE">CONTRACT_PRICE</SelectItem>
                      <SelectItem value="DELTA">DELTA</SelectItem>
                      <SelectItem value="MANUAL">MANUAL</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">الإزاحة</Label>
                  <Input type="number" value={spxStrikeOffset} onChange={(e) => setSpxStrikeOffset(e.target.value)} className="bg-slate-700 border-slate-600 text-white" />
                </div>
                <Button className="w-full bg-emerald-600 hover:bg-emerald-700">حفظ</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* AI */}
          <TabsContent value="ai">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><Brain className="h-5 w-5 text-pink-400" />تحليل الذكاء الاصطناعي</CardTitle></CardHeader>
              <CardContent><p className="text-slate-400 text-center py-8">تحليل ذكي لظروف السوق</p></CardContent>
            </Card>
          </TabsContent>

          {/* Analytics */}
          <TabsContent value="analytics">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><BarChart3 className="h-5 w-5 text-cyan-400" />التحليلات</CardTitle></CardHeader>
              <CardContent><p className="text-slate-400 text-center py-8">تحليلات الأداء</p></CardContent>
            </Card>
          </TabsContent>

          {/* Charts */}
          <TabsContent value="charts">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><LineChart className="h-5 w-5 text-indigo-400" />الرسوم البيانية</CardTitle></CardHeader>
              <CardContent><p className="text-slate-400 text-center py-8">الرسوم البيانية للأسعار</p></CardContent>
            </Card>
          </TabsContent>

          {/* Whales */}
          <TabsContent value="whales">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><Fish className="h-5 w-5 text-teal-400" />متتبع الحيتان</CardTitle></CardHeader>
              <CardContent><p className="text-slate-400 text-center py-8">تتبع حركات الحيتان</p></CardContent>
            </Card>
          </TabsContent>

          {/* Connection */}
          <TabsContent value="connection">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white">تكوين IB TWS</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label className="text-slate-300">المضيف</Label>
                    <Input value={ibHost} onChange={(e) => setIbHost(e.target.value)} className="bg-slate-700 border-slate-600 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">المنفذ</Label>
                    <Input value={ibPort} onChange={(e) => setIbPort(e.target.value)} className="bg-slate-700 border-slate-600 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">معرف العميل</Label>
                    <Input value={ibClientId} onChange={(e) => setIbClientId(e.target.value)} className="bg-slate-700 border-slate-600 text-white" />
                  </div>
                </div>
                <Button className="w-full bg-emerald-600 hover:bg-emerald-700">حفظ</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Webhook */}
          <TabsContent value="webhook">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white">رابط الويب هوك</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="p-3 bg-slate-700 rounded-lg font-mono text-sm break-all text-green-400">
                  {typeof window !== 'undefined' ? window.location.origin : ''}/api/webhook/tradingview
                </div>
                <Button variant="outline" className="w-full border-slate-600 text-white hover:bg-slate-700">اختبار</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notifications */}
          <TabsContent value="notifications">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white">إشعارات تيليجرام</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label className="text-slate-300">تفعيل</Label>
                  <Switch checked={telegramEnabled} onCheckedChange={setTelegramEnabled} />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">توكن البوت</Label>
                  <Input value={telegramBotToken} onChange={(e) => setTelegramBotToken(e.target.value)} className="bg-slate-700 border-slate-600 text-white" placeholder="123456:ABC-DEF..." />
                </div>
                <div className="space-y-2">
                  <Label className="text-slate-300">معرف المحادثة</Label>
                  <Input value={telegramChatId} onChange={(e) => setTelegramChatId(e.target.value)} className="bg-slate-700 border-slate-600 text-white" placeholder="-1001234567890" />
                </div>
                <div className="flex gap-2">
                  <Button className="flex-1 bg-emerald-600 hover:bg-emerald-700">حفظ</Button>
                  <Button variant="outline" className="border-slate-600 text-white hover:bg-slate-700">اختبار</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Risk */}
          <TabsContent value="risk">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><Calculator className="h-5 w-5 text-yellow-400" />إدارة المخاطر</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-slate-300">أقصى مخاطرة ($)</Label>
                    <Input type="number" value={maxRisk} onChange={(e) => setMaxRisk(e.target.value)} className="bg-slate-700 border-slate-600 text-white" />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-slate-300">أقصى صفقات</Label>
                    <Input type="number" value={maxPositions} onChange={(e) => setMaxPositions(e.target.value)} className="bg-slate-700 border-slate-600 text-white" />
                  </div>
                </div>
                <Button className="w-full bg-emerald-600 hover:bg-emerald-700">حفظ</Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Journal */}
          <TabsContent value="journal">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><FileText className="h-5 w-5 text-slate-400" />يومية التداول</CardTitle></CardHeader>
              <CardContent><p className="text-slate-400 text-center py-8">إدخالات اليومية</p></CardContent>
            </Card>
          </TabsContent>

          {/* Calendar */}
          <TabsContent value="calendar">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><Calendar className="h-5 w-5 text-blue-300" />التقويم الاقتصادي</CardTitle></CardHeader>
              <CardContent><p className="text-slate-400 text-center py-8">أحداث السوق القادمة</p></CardContent>
            </Card>
          </TabsContent>

          {/* Security */}
          <TabsContent value="security">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><Lock className="h-5 w-5 text-gray-400" />الأمان</CardTitle></CardHeader>
              <CardContent><p className="text-slate-400 text-center py-8">إعدادات الأمان</p></CardContent>
            </Card>
          </TabsContent>

          {/* Backup */}
          <TabsContent value="backup">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><Database className="h-5 w-5 text-emerald-400" />النسخ الاحتياطي</CardTitle></CardHeader>
              <CardContent><p className="text-slate-400 text-center py-8">إدارة النسخ الاحتياطية</p></CardContent>
            </Card>
          </TabsContent>

          {/* Help */}
          <TabsContent value="help">
            <Card className="bg-slate-800 border-slate-700">
              <CardHeader><CardTitle className="text-white flex items-center gap-2"><HelpCircle className="h-5 w-5 text-sky-400" />دليل المستخدم</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3 text-slate-300">
                  <p><strong>1.</strong> اضغط على زر التشغيل للاتصال بـ IB</p>
                  <p><strong>2.</strong> اختر طريقة تحديد الاسترايك</p>
                  <p><strong>3.</strong> فعّل تيليجرام للتنبيهات</p>
                  <p><strong>4.</strong> استخدم رابط الويب هوك في TradingView</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
