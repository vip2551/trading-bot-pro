#!/bin/bash

# ============================================
# 🚂 Railway Startup Script
# ============================================

echo "🚂 Starting Trading Bot on Railway..."

# Generate Prisma Client
echo "📦 Generating Prisma Client..."
bunx prisma generate

# Push database schema
echo "📊 Setting up database..."
bunx prisma db push --skip-generate

# Start mini-services in background
echo "🔄 Starting mini-services..."

# Start IB Service (port from env or default 3003)
if [ -d "mini-services/ib-service" ]; then
  cd mini-services/ib-service
  bun index.ts &
  IB_PID=$!
  echo "   ✓ IB Service started (PID: $IB_PID)"
  cd /app
fi

# Start Trade Monitor (port from env or default 3004)
if [ -d "mini-services/trade-monitor" ]; then
  cd mini-services/trade-monitor
  bun index.ts &
  MONITOR_PID=$!
  echo "   ✓ Trade Monitor started (PID: $MONITOR_PID)"
  cd /app
fi

# Start Realtime Service (port from env or default 3006)
if [ -d "mini-services/realtime-service" ]; then
  cd mini-services/realtime-service
  bun index.ts &
  REALTIME_PID=$!
  echo "   ✓ Realtime Service started (PID: $REALTIME_PID)"
  cd /app
fi

# Start main Next.js app
echo "🚀 Starting Next.js app..."
exec bun run start
